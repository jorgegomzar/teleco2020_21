////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "MAC_ONU.h"
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "ONU_Table.h"

// GENERAMOS EL CÓDIGO Y LAS FUNCIONES DEL MÓDULO SIMPLE
Define_Module(MAC_ONU);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN NUMINITSTAGES()--> ESTA FUNCIÓN INICIALIZA VARIAS ETAPAS. SE DEFINE PARA QUE DEV UELVA EL NÚMERO DE ETAPAS DE INICIO.  //
//							 EN NUESTRO CASO, LA FUNCIÓN DEV ULEV E EL VALOR 1 YA QUE SOLO TENEMOS UNA ETAPA DE INICIALIZACIÓN.	//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int MAC_ONU::numInitStages() const{return 1;}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN INITIALIZE()--> ESTA FUNCIÓN SE INVOCA DESPUÉS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARÁMETROS DEL MÓDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MÓDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINÁMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MÓDULO.			   													//
//						  LA FUNCIÓN INITIALIZE(INT STAGE) SE UTILIZA PARA INICIALIZAR VARIAS ETAPAS SEGUN EL VALOR STAGE.      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MAC_ONU::initialize(int stage)
{
	numsla_onu.resize((int)par("numOnu"),0); // VECTOR QUE GUARDA EL IDENTIFICADOR DE SLA ASOCIADO A LA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED

	// DEFININOS EL PROCESO PARA PODER ENTRAR DESDE ESTE MÓDULO AL MÓDULO ONU_TABLE
	cModule *c_onutable_module;
	if(stage==0)
	{
		c_onutable_module = getParentModule()->getSubmodule("onu_table"); // CAMINO PARA LLEGAR HASTA EL MÓDULO ONU_TABLE
		onutable_module = check_and_cast<ONU_Table *>(c_onutable_module); // ENTRAMOS Y CHEQUEAMOS EL MÓDULO ONU_TABLE
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIÓN SE INVOCA CON EL MENSAJE COMO PARÁMETRO CADA VEZ QUE EL MÓDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CÓDIGO IMPLEMENTADO PARA DEV OLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIÓN DENTRO DEL MÓDULO SIMPLE. EL TIEMPO DE SIMULACIÓN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CÓDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MAC_ONU::handleMessage(cMessage *msg)
{
	// VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED
	int destAddress = 9; // DEFINIMOS EL IDENTIFICADOR DE LA DIRECCIÓN DE DESTINO DE LOS PAQUETES REPORT
	int srcAddress = getParentModule()->getIndex(); // DEFINIMOS EL IDENTIFICADOR DE LA DIRECCIÓN FUENTE DE LOS PAQUETES GATE
	int tamqueuereport[(int)par("numqueue")]; // VARIABLE DE TAMAÑO DE LAS COLAS DEL MENSAJE REPORT CON TAMAÑO IGUAL AL NÚMERO DE COLAS QUE DEFINAMOS
	// GENERAMOS CON EL BUCLE FOR LA VARIABLE DEL TAMAÑO DE LAS COLAS
	for(int b=0; b<(int)par("numqueue"); b++)
	{
		tamqueuereport[b] = 0; // DAMOS EL VALOR 0 A LA VARIABLE DEL TAMAÑO DE LAS COLAS DEL PAQUETE REPORT
	}
	double bandwitch;

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MÓDULO
	switch(type)
	{
		case 0:
			// LLEGA UN PAQUETE GATE CON IDENTIFICADOR = 0
			if(msg->getKind()==0)
			{
				GATEmsg *gatemsg = check_and_cast<GATEmsg *>(msg); // CHEQUEAMOS EL PAQUETE GATE

				numsla_onu[getIndex()] = gatemsg->getNumsla(); // ASIGNAMOS EL IDENTIFICADOR DEL SLA ASOCIADO A LA ONU AL VECTOR numsla_onu[]

				// COMPARAMOS EL MÉTODO DE EXTRACCIÓN DE PAQUETES QUE SE DEFINE EN OMNETPP.INI
				if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
				{
					// VISUALIZAMOS POR PANTALLA CAMPOS DEL PAQUETE GATE
					EV <<" Mensaje Gate en capa MAC para Onu: "<<gatemsg->getDestAddress()<<endl;
					EV <<" Tiempo de comienzo a transmitir: "<<gatemsg->getGrant_IniTime()<<endl;
					EV <<" Ancho de Banda de slot asignado: "<<gatemsg->getGrant_IntervalTx(0)<<endl;

					// GUARDAMOS EN LA TABLA CREADA EN EL MÓDULO ONU_TABLE LOS VALORES DEL TIEMPO DE INICIO DE TRANSMISIÓN Y DE ANCHO DE BANDA DE SLOT
					onutable_module->table_onu_gate_time[0] = gatemsg->getGrant_IniTime();
					onutable_module->table_onu_gate[0] = gatemsg->getGrant_IntervalTx(0);
				}
				else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
				{
					// GUARDAMOS EN LA TABLA DEL MÓDULO ONU_TABLE EL TIEMPO DE INICIO DE TRANSMISIÓN Y LO VISUALIZAMOS POR PANTALLA
					onutable_module->table_onu_gate_time[0] = gatemsg->getGrant_IniTime();
					EV <<" Tiempo de comienzo a transmitir: "<<gatemsg->getGrant_IniTime()<<endl;

					// MEDIANTE EL FOR, GUARDAMOS EN LA TABLA DEL MÓDULO ONU_TABLE EL ANCHO DE BANDA DE SLOT DE CADA COLA Y LO VISUALIZAMOS POR PANTALLA
					for(int i=0; i<(int)par("numqueue"); i++)
					{
						onutable_module->table_onu_gate[i] = gatemsg->getGrant_IntervalTx(i);
						EV <<" Ancho de Banda de slot de la cola "<<i<<": "<<gatemsg->getGrant_IntervalTx(i)<<"Bytes"<<endl;
					}
				}

				// COMPARAMOS EL IDENTIFICADOR DE LA DIRECCIÓN DE DESTINO CON EL PROPIO IDENTIFICADOR DE LA ONU
				if(gatemsg->getDestAddress() == getParentModule()->getIndex())
				{
					// CREAMOS UN AUTOMENSAJE PARA GENERAR EL MENSAJE REPORT
					cMessage *msg = new cMessage ("mensaje inicial report");
					msg->setKind(5); // IDENTIFICADOR DEL AUTOMENSAJE
					scheduleAt(onutable_module->table_onu_gate_time[0], msg);
					// EL AUTOMENSAJE SE MANDA EN EL INSTANTE QUE CONTENIA EL CAMPO getGrant_IniTime() DEL PAQUETE GATE
				}

				delete gatemsg; // BORRAMOS EL PAQUETE GATE
			}
			break;

		case 1:
			// LLEGA UN PAQUETE ETHERNET CON IDENTIFICADOR = 1
			 if(msg->getKind()==1)
			{
				send(msg, "macrxuserOut"); // ENVIA EL PAQUETE ETHERNET QUE SON PARA ELLA HACIA EL MODULO ONU_RXUSER
			}
			break;

		case 5:
			// LLEGA UN AUTOMENSAJE CON IDENTIFICADOR = 5 PARA GENERAR EL PAQUETE REPORT
			if(msg->getKind()==5)
			{
				delete msg; // BORRAMOS EL AUTOMENSAJE YA QUE NO SE UTILIZA MAS VECES



				//CREAMOS EL PAQUETE REPORT
				REPORTmsg *packet = new REPORTmsg("report");
				packet->setByteLength(64); // TAMAÑO DEL PAQUETE REPORT
				packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
				packet->setDestAddress(destAddress); // DIRECCIÓN DE DESTINO
				packet->setPriority((int)par("numqueue")); // PRIORIDAD DEL PAQUETE REPORT
				packet->setLambdareport(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE REPORT
				packet->setKind(2);// IDENTIFICADOR DEL PAQUETE REPORT
				packet->setQueue_estadoArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ESTADO DE LAS COLAS DE LA ONU
				packet->setNumsla(numsla_onu[getIndex()]); // IDENTIFICADOR DEL SLA DE LA ONU


				// BUCLE FOR PARA ASIGNAR EL ESTADO DE LAS COLAS
				for(int i=0; i<(int)par("numqueue"); i++)
				{
					packet->setQueue_estado(i,tamqueuereport[i]);
					packet->getQueue_estado(i);

				}
				packet->setBandwitchArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DEMANDADO DE LA ONU

				// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA GENERAL O UNO PARA CADA COLA
				if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
				{
					// DAMOS A LA VARIABLE bandwitch EL VALOR QUE ESTABA GUARDADO EN LA TABLA DEL MÓDULO ONU_TABLE
					// TAMAÑO TOTAL DE BYTES QUE TENEMOS PARA SACAR MENSAJES DE LAS COLAS
					bandwitch = onutable_module->table_onu_gate[0];
					packet->setBandwitch(0,bandwitch);
					//EV <<" Bandwidth para transmitir paquetes: "<<packet->getBandwitch(0)<<endl;
				}
				else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
				{
					// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA PARA CADA COLA
					for(int i=0; i<(int)par("numqueue"); i++)
					{
						// DEFINIMOS EL ANCHO DE BANDA PARA CADA COLA
						// TAMAÑO TOTAL DE BYTES QUE TENEMOS PARA SACAR MENSAJES DE CADA COLA
						bandwitch = onutable_module->table_onu_gate[i];
						packet->setBandwitch(i,bandwitch);
						//EV <<" Bandwidth para transmitir paquetes cola "<<i<<": "<<packet->getBandwitch(i)<<endl;
					}
				}

				// VISUALIZAMOS POR PANTALLA TODOS LOS CAMPOS DEL PAQUETE REPORT
				/*EV <<" Paquete Report "<<endl;
				EV <<" Origen ONU "<<packet->getSrcAddress()<<endl;
				EV <<" Destino OLT con ID "<<packet->getDestAddress()<<endl;
				EV <<" Prioridad: "<<packet->getPriority()<<endl;
				//EV <<" Longitud de onda de envio, Lambda "<<packet->getLambdareport()<<endl;
				EV <<" Tamaño Paquete Report: "<<packet->getByteLength()<<endl;
				EV <<" Tipo "<<packet->getKind()<<endl;
				EV <<" SLA: "<<packet->getNumsla()<<endl;*/

				// ENVIAMOS LOS PAQUETES REPORT HACIA EL MÓDULO DEL GENERADOR
				send(packet, "macgenOut");
			}
			break;

		default:
			delete msg;
			break;
	}
}
