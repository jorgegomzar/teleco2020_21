////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_MAC_OLT_H_
#define __REDPON_MAC_OLT_H_

#include <omnetpp.h>
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "OLT_Table.h"

//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES Y MATRICES
typedef std::vector<int> int_vector_t; // VECTOR TIPO ENTERO
typedef std::vector<double> double_vector_t; // VECTOR TIPO DOUBLE
typedef std::vector<simtime_t> simtime_t_vector_t; // VECTOR DE TIPO TIEMPO
typedef std::vector< int_vector_t > int_matrix_t; // MATRIZ DE TIPO ENTERO

class MAC_OLT : public cSimpleModule
{
	public:
		int numInitStages() const; // FUNCIÓN QUE INICIALIZA VARIAS ETAPAS.

		OLT_Table *table_module; // DEFINIMOS VARIABLE PARA PODER ENTRAR EN EL MÓDULO OLT_TABLE
		long sumqueue; // VARIABLE DEL TAMAÑO DE LA SUMA DE LOS PAQUETES DE LAS COLAS
		long sumbdemand; // VARIABLE DEL TAMAÑO DE LA SUMA DEL ANCHO DE BANDA DEMANDADO
		long B_sobra; // VARIABLE DEL ANCHO DE BANDA DE SOBRA
		long B_exceded; // VARIABLE DEL ANCHO DE BANDA EN EXCESO
		simtime_t tstarttime; // VARIABLE DEL TIEMPO DE INICIO DE TRANSMISIÓN
		simtime_t t_final; // VARIABLE DEL TIEMPO DE INICIO DE TRANSMISIÓN
		double_vector_t B_alloc; // VECTOR DEL ANCHO DE BANDA ASIGNADO
		double_vector_t B_demand; // VECTOR DEL ANCHO DE BANDA DEMANDADO
		double_vector_t t_slot; // VECTOR DE TIEMPO DE SLOT DE LA ONU
		double_vector_t t_slot_initialization; // VECTOR DE TIEMPO DE SLOT DE LA ONU
		int_vector_t B_extra; // VECTOR DEL ANCHO DE BANDA EXTRA QUE SE ASIGNA A MAYORES
		simtime_t tiempo_tx_siguiente; // VARIABLE DE TIEMPO DE TRANSMISION DE LA SIGUIENTE ONU
		simtime_t tiempo_sim_delay_datarate; // VARIABLE DE TIEMPO DE LA SUMA DEL TIEMPO DE SIMULACION, RETARDO Y TIEMPO DE TRANSMISIÓN DEL PAQUETE GATE
		double_vector_t T_alloc; // VECTOR DE TIEMPO ASIGNADO PARA TRANSMITIR
		double delay; // RETARDO DE NUESTRA RED DEPENDIENDO DE LA LONGITUD TOTAL DE LA RED
		simtime_t delay_pon1; // RETARDO DEL SEGMENTO DE LA RED QUE UNE EL OLT Y EL SPLITTER
		simtime_t_vector_t delay_pon2; // VECTOR DEL RETARDO DEL SEGMENTO DE LA RED QUE UNE EL SPLITTER Y CADA ONU
		simtime_t_vector_t delay_total; // VECTOR DE LA SUMA DE LOS RETARDOS DE CADA SEGMENTO DE LA RED (OLT-SPLITTER Y SPLITTER-ONU)
		double_vector_t B_ex_sla; // VECTOR DEL ANCHO DE BANDA ASOCIADO A CADA ONU SEGUN EL SLA ASOCIADO A LA ONU
		double_vector_t B_max_dmb; // VECTOR DEL ANCHO DE BANDA MÁXIMO PARA CADA ONU
		int id_onu; // IDENTIFICADOR DE LA ONU
		double W_min; // PESO MÍNIMO CON UN VALOR FIJO DE 0.34
		double long_max; // LONGITUD MÁXIMA QUE TIENE UNA ONU PARA TRANSMITIR DEPENDIENDO DEL B_cycle Y DEL NÚMERO DE ONUs
		double B_basico; // ANCHO DE BANDA BASICO PARA TRANSMITIR QUE TIENE CADA ONU.
		double sumatorio; // VARIABLE QUE NOS INDICA EL SUMATORIO DE CADA PESO ASOCIADO A UN SLA POR SU NÚMERO DE ONUS ASOCIADOS A SLA
		int_vector_t SLA_onu; // VECTOR EN EL QUE SE INTRODUCIRA LOS PESOS ASOCIADOS AL SLA QUE CORRESPONDE A CADA ONU
		int_vector_t numonu_sla;// VECTOR DEL NÚMERO DE ONUs ASOCIADAS A CADA SLA
		int_vector_t Wsla; // VECTOR DE LOS PESOS DE CADA SLA
		int_vector_t numsla; // VECTOR QUE NOS GUARDA EL NÚMERO DE SLA ASOCIADO A CADA ONU

	protected:
		virtual void initialize(int stage);
		virtual void handleMessage(cMessage *msg);

		virtual void centralizedmethod_DMB(cMessage *msg); // DEFINICIÓN DE LA FUNCIÓN DEL MÉTODO DMB DEL OLT
		virtual void pollingmethod_IPACT(cMessage *msg); // DEFINICIÓN DE LA FUNCIÓN DEL MÉTODO IPACT DEL OLT
		void centralizedmethod(cMessage *msg);


};

#endif
