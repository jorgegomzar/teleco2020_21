////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TTULO: Implementacin de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERA TCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "ONU_Rx_Report.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include <omnetpp.h>
#include <vector>
#include <time.h>
#include "analysis.h"

// GENERAMOS EL CDIGO Y LAS FUNCIONES DEL MDULO SIMPLE
Define_Module(ONU_Rx_Report);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIN INITIALIZE()--> ESTA FUNCIN SE INVOCA DESPUS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARMETROS DEL MDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Rx_Report::initialize()
{

	// INICIALIZACIN AL VALOR 0 DE VARIABLES
	sumpacketextrac = 0; // SUMA DE LOS PAQUETES QUE SE CHEQUEAN EN EL MTODO DE EXTRACION ESTRICTA DE PAQUETES
	sumextract = 0; // VARIABLE DE LA SUMA DE LOS PAQUETES QUE SE EXTRAEN EN EL MTODO DE EXTRACION ESTRICTA DE PAQUETES
	tamsumqueue = 0; // TAMAO DE LA SUMA DEL TAMAO DE LOS PAQUETES QUE LLEGAN A LAS COLAS DE LA ONU
	sumpacket.resize((int)par("numqueue"),0); // RESERVAMOS TAMAO E INICIALIZAMOS A 0 EL VECTOR DE LA SUMA DE LOS PAQUETES QUE SE CHEQUEAN EN LAS COLAS
	sumqueuepop.resize((int)par("numqueue"),0); // RESERVAMOS TAMAO E INICIALIZAMOS A 0 EL VECTOR DE LA SUMA TOTAL DE BYTES EXTRAIDOS DE LAS COLAS
	bytes_queue.resize((int)par("numqueue"),0); // VECTOR DE LOS BYTES QUE QUEDAN EN LA COLA DESPUES DE CADA CICLO. SE INICIALIZA A 0 CON UN TAMAO IGUAL AL NÚMERO DE COLAS O SERVICIOS DE NUESTRA RED
	media.resize((int)par("numqueue"),0); // VECTOR QUE NOS INDICA LA MEDIA. SE INICIALIZA A 0 CON UN TAMAO IGUAL AL NÚMERO DE COLAS O SERVICIOS DE NUESTRA RED
	media_bytes_queue.resize((int)par("numqueue"));

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIN SE INVOCA CON EL MENSAJE COMO PARMETRO CADA VEZ QUE EL MDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CDIGO IMPLEMENTADO PARA DEVOLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIN DENTRO DEL MDULO SIMPLE. EL TIEMPO DE SIMULACIN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Rx_Report::handleMessage(cMessage *msg)
{
	// VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED
	int extraction = (int)par("extractionmethod_StrictPQ0_Centralized1"); // PARAMETRO PARA ELEGIR EL METODO DE EXTRACCION DE COLAS ( METODO DE EXTRACCION DE COLAS DE PRIORIDAD EXTRICTA  METODO DE EXTRACCION DE COLAS CENTRALIZADO )

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MDULO
	switch(type)
	{
		case 2:
			// LLEGA UN PAQUETE REPORT CON IDENTIFICADOR = 2
			if(msg->getKind()==2)
			{
				EV <<" Recibimos paquete Report y sacamos paquetes de las colas" << endl;

				// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA EL MTODO DE EXTRACCIN DE PAQUETES DE LAS COLAS
				switch(extraction)
					{
						case 0:
							EV << " Metodo de Extracción de Colas de Prioridad Estricta." << endl;
							strictpriorityqueue(msg); // LLAMADA A LA FUNCIN DEL MTODO DE EXTRACCIN DE PAQUETES DE COLAS DE PRIORIDAD ESTRICTA
							break;

						case 1:
							EV << " Metodo de Extracción de Colas Centralizado." << endl;
							centralizedmethod(msg); // LLAMADA A LA FUNCIN DEL MTODO DE EXTRACCIN DE PAQUETES DE COLAS CENTRALIZADO
							break;

						default:
							EV <<" ERROR AL ELEGIR EL METODO DE EXTRACCION DE PAQUETES DE COLAS, ELEGIR 0  1."<< endl;
							delete msg;
							break;
					}
			}
			break;
	}


}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIN STRICTPRIORITYQUEUE(CMESSAGE *MSG)--> FUNCIN QUE NOS INDICA UN MTODO PARA LA EXTRACCIN DE PAQUETES DE LAS COLAS.	 //
//					ESTE MTODO ES DE EXTRACCIN DE PAQUETES DE LAS COLAS DE PRIORIDAD ESTRICTA. EL TAMAO EN BYTES QUE TENEMOS	 //
//					PARA TRANSMITIR PAQUETES DE LAS COLAS SE NOS INDICA PARA TODAS LAS COLA JUNTAS EN GLOBAL. CUANDO LLEGA EL 	 //
//					PAQUETE REPORT AL MDULO SIMPLE ONU_Rx_Report, RECORREMOS LAS COLAS DE MAYOR PRIORIDAD A MENOR PRIORIDAD PARA//
//					OBTENER EL TAMAO DEL PRIMER PAQUETE QUE ESTA INSERTADO EN LA COLA A EXTRAER, Y DEPENDIENDO DEL TAMAO TOTAL //
//					EN BYTES DE TODAS LAS COLAS QUE TENEMOS PARA TRANSMITIR, EXTRAEMOS PAQUETES DE LA COLA DE MAYOR PRIORIDAD 	 //
//					HASTA QUE SE QUEDA SIN PAQUETES Y SEGUIMOS HACIA COLAS DE MENOR PRIORIDAD HASTA	QUE COMPLETAMOS EL TAMAO 	 //
//					TOTAL DE BYTES QUE TIENE LA ONU PARA TRANSMITIR.															 //
//					MEDIANTE ESTE MTODO DAMOS PRIORIDAD AL TRFICO DE MAYOR PRIORIDAD.										 //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Rx_Report::strictpriorityqueue(cMessage *msg)
{
	// EJECUTAMOS EL MTODO DE EXTRACCIN DE COLAS DE PRIORIDAD ESTRICTA

	REPORTmsg *reportmsg=check_and_cast<REPORTmsg*>(msg); // CHEQUEAMOS EL PAQUETE REPORT


	// RECORREMOS LAS COLAS PARA VISUALIZAR POR PANTALLA EL TAMAO DE LAS COLAS
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		// VARIABLES PARA PODER ENTRAR DESTE STE MDULO AL MDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIN SOBRE LAS COLAS
		cModule *c_onu_queue;
		c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
		onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
		//EV<<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
	}

	// RECORREMOS LAS COLAS PARA COMPROBAR SI TIENEN PAQUETES Y EXTRAER LOS BYTES QUE NOS PROPORCION EL OLT
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		// VARIABLES PARA PODER ENTRAR DESTE STE MDULO AL MDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIN SOBRE LAS COLAS
		cModule *c_onu_queue;
		c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
		onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);

		// COMPARAMOS SI LA COLA EN LA QUE NOS ENCONTRAMOS TIENE PAQUETES INSERTADOS EN ELLA,
		// ADEMS COMPARAMOS SI EL ANCHO DE BANDA ASIGANDO POR EL OLT ES MAYOR O IGUAL A LA SUMA DE PAQUETES QUE EXTRAEMOS MS EL TAMAO DEL PAQUETE REPORT QUE SE MANDA EN ESE ANCHO DE BANDA ASIGNADO HACIA LA ONU
		if(onu_queue->queue.getLength()>0 && reportmsg->getBandwitch(0) >= sumpacketextrac + reportmsg->getByteLength())
		{
			// RECORREMOS TODOS LOS PAQUETES DE LA COLA DESDE EL MAS ANTIGUO PARA EXTRAERLOS
			for(int j=0; (j=onu_queue->queue.getLength()); j++)
			{
				// LLAMAMOS A LA FUNCIN CHEQUEAR PAQUETE PARA COMPROBAR QUE PODEMOS EXTRAERLO Y LO VISUALIZAMOS POR LA PANTALLA
				onu_queue->checkpacket();
				EV<<" "<<endl;
				EV<<" Tamaño paquete chequeado cola"<<i<<"-> "<< onu_queue->tamqueueextract<<"Bytes"<<endl;
				// SUMA DE LOS PAQUETES QUE SE CHEQUEAN Y LO VISUALIZAMOS POR PANTALLA
				sumpacketextrac = sumpacketextrac + onu_queue->tamqueueextract;
				EV<<" Suma paquetes que se extraen-> "<<sumpacketextrac<<"Bytes"<<endl;

				// COMPROBAMOS SI EL ANCHO DE BANDA ASIGANDO POR EL OLT ES MAYOR O MENOR QUE LA SUMA DE PAQUETES QUE EXTRAEMOS MS EL TAMAO DEL PAQUETE REPORT QUE SE MANDA EN ESE ANCHO DE BANDA ASIGNADO HACIA LA ONU
				if(reportmsg->getBandwitch(0) >= sumpacketextrac + reportmsg->getByteLength())
				{
					// SI EL ANCHO DE BANDA ASIGNADO ES MAYOR, SE EXTRAE EL PAQUETE Y SE ENVIA HACIA EL OLT
					//EV<<" Extraemos y enviamos paquete a el OLT."<<endl;
					onu_queue->extractionelement(i); // LLAMAMOS DE FORMA REMOTA A LA FUNCION EXTRAER PAQUETES IMPLEMENTADA EN EL MDULO ONU_SISTQUEUE
					// SUMA DE LOS PAQUETES QUE EXTRAEMOS EN ESTA COLA
					sumextract = sumextract + onu_queue->tamextract;
				}
				else if(reportmsg->getBandwitch(0) < sumpacketextrac + reportmsg->getByteLength())
				{
					// SI EL ANCHO DE BANDA ASIGNADO ES MENOR, NO SE EXTRAEN MS PAQUETES
					EV<<" No extraemos paquete de tamaño "<< onu_queue->tamqueueextract<<" porque no entra en el Ancho de Banda de Slot de "<< reportmsg->getBandwitch(0)<<endl;
					break; // SALIMOS DEL BUCLE FOR QUE RECORRE TODOS LOS PAQUETES DE LA COLA EN LA QUE NOS ENCONTRAMOS
				}
			}
		}
		else if(reportmsg->getBandwitch(0) < sumpacketextrac + reportmsg->getByteLength())
		{
			tamsumqueue = tamsumqueue - sumextract; // RESTAMOS EL TAMAO DE LOS PAQUETES QUE HEMOS EXTRAIDO A LA SUMA DEL TAMAO DE LOS PAQUETES DE LAS COLAS
			break; // SALIMOS DEL BUCLE FOR QUE RECORRE TODAS LAS COLAS
		}

	}

	// COMPROBAMOS SI EL ANCHO DE BANDA ASIGANDO POR EL OLT ES MAYOR QUE LA SUMA DE PAQUETES QUE EXTRAEMOS MS EL TAMAO DEL PAQUETE REPORT QUE SE MANDA EN ESE ANCHO DE BANDA ASIGNADO HACIA LA ONU
	if(reportmsg->getBandwitch(0) >= sumpacketextrac + reportmsg->getByteLength())
	{
		tamsumqueue = tamsumqueue - sumextract; // RESTAMOS EL TAMAO DE LOS PAQUETES QUE HEMOS EXTRAIDO A LA SUMA DEL TAMAO DE LOS PAQUETES DE LAS COLAS
	}

	//EV<<"             "<<endl;
	//EV<<" Actualizamos el tamaño de las colas y lo reescribimos en el Report."<<endl;

	// ACTUALIZAMOS EL VALOR DE LAS COLAS QUE LLEVARA EL REPORT HASTA EL OLT Y LO VISUALIZAMOS POR PANTALLA
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		// VARIABLES PARA PODER ENTRAR DESTE STE MDULO AL MDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIN SOBRE LAS COLAS
		cModule *c_onu_queue;
		c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
		onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);

		// VISUALIZAMOS POR PANTALLA EL TAMAO DE LAS COLAS Y LO INTRODUCIMOS EN EL PAQUETE REPORT PARA MANDARLO HACIA EL OLT
		//EV<<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
		reportmsg->setQueue_estado(i,onu_queue->tamqueue[i]); // INTRODUCIMOS EL VALOR OBTENIDO ANTERIORMENTE PARA MANDARLO EN EL PAQUETE REPORT
		bytes_queue[i] = reportmsg->getQueue_estado(i); // INTRODUCIMOS EN LA VARIABLE bytes_queue[] EL VALOR DEL TAMAO DE LOS BYTES QUE QUEDAN LA COLA
		EV<<" Bytes que quedan en la cola después de transmitir"<<i<<": "<<bytes_queue[i]<<endl; // VISUALIZAMOS EL VALOR POR PANTALLA

	}

	// CALCULAMOS LA MEDIA DE LOS BYTES QUE SE QUEDAN EN LA COLA CADA CICLO
	if(simTime()>=1)// && getIndex()==0)
	{
		// BUCLE FOR PARA RECORRER TODAS LAS COLAS QUE TENGAMOS Y GUARDAR EN LA VARIABLE media[] LOS BYTES QUE QUEDAN EN LAS COLAS DESPUES DE CADA CICLO
		for(int i=0; i<(int)par("numqueue"); i++)
		{
			media[i] = bytes_queue[i]; // GUARDAMOS EN LA VARIABLE media[] LOS BYTES QUE QUEDAN EN LAS COLAS DESPUES DE CADA CICLO
			media_bytes_queue[i].analyze(media[i]);
		}

		// SI QUEREMOS QUE LA SIMULACIN TERMINE Y LLAME A LA FUNCIN FINISH() PARA RECOGER LAS ESTADSTICAS DE LA MEDIA DE LOS
		// BYTES QUE QUEDAN EN LAS COLAS DESPUS DE CADA CICLO.
		// PARA PARAR LA SIMULACIN EL VALOR DEL NÚMERO DE ITERACIONES DE LA CLASE ANALISIS DEL PARMETRO QUE CALCULA LA MEDIA
		// DEBE SER IGUAL O MAYOR AL QUE INTRODUZCAMOS MANUALMENTE
		// DEPENDIENDO DEL NÚMERO DE COLAS QUE TENGAMOS, DEBEMOS INTRODUCIR LAS VARIABLES CORESPONDIENTES

		//if( media_bytes_queue[0].number_iterations() >= 20)
		//{
		//	endSimulation(); // LLAMAMOS A LA FUNCIN TERMINAR SIMULACIN
		//	callFinish(); // LLAMAMOS A LA FUNCIN FINISH()
		//}

	}

	//ENVIAMOS EL PAQUETE REPORTR HACIA LA COLA DE ALMACENAMIENTO DE ESTOS PAQUETES DESPUES DE ACTUALIZAR EL ESTADO DE LAS COLAS
	send(reportmsg, "rxqueuereportOut");//, (int)par("numqueue"));

	sumpacketextrac = 0; // ACTUALIZAMOS EL VALOR DE LA VARIABLE sumpacketextra A UN VALOR DE 0 PARA EL PROXIMO CICLO DE EXTRACCIN DE PAQUETES
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIN CENTRALIZEDMETHOD(CMESSAGE *MSG)--> FUNCIN QUE NOS INDICA UN MTODO PARA LA EXTRACCIN DE PAQUETES DE LAS COLAS.		//
//					ESTE MTODO ES DE EXTRACCIN DE PAQUETES DE LAS COLAS CENTRALIZADO. EL TAMAO EN BYTES QUE TENEMOS PARA 	//
//					TRANSMITIR PAQUETES DE LAS COLAS SE NOS INDICA PARA COLA POR SEPARADO. CUANDO LLEGA EL PAQUETE REPORT AL 	//
//					MDULO SIMPLE ONU_Rx_Report, RECORREMOS LAS COLAS DE MAYOR PRIORIDAD A MENOR PRIORIDAD PARA OBTENER EL 		//
//					TAMAO DEL PRIMER PAQUETE QUE ESTA INSERTADO EN LA COLA A EXTRAER, Y DEPENDIENDO DEL TAMAO EN BYTES 		//
//					ASIGNADO A LA COLA EN LA EXTRAEMOS PAQUETES, SACAMOS PAQUETES DE LA COLA DE MAYOR PRIORIDAD A COLAS DE MENOR//
//					PRIORIDAD HASTA	QUE COMPLETAMOS EL TAMAO TOTAL DE BYTES QUE TIENE ESA ONU PARA TRANSMITIR.					//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Rx_Report::centralizedmethod(cMessage *msg)
{
	// EJECUTAMOS EL MTODO DE EXTRACCIN DE COLAS CENTRALIZADO

	REPORTmsg *reportmsg=check_and_cast<REPORTmsg*>(msg); // CHEQUEAMOS EL PAQUETE REPORT

	// RECORREMOS LAS COLAS PARA COMPROBAR SI TIENEN PAQUETES Y EXTRAER LOS BYTES QUE NOS PROPORCION EL OLT
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		// VARIABLES PARA PODER ENTRAR DESTE STE MDULO AL MDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIN SOBRE LAS COLAS
		cModule *c_onu_queue;
		c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
		onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);

		EV<<" Ancho de Banda: "<<reportmsg->getBandwitch(i)<<endl;
		EV<<" Nos encontramos en la cola "<<i<<endl;

		// COMPARAMOS SI LA COLA EN LA QUE NOS ENCONTRAMOS TIENE PAQUETES INSERTADOS EN ELLA,
		// ADEMS COMPARAMOS SI EL ANCHO DE BANDA ASIGANDO POR EL OLT ES MAYOR O IGUAL A LA SUMA DE PAQUETES QUE EXTRAEMOS EN LA COLA EN LA QUE NOS ENCONTRAMOS MS EL TAMAO DEL PAQUETE REPORT QUE SE MANDA EN ESE ANCHO DE BANDA ASIGNADO HACIA LA ONU
		if(onu_queue->queue.getLength()>0 && reportmsg->getBandwitch(i) >= sumpacket[i] + reportmsg->getByteLength())
		{
			// RECORREMOS TODOS LOS PAQUETES DE LA COLA DESDE EL MAS ANTIGUO PARA EXTRAERLOS
			for(int j=0; (j=onu_queue->queue.getLength()); j++)
			{
				// LLAMAMOS A LA FUNCIN CHEQUEAR PAQUETE PARA COMPROBAR QUE PODEMOS EXTRAERLO Y LO VISUALIZAMOS POR LA PANTALLA
				onu_queue->checkpacket();
				EV<<" "<<endl;
				EV<<" Tamaño paquete chequeado cola "<<i<<"-> "<< onu_queue->tamqueueextract<<"Bytes"<<endl;
				// SUMA DE LOS PAQUETES QUE SE EXTRAEN EN LA COLA QUE NOS ENCONTRAMOS
				sumpacket[i] = sumpacket[i] + onu_queue->tamqueueextract;
				EV<<" Suma paquetes que se extraen en la cola "<<i<<"-> "<<sumpacket[i]<<"Bytes"<<endl;

				// COMPROBAMOS SI EL ANCHO DE BANDA ASIGANDO POR EL OLT ES MAYOR O MENOR QUE LA SUMA DE PAQUETES QUE EXTRAEMOS EN LA COLA EN LA QUE NOS ENCONTRAMOS MS EL TAMAO DEL PAQUETE REPORT QUE SE MANDA EN ESE ANCHO DE BANDA ASIGNADO HACIA LA ONU
				if(reportmsg->getBandwitch(i) >= sumpacket[i] + reportmsg->getByteLength())
				{
					// SI EL ANCHO DE BANDA ASIGNADO ES MAYOR, SE EXTRAE EL PAQUETE Y SE ENVIA HACIA EL OLT
					EV<<" Extraemos y enviamos paquete a la Onu."<<endl;
					onu_queue->extractionelement(i); // LLAMAMOS DE FORMA REMOTA A LA FUNCION EXTRAER PAQUETES IMPLEMENTADA EN EL MDULO ONU_SISTQUEUE
					// SUMA DE LOS PAQUETES QUE EXTRAEMOS EN ESTA COLA Y LO VISUALIZAMOS POR PANTALLA
					sumextract = sumextract + onu_queue->tamextract;
					EV<<" Suma total de Bytes Extraidos-> "<<sumextract<<"Bytes"<<endl;
					// SUMA TOTAL DEL TAMAO DE LOS PAQUETES EXTRAIDOS EN LA COLA EN LA QUE NOS ENCONTRAMOS Y LO VISUALIZAMOS POR PANTALLA
					sumqueuepop[i] = sumqueuepop[i] + onu_queue->tamextract;
					EV<<" Suma total de Bytes Extraidos de la cola "<<i<<"-> "<<sumqueuepop[i]<<"Bytes"<<endl;
				}
				else if(reportmsg->getBandwitch(i) < sumpacket[i] + reportmsg->getByteLength())
				{
					// SI EL ANCHO DE BANDA ASIGNADO ES MENOR, NO SE EXTRAEN MS PAQUETES
					EV<<" No extraemos más paquetes porque no entra en el Ancho de Banda de Slot."<<endl;
					break; // SALIMOS DEL BUCLE FOR QUE RECORRE TODOS LOS PAQUETES DE LA COLA EN LA QUE NOS ENCONTRAMOS
				}
			}
		}
	}
	// RESTAMOS EL TAMAO DE LOS PAQUETES QUE HEMOS EXTRAIDO A LA SUMA DEL TAMAO DE LOS PAQUETES DE LAS COLAS
	tamsumqueue = tamsumqueue - sumextract;


	EV<<"             "<<endl;
	EV<<" Actualizamos el tamaño de las colas y lo reescribimos en el Report."<<endl;

	// ACTUALIZAMOS EL VALOR DE LAS COLAS QUE LLEVARA EL REPORT HASTA EL OLT Y LO VISUALIZAMOS POR PANTALLA
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		// VARIABLES PARA PODER ENTRAR DESTE STE MDULO AL MDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIN SOBRE LAS COLAS
		cModule *c_onu_queue;
		c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
		onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);

		// VISUALIZAMOS POR PANTALLA EL TAMAO DE LAS COLAS Y LO INTRODUCIMOS EN EL PAQUETE REPORT PARA MANDARLO HACIA EL OLT
		EV<<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
		reportmsg->setQueue_estado(i,onu_queue->tamqueue[i]);
		bytes_queue[i] = reportmsg->getQueue_estado(i); // INTRODUCIMOS EN LA VARIABLE bytes_queue[] EL VALOR DEL TAMAO DE LOS BYTES QUE QUEDAN LA COLA
		EV<<" Bytes que quedan en la cola"<<i<<": "<<bytes_queue[i]<<endl; // VISUALIZAMOS EL VALOR POR PANTALLA
	}

	// CALCULAMOS LA MEDIA DE LOS BYTES QUE SE QUEDAN EN LA COLA CADA CICLO
	if(simTime()>=1)
	{
		// BUCLE FOR PARA RECORRER TODAS LAS COLAS QUE TENGAMOS Y GUARDAR EN LA VARIABLE media[] LOS BYTES QUE QUEDAN EN LAS COLAS DESPUES DE CADA CICLO
		// BUCLE FOR PARA RECORRER TODAS LAS COLAS QUE TENGAMOS Y GUARDAR EN LA VARIABLE media[] LOS BYTES QUE QUEDAN EN LAS COLAS DESPUES DE CADA CICLO
		for(int i=0; i<(int)par("numqueue"); i++)
		{
			media[i] = bytes_queue[i]; // GUARDAMOS EN LA VARIABLE media[] LOS BYTES QUE QUEDAN EN LAS COLAS DESPUES DE CADA CICLO
			media_bytes_queue[i].analyze(media[i]);
		}

		// SI QUEREMOS QUE LA SIMULACIN TERMINE Y LLAME A LA FUNCIN FINISH() PARA RECOGER LAS ESTADSTICAS DE LA MEDIA DE LOS
		// BYTES QUE QUEDAN EN LAS COLAS DESPUS DE CADA CICLO.
		// PARA PARAR LA SIMULACIN EL VALOR DEL NÚMERO DE ITERACIONES DE LA CLASE ANALISIS DEL PARMETRO QUE CALCULA LA MEDIA
		// DEBE SER IGUAL O MAYOR AL QUE INTRODUZCAMOS MANUALMENTE
		// DEPENDIENDO DEL NÚMERO DE COLAS QUE TENGAMOS, DEBEMOS INTRODUCIR LAS VARIABLES CORESPONDIENTES

		//if( media_bytes_queue[0].number_iterations() >= 30)
		//{
		//	endSimulation(); // LLAMAMOS A LA FUNCIN TERMINAR SIMULACIN
		//	callFinish(); // LLAMAMOS A LA FUNCIN FINISH()
		//}
	}

	//ENVIAMOS EL PAQUETE REPORTR HACIA LA COLA DE ALMACENAMIENTO DE ESTOS PAQUETES DESPUES DE ACTUALIZAR EL ESTADO DE LAS COLAS
	send(reportmsg, "rxqueuereportOut");//, (int)par("numqueue"));

}

void ONU_Rx_Report::finish()
{

	// RECOGIDA DE ESTADISTICAS DE LAS MEDIAS DE LOS BYTES QUE QUEDAN EN LAS COLAS DESPUS DE CADA CICLO CON LA CLASE ANALISIS Y LO GUARDAMOS LOS DATOS EN UN ARCHIVO
	// SE PONE LA RUTA DONDE SE VAN A CREAR LOS ARCHIVOS
	media_queue_onu=fopen("results/media_queue_onu.txt", "a+"); // ABRIMOS EL ARCHIVO EN EL QUE GUARDAREMOS LOS RESULTADOS
		for(int i=0; i<(int)par("numqueue"); i++)
		{
			fprintf(media_queue_onu,"%g\t", (double)media_bytes_queue[i].average()); // MEDIA DE LOS BYTES QUE QUEDAN EN LAS COLAS DESPUS DE CADA CICLO
		}
		fprintf(media_queue_onu,"\n");
		fclose(media_queue_onu); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS
}


