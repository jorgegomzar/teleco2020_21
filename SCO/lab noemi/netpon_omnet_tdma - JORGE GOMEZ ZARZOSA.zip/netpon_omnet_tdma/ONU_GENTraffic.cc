////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TxTULO: Implementacixn de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERxA TxCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIxN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "ONU_GENTraffic.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include <omnetpp.h>
#include <vector>
#include <time.h>
#include "analysis.h"
#include "ONU_Table.h"

// DEPENDIENDO DE LA VERSIxN DE LA FUENTE SELF SIMILAR CON LA QUE QUEREMOS TRABAJAR, DEBEMOS ELEGIR UNAS CABECERAS U OTRAS.
// PARA ELEGIR LA VERSIxN DE LA FUENTE CON LA QUE QUERAMS TRABAJAR, TENEMOS QUE COMENTAR Y DESCOMENTAR LAS CABECERAS Y
// LO QUE ESTA EN LAS FUNCIxNES INITIALIZE() Y HANDLEMESSAGE() PARA CADA VERSIxN DE LA FUENTE

// FUENTE SELF SIMILAR VERSIxN 2 /////////////////////////////////

#include "_types.h"
#include "_util.h"
#include "_rand_MT.h"
#include "_link.h"
#include "trace.h"
#include "aggreg.h"

// FIN DE LA FUENTE VERSIxN 2//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// FUENTE SELF SIMILAR VERSIxN 3 //////////////////////////////////
/*
#include "trf_gen_v3.h"
#include "avltree.h"
#include "_types.h"
*/
// FIN DE LA FUENTE VERSIxN 3//////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// GENERAMOS EL CxDIGO Y LAS FUNCIONES DEL MxDULO SIMPLE
Define_Module(ONU_GENTraffic);

// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2 /////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//CONSTRUCTOR--> ESTABLECE LOS MIEMBROS DEL PUNTERO DEL GENERADOR EN NULL.														//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ONU_GENTraffic::ONU_GENTraffic()
{
    pAG = NULL; // PUNTERO AL GENERADOR DE PAQUETES CON VALOR NULL O VACIO
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DESTRUCTOR--> ELIMINA TODO LO QUE FUE ASIGNADO COMO NUEV O EN EL PUNTERO AL GENERADOR DE PAQUETES.								//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ONU_GENTraffic::~ONU_GENTraffic()
{
    delete pAG; // BORRAMOS EL PUNTERO AL GENERADOR DE PAQUETES
}

// FINAL DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2 ////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 ////////////////////////////////////////////////////////////////////
/*
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// DEV UELVE LA LLAMADA DE LA FUNCIxN QUE CREA NUEV OS SUBS.STREAMS CON LA DISTRIBUCIxN DESEADA.									//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Stream* CreateStream( load_t load, float mean_burst,int id )
{
return new StreamPareto( load, mean_burst, SHAPE_PARETO ); // TIPO DE GENERADOR DE TRxFICO DE PARETO.
//return new StreamExpon( load, mean_burst ) ; // TIPO DE GENERACIxN DE TRxFICO EXPONENCIAL

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// DEV UELVE LA LLAMADA DE LA FUNCIxN QUE GENERA LOS TAMAxOS DE LOS PAQUETES CON LA DISTRIBUCIxN DESEADA.						//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
pckt_size_t PacketSize( void ) // TAMAxO DEL PAQUETE A GENERAR
{
long int packetSize = (long int) 1500; // TAMAxO DEL PAQUETE FIJO = 1500 BYTES
//int packetSize = intuniform(MIN_PACKET_SIZE,MAX_PACKET_SIZE); // TAMAxO DEL PAQUETE DEFINIDO EN EL ARCHIVO ONU_GENTRAFFIC.H

return (pckt_size_t)(packetSize); // DEV UELVE EL TAMAxO DEL PAQUETE SELECCIONADO
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//CONSTRUCTOR--> ESTABLECE LOS MIEMBROS DEL PUNTERO DEL GENERADOR EN NULL.														//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ONU_GENTraffic::ONU_GENTraffic()
{
	pSRC=NULL; // PUNTERO AL GENERADOR DE PAQUETES CON VALOR NULL O VACIO
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//DESTRUCTOR--> ELIMINA TODO LO QUE FUE ASIGNADO COMO NUEV O EN EL PUNTERO AL GENERADOR DE PAQUETES.								//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ONU_GENTraffic::~ONU_GENTraffic()
{
	delete pSRC; // BORRAMOS EL PUNTERO AL GENERADOR DE PAQUETES
}
*/
// FINAL DEL CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 ///////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN INITIALIZE()--> ESTA FUNCIxN SE INVOCA DESPUxS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARxMETROS DEL MxDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MxDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINxMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MxDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_GENTraffic::initialize()
{
// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2 ///////////////////////////////////////////////////////////////////////

	// VARIABLES
	load_dmb.resize((int)par("numqueue"),0); // VECTOR QUE INDICA LA CARGA DEL NODO DE LA ONU. SE INICIALIZA A 0 CON UN TAMAxO IGUAL AL NÚMERO DE COLAS DE NUESTRA RED

	// COMPARAMOS EL NÚMERO DE COLAS O SERVICIOS DE LA ONU
	if((int)par("numqueue")==1)
	{
		// LA ONU SOLO TIENE UN SERVICIO
		load_dmb[getIndex()] = (double)par("node_load"); // VARIABLE CARGA DEL NODO DE LA ONU Y LA VISUALIZAMOS POR PANTALLA
		EV <<" Carga de los nodos de las ONU: "<<load_dmb[getIndex()]<<endl;
	}
	else if((int)par("numqueue")>=2)
	{
		// LA ONU TIENE 2 O MxS SERVICIOS
		if(getIndex()==0)
		{
			// SERVICIO P0
			EV <<" Carga de los nodos de las ONU: 0.0448"<<endl;
		}
		else if(getIndex()>=1)
		{
			load_dmb[getIndex()] = (double)par("node_load"); // VARIABLE CARGA DEL NODO DE LA ONU Y LA VISUALIZAMOS POR PANTALLA
			EV <<" Carga de los nodos de las ONU: "<<load_dmb[getIndex()]<<endl;
		}
	}

	packetSize = 64;  // TAMAxO DEL PAQUETE FIJO PARA LA FUENTE SELF SIMILAR VERSIxN 2
	//packetSize = intuniform(MIN_PACKET_SIZE,MAX_PACKET_SIZE); // TAMAxO DEL PAQUETE VARIABLE ENTRE DOS VALORES PARA LA FUENTE SELF SIMILAR VERSIxN 2
	int streams = (int)par("numstreamV2"); // NÚMERO DE FUENTES O SUB-STREAMS
	int method_generator = (int)par("longpacketfixed0_trimodal1"); // PARxMETRO PARA DEFINIR LA LONGITUD O TAMAxO DE LOS PAQUETES DE LA RED ( LONGITUD O TAMAxO DE LOS PAQUETES DE LA RED FIJA x LONGITUD O TAMAxO DE LOS PAQUETES DE LA RED TRIMODAL )

	// COMPARAMOS CON EL SWITCH EL MxTODO CON EL QUE TRABAJA EL GENERADOR ( MONOMODAL O TRIMODAL )
	switch(method_generator)
	{
		case 0:
			// MONOMODAL-> 1 SERVICIO
			pAG =new Generator; // PUNTERO PARA EL GENERADOR
			for( int src = 0; src < streams; src++ )
			{
			pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
			}
			break;

		case 1:
			// TRIMODAL-> 3 SERVICIOS

			switch((int)par("numstreamV2"))
			{
				case 32:
					pAG =new Generator; // PUNTERO PARA EL GENERADOR
					// MEDIANTE EL BUCLE FOR REPARTIMOS LAS FUENTES O STREAMS PARA GENERAR PAQUETES DE VARIOS TAMAxOS O LONGITUDES
					for( int src = 0; src < streams; src++ )
					{
						if(src<3)
						{
							packetSize = 64;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
						else if(src>=3 && src<8)
						{
							packetSize = 594;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
						else if(src>=8)
						{
							packetSize = 1500;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
					}
					break;

				case 128:
					pAG =new Generator; // PUNTERO PARA EL GENERADOR
					// MEDIANTE EL BUCLE FOR REPARTIMOS LAS FUENTES O STREAMS PARA GENERAR PAQUETES DE VARIOS TAMAxOS O LONGITUDES
					for( int src = 0; src < streams; src++ )
					{
						if(src<12)
						{
							packetSize = 64;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
						else if(src>=12 && src<32)
						{
							packetSize = 594;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
						else if(src>=32)
						{
							packetSize = 1500;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
					}
					break;

				case 256:
					pAG =new Generator; // PUNTERO PARA EL GENERADOR
					// MEDIANTE EL BUCLE FOR REPARTIMOS LAS FUENTES O STREAMS PARA GENERAR PAQUETES DE VARIOS TAMAxOS O LONGITUDES
					for( int src = 0; src < streams; src++ )
					{
						if(src<24)
						{
							packetSize = 64;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
						else if(src>=24 && src<64)
						{
							packetSize = 594;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
						else if(src>=64)
						{
							packetSize = 1500;
							pAG->AddSource( new SourcePareto( src, 0, packetSize, 0, load_dmb[getIndex()]/streams, 1.4, 1.2 ));
						}
					}
					break;
			}

	}

	//CREAMOS UN AUTOMENSAJE PARA CREAR LOS PAQUETES ETHERNET QUE MANDA LA ONU HACIA EL OLT
	cMessage *msg = new cMessage ("mensaje inicial");
	msg->setKind(5); // IDENTIFICADOR DEL AUTOMENSAJE
	scheduleAt(0.0001, msg);

// FINAL DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2 ////////////////////////////////////////////////////////////////////////



// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 ////////////////////////////////////////////////////////////////////////
/*
	// INICIALIZACIxN DE LAS VARIABLES DEFINIDAS EN EL ARCHIVO ONU_GENTRAFFIC.H
	load = (int)par("node_load");
	pSRC=new PacketGenerator ( 0, MIN_IFG, MEAN_BURST_SIZE, CreateStream, PacketSize, SUB_STREAMS, load);

	// CREAMOS UN AUTOMENSAJE PARA CREAR LOS PAQUETES ETHERNET QUE MANDA LA ONU HACIA EL OLT
	cMessage *msg = new cMessage ("mensaje inicial");
	msg->setKind(5); // IDENTIFICADOR DEL AUTOMENSAJE
	scheduleAt(1, msg);
*/
// FINAL DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 //////////////////////////////////////////////////////////////////////////

	// INICIALIZACIxN AL VALOR 0 DE VARIABLES
	tamsumpop.resize((int)par("numqueue"),0); // RESERVAMOS TAMAxO E INICIALIZAMOS A 0 EL VECTOR DEL TAMAxO DE LA SUMA DE LOS BYTES DE LOS PAQUETES EXTRAIDOS DE LAS COLAS
	suma_tam_packets = 0; // VARIABLE DE LA SUMA TOTAL DEL TAMAxO DE LOS PAQUETES GENERADOS POR LA ONU EN BYTES
	total_load = 0; // CARGA TOTAL DEL NODO DE LA ONU
	time_creation = 0; // TIEMPO DE CREACCIxN

	suma_total.resize((int)par("numqueue"),0); // RESERVAMOS TAMAxO E INICIALIZAMOS A 0 EL VECTOR DE LA SUMA TOTAL DE LOS BYTES DE LOS PAQUETES QUE ESTAN INSERTADOS EN LAS COLAS

	// INICIALIZAMOS LAS VARIABLES PARA CALCULAR LAS ESTADxSTICAS DE LOS PAQUETES CREADOS POR EL GENERADOR
	packet_64 = 0;
	packet_594 = 0;
	packet_1500 = 0;
	totalpacket = 0;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIxN SE INVOCA CON EL MENSAJE COMO PARxMETRO CADA VEZ QUE EL MxDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CxDIGO IMPLEMENTADO PARA DEV OLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIxN DENTRO DEL MxDULO SIMPLE. EL TIEMPO DE SIMULACIxN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CxDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_GENTraffic::handleMessage(cMessage *msg)
{
	//VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED
	int method = (int)par("insercionmethod_separatequeue0_priorityqueue1"); // PARAMETRO PARA ELEGIR EL METODO DE COLAS ( METODO DE COLAS SEPARADAS O METODO DE PRIORIDAD DE COLAS )
	double buffer = (double)par("tambuffer"); // TAMAxO TOTAL DEL BUFFER Y VISUALIZACIxN POR PANTALLA
	//EV <<" Tamaño del Buffer: "<<buffer<<endl;
	// TASA DE BITS POR LONGITUD DE ONDA UTILIZADA
	wavelength_bit_rate=(int)par("txrate")/10;// DIVIDIMOS LA TASAS DE TRANSMISIxN ENTRE 10 PARA QUE TENGAMOS EL PARxMETRO = 10e8 PARA TENER UN TAMAxO DE BUFFER DE 10 MBytes
	int destAddress = 9; // DIRECCIxN DE DESTINO DEL PAQUETE ETHERNET
	int srcAddress = getParentModule()->getParentModule()->getIndex(); // DIRECCIxN FUENTE O DE ORIGEN DEL PAQUETE ETHERNET
	int priority = getIndex(); // PARxMETRO DE LA PRIORIDAD QUE SE ASIGNA POR EL IDENTIFICADOR DE LA FUENTE QUE SE CREA
	double txrate = (int)par("txrate"); // TASA DE TRANSMISIxN EN BITS POR SEGUNDO

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MxDULO
	switch(type)
	{
		case 5:
			// LLEGA UN AUTOMENSAJE CON IDENTIFICADOR = 5 PARA GENERAR EL PAQUETE ETHERNET
			if(msg->getKind()==5)
			{
				//delete msg; // BORRAMOS EL AUTOMENSAJE YA QUE NO SE UTILIZA MAS ADELANTE
				if((int)par("numqueue") == 1)
				{
					//EV <<" TRABAJAMOS CON UN FUENTE SELF SIMILAR AL SOLO TENER UNA PRIORIDAD"<<endl;

// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2 ////////////////////////////////////////////////////////////////////

					Generator &AG=*pAG;
					AG.GetNextPacket();
					Trace trc= AG.PeekNextPacket();

					bytestamp_t tiempo=AG.GetTime();
					bytestamp_t ByteStamp= AG.GetByteStamp();
					bytestamp_t intervalo=ByteStamp-tiempo;

					// CALCULAMOS LA VARIABLE interarrivaltime A PARTIR DEL INTERVALO DETERMINADO EN BYTES
					simtime_t interarrivaltime = (simtime_t)(intervalo*8/wavelength_bit_rate);

					//CREAMOS PAQUETE ETHERNET PARA ENVIAR AL OLT
					ETHERNETmsg *packet = new ETHERNETmsg("ethernet");
					packet->setSrcAddress(srcAddress); // DIRECCIxN FUENTE O DE ORIGEN
					packet->setDestAddress(destAddress); // DIRECCIxN DE DESTINO
					packet->setByteLength(trc.PacketSize); // TAMAxO DEL PAQUETE ETHERNET
					packet->setPriority(priority); // PRIORIDAD DEL PAQUETE ETHERNET
					packet->setLambdaethernet(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE ETHERNET
					packet->setKind(1); // IDENTIFICADOR DEL PAQUETE ETHERNET
					packet->setId_servicio(getIndex());

					//VISUALIZAMOS POR PANTALLA LOS CAMPOS DEL PAQUETE ETHERNET
					//EV <<" Paquete Ethernet en ONU "<<packet->getSrcAddress()<<endl;
					/*EV <<" Origen ONU "<<packet->getSrcAddress()<<endl;
					EV <<" Destino OLT con ID "<<packet->getDestAddress()<<endl;
					EV <<" Prioridad: "<<packet->getPriority()<<endl;
					EV <<" Longitud de onda de envio, Lambda "<<packet->getLambdaethernet()<<endl;
					EV <<" Tamaño Paquete Ethernet: "<<packet->getByteLength()<<endl;
					EV <<" Tipo "<<packet->getKind()<<endl;
					EV <<" Identificador servicio P"<<packet->getId_servicio()<<endl;*/

					scheduleAt(simTime()+interarrivaltime,msg); //PROGRAMAMOS UN AUTOMENSAJE PARA EL INSTANTE SimTime()+interarrivalTime

					// CALCULAMOS LA SUMA TOTAL DEL TAMAxO DE LOS PAQUETES GENERADOS POR LA ONU EN BYTES Y LO VISUALIZAMOS POR PANTALLA
					suma_tam_packets = suma_tam_packets + trc.PacketSize;
					//EV <<" suma tamaño paquetes ONU "<<getParentModule()->getParentModule()->getIndex()<<": "<<suma_tam_packets<<"Bytes"<<endl;

					time_creation = simTime(); // TIEMPO DE CREACCIxN DEL PAQUETE ETHERNET

					// CALCULAMOS LA CARGA DEL NODO DE LA ONU Y LA VISUALIZAMOS POR PANTALLA CADA VEZ QUE SE GENERA UN PAQUETE ETHERNET
					total_load = suma_tam_packets*8/(SIMTIME_DBL(time_creation)*txrate); // FxRMULA PARA CALCULAR LA CARGA DEL NODO DE LA ONU
					//EV <<" Carga Total del Nodo de la ONU: "<<total_load<<endl;

					//RECOGIDA DE ESTADISTICAS DE LA CARGA TOTAL
					load_carga.analyze(total_load);

					totalpacket++; // SUMA TOTAL DE TODOS LOS PAQUETES CREADOS POR LA ONU

					if(packet->getByteLength()==64)
					{
						// PAQUETES CREADOS DE 64 BYTES
						packet_64++;
					}
					else if(packet->getByteLength()==594)
					{
						// PAQUETES CREADOS DE 594 BYTES
						packet_594++;
					}
					else if(packet->getByteLength()==1500)
					{
						// PAQUETES CREADOS DE 1500 BYTES
						packet_1500++;
					}

					// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA EL MxTODO DE INSERCIxN DE PAQUETES DE LAS COLAS
					switch(method)
					{
						case 0:
							//EV <<" Metodo de Colas Separadas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;
							//EV <<" Tamaño Colas Totales."<<endl;

							// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE ESTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
							for(int i=0; i<(int)par("numqueue"); i++)
							{
								cModule *c_onu_queue;
								c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
								onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
								//EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
							}
							separatequeue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE COLAS SEPARADAS
							break;

						case 1:
							//EV <<" Metodo de Prioridad de Colas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;

							// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
							for(int i=0; i<(int)par("numqueue"); i++)
							{
								cModule *c_onu_queue;
								c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
								onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
								//EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
							}
							priorityqueue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE PRIORIDAD DE COLAS
							break;

						default:
							EV <<" ERROR AL ELEGIR EL METODO DE COLAS, ELEGIR 0 x 1."<<endl;
							delete packet;
							break;
					}

// FINAL DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 ///////////////////////////////////////////////////////////////////////////
/*
					PacketGenerator &SRC=*pSRC;
					Packet pckt; // DEFINIMOS EL PAQUETE
					pckt = SRC.GetNextPacket(); // SIGUIENTE PAQUETE

					// CALCULAMOS LA VARIABLE interarrivaltime A PARTIR DEL INTERVALO DETERMINADO EN BYTES
					interarrivalTime = (simtime_t)(((double)pckt.Interval*8)/wavelength_bit_rate);

					//CREAMOS PAQUETE ETHERNET PARA ENVIAR AL OLT
					ETHERNETmsg *packet = new ETHERNETmsg("ethernet");
					packet->setSrcAddress(srcAddress); // DIRECCIxN FUENTE O DE ORIGEN
					packet->setDestAddress(destAddress); // DIRECCIxN DE DESTINO
					packet->setByteLength(pckt.PcktSize); // TAMAxO DEL PAQUETE ETHERNET
					packet->setPriority(priority); // PRIORIDAD DEL PAQUETE ETHERNET
					packet->setLambdaethernet(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE ETHERNET
					packet->setKind(1); // IDENTIFICADOR DEL PAQUETE ETHERNET
					packet->setId_servicio(getIndex());

					//VISUALIZAMOS POR PANTALLA LOS CAMPOS DEL PAQUETE ETHERNET
					EV <<" Paquete Ethernet "<<endl;
					EV <<" Origen ONU "<<packet->getSrcAddress()<<endl;
					EV <<" Destino OLT con ID "<<packet->getDestAddress()<<endl;
					EV <<" Prioridad: "<<packet->getPriority()<<endl;
					EV <<" Longitud de onda de envio, Lambda "<<packet->getLambdaethernet()<<endl;
					EV <<" Tamaño Paquete Ethernet: "<<packet->getByteLength()<<endl;
					EV <<" Tipo "<<packet->getKind()<<endl;
					EV <<" Identificador servicio P"<<packet->getId_servicio()<<endl;

					scheduleAt(simTime()+interarrivalTime,msg); //PROGRAMAMOS UN AUTOMENSAJE PARA EL INSTANTE SimTime()+interarrivalTime

					// CALCULAMOS LA SUMA TOTAL DEL TAMAxO DE LOS PAQUETES GENERADOS POR LA ONU EN BYTES Y LO VISUALIZAMOS POR PANTALLA
					suma_tam_packets = suma_tam_packets + pckt.PcktSize;
					EV <<" suma tamaño paquetes ONU "<<getParentModule()->getParentModule()->getIndex()<<": "<<suma_tam_packets<<"Bytes"<<endl;

					time_creation = simTime(); // TIEMPO DE CREACCIxN DEL PAQUETE ETHERNET

					// CALCULAMOS LA CARGA DEL NODO DE LA ONU Y LA VISUALIZAMOS POR PANTALLA CADA VEZ QUE SE GENERA UN PAQUETE ETHERNET
					total_load = suma_tam_packets*8/(SIMTIME_DBL(time_creation)*txrate); // FxRMULA PARA CALCULAR LA CARGA DEL NODO DE LA ONU
					EV <<" Carga Total del Nodo de la ONU: "<<total_load<<endl;

					//RECOGIDA DE ESTADISTICAS DE LA CARGA TOTAL
					load_carga.analyze(total_load);

					// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA EL MxTODO DE INSERCIxN DE PAQUETES DE LAS COLAS
					switch(method)
					{
						case 0:
							EV <<" Metodo de Colas Separadas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;
							EV <<" Tamaño Colas Totales."<<endl;

							// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE ESTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
							for(int i=0; i<(int)par("numqueue"); i++)
							{
								cModule *c_onu_queue;
								c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
								onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
								EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
							}
							separatequeue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE COLAS SEPARADAS
							break;

						case 1:
							EV <<" Metodo de Prioridad de Colas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;

							// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
							for(int i=0; i<(int)par("numqueue"); i++)
							{
								cModule *c_onu_queue;
								c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
								onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
								EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
							}
							priorityqueue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE PRIORIDAD DE COLAS
							break;

						default:
							EV <<" ERROR AL ELEGIR EL METODO DE COLAS, ELEGIR 0 x 1."<<endl;
							delete packet;
							break;
					}
*/
// FINAL DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 ////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				}
				else if((int)par("numqueue") >= 2)
				{
					if(getIndex() == 0)
					{
						EV <<" TRABAJAMOS CON UN FUENTE DE TASA CONSTANTE YA QUE TENEMOS UNA PRIORIDAD "<<getIndex()<<endl;

						// FUENTE CONSTANTE DE PAQUETES DE 70 BYTES QUE SE MANDAN DURANTE 125 MICROSEGUNDOS
						//CREAMOS PAQUETE ETHERNET PARA ENVIAR AL OLT
						ETHERNETmsg *packet = new ETHERNETmsg("ethernet");
						packet->setSrcAddress(srcAddress); // DIRECCIxN FUENTE O DE ORIGEN
						packet->setDestAddress(destAddress); // DIRECCIxN DE DESTINO
						packet->setByteLength(70); // TAMAxO DEL PAQUETE ETHERNET
						packet->setPriority(priority); // PRIORIDAD DEL PAQUETE ETHERNET
						packet->setLambdaethernet(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE ETHERNET
						packet->setKind(1); // IDENTIFICADOR DEL PAQUETE ETHERNET
						packet->setId_servicio(getIndex());

						//VISUALIZAMOS POR PANTALLA LOS CAMPOS DEL PAQUETE ETHERNET
						//EV <<" Paquete Ethernet ONU "<<packet->getSrcAddress()<<endl;
						/*EV <<" Origen ONU "<<packet->getSrcAddress()<<endl;
						EV <<" Destino OLT con ID "<<packet->getDestAddress()<<endl;
						EV <<" Prioridad: "<<packet->getPriority()<<endl;
						EV <<" Longitud de onda de envio, Lambda "<<packet->getLambdaethernet()<<endl;
						EV <<" Tamaño Paquete Ethernet: "<<packet->getByteLength()<<endl;
						EV <<" Tipo "<<packet->getKind()<<endl;
						EV <<" Identificador servicio P"<<packet->getId_servicio()<<endl;*/

						scheduleAt(simTime()+0.000125,msg); //PROGRAMAMOS UN AUTOMENSAJE PARA EL INSTANTE SimTime()+interarrivalTime

						// CALCULAMOS LA SUMA TOTAL DEL TAMAxO DE LOS PAQUETES GENERADOS POR LA ONU EN BYTES Y LO VISUALIZAMOS POR PANTALLA
						suma_tam_packets = suma_tam_packets + packet->getByteLength();
						//EV <<" suma tamaño paquetes ONU "<<getParentModule()->getParentModule()->getIndex()<<": "<<suma_tam_packets<<"Bytes"<<endl;

						time_creation = simTime(); // TIEMPO DE CREACCIxN DEL PAQUETE ETHERNET

						// CALCULAMOS LA CARGA DEL NODO DE LA ONU Y LA VISUALIZAMOS POR PANTALLA CADA VEZ QUE SE GENERA UN PAQUETE ETHERNET
						total_load = suma_tam_packets*8/(SIMTIME_DBL(time_creation)*txrate); // FxRMULA PARA CALCULAR LA CARGA DEL NODO DE LA ONU
						//EV <<" Carga Total del Nodo de la ONU: "<<total_load<<endl;

						//RECOGIDA DE ESTADISTICAS DE LA CARGA TOTAL
						load_carga.analyze(total_load);

						// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA EL MxTODO DE INSERCIxN DE PAQUETES DE LAS COLAS
						switch(method)
							{
								case 0:
									EV <<" Metodo de Colas Separadas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;
									EV <<" Tamaño Colas Totales."<<endl;

									// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE ESTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
									for(int i=0; i<(int)par("numqueue"); i++)
									{
										cModule *c_onu_queue;
										c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
										onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
										EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
									}
										separatequeue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE COLAS SEPARADAS
										break;

								case 1:
									//EV <<" Metodo de Prioridad de Colas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;

									// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
									for(int i=0; i<(int)par("numqueue"); i++)
									{
										cModule *c_onu_queue;
										c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
										onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
										//EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
									}
									priorityqueue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE PRIORIDAD DE COLAS
									break;

								default:
									EV <<" ERROR AL ELEGIR EL METODO DE COLAS, ELEGIR 0 x 1."<<endl;
									delete packet;
									break;
							}

					}
					else if(getIndex() >=1)
					{
						 //EV <<" TRABAJAMOS CON UN FUENTE SELF SIMILAR AL TENER LA PRIORIDAD "<<getIndex()<<" > QUE PRIORIDAD 0"<<endl;

// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2 //////////////////////////////////////////////////////////////////////////

						Generator &AG=*pAG;
						AG.GetNextPacket();
						Trace trc= AG.PeekNextPacket();

						bytestamp_t tiempo=AG.GetTime();
						bytestamp_t ByteStamp= AG.GetByteStamp();
						bytestamp_t intervalo=ByteStamp-tiempo;

						// CALCULAMOS LA VARIABLE interarrivaltime A PARTIR DEL INTERVALO DETERMINADO EN BYTES
						simtime_t interarrivaltime = (simtime_t)(intervalo*8/wavelength_bit_rate);

						//CREAMOS PAQUETE ETHERNET PARA ENVIAR AL OLT
						ETHERNETmsg *packet = new ETHERNETmsg("ethernet");
						packet->setSrcAddress(srcAddress); // DIRECCIxN FUENTE O DE ORIGEN
						packet->setDestAddress(destAddress); // DIRECCIxN DE DESTINO
						packet->setByteLength(trc.PacketSize); // TAMAxO DEL PAQUETE ETHERNET
						packet->setPriority(priority); // PRIORIDAD DEL PAQUETE ETHERNET
						packet->setLambdaethernet(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE ETHERNET
						packet->setKind(1); // IDENTIFICADOR DEL PAQUETE ETHERNET
						packet->setId_servicio(getIndex());

						//VISUALIZAMOS POR PANTALLA LOS CAMPOS DEL PAQUETE ETHERNET
						/*EV <<" Paquete Ethernet "<<endl;
						EV <<" Origen ONU "<<packet->getSrcAddress()<<endl;
						EV <<" Destino OLT con ID "<<packet->getDestAddress()<<endl;
						EV <<" Prioridad: "<<packet->getPriority()<<endl;
						EV <<" Longitud de onda de envio, Lambda "<<packet->getLambdaethernet()<<endl;
						EV <<" Tamaño Paquete Ethernet: "<<packet->getByteLength()<<endl;
						EV <<" Tipo "<<packet->getKind()<<endl;
						EV <<" Identificador servicio P"<<packet->getId_servicio()<<endl;*/

						scheduleAt(simTime()+interarrivaltime,msg); //PROGRAMAMOS UN AUTOMENSAJE PARA EL INSTANTE SimTime()+interarrivalTime

						// CALCULAMOS LA SUMA TOTAL DEL TAMAxO DE LOS PAQUETES GENERADOS POR LA ONU EN BYTES Y LO VISUALIZAMOS POR PANTALLA
						suma_tam_packets = suma_tam_packets + trc.PacketSize;
						//EV <<" Suma del Tamaño de los Paquetes de la Onu ONU "<<getParentModule()->getParentModule()->getIndex()<<": "<<suma_tam_packets<<"Bytes"<<endl;

						time_creation = simTime(); // TIEMPO DE CREACCIxN DEL PAQUETE ETHERNET

						// CALCULAMOS LA CARGA DEL NODO DE LA ONU Y LA VISUALIZAMOS POR PANTALLA CADA VEZ QUE SE GENERA UN PAQUETE ETHERNET
						total_load = suma_tam_packets*8/(SIMTIME_DBL(time_creation)*txrate); // FxRMULA PARA CALCULAR LA CARGA DEL NODO DE LA ONU
						//EV <<" Carga Total del Nodo de la ONU: "<<total_load<<endl;

						//RECOGIDA DE ESTADISTICAS DE LA CARGA TOTAL
						load_carga.analyze(total_load);

						totalpacket++; // SUMA TOTAL DE TODOS LOS PAQUETES CREADOS POR LA ONU

						if(packet->getByteLength()==64)
						{
							// PAQUETES CREADOS DE 64 BYTES
							packet_64++;
						}
						else if(packet->getByteLength()==594)
						{
							// PAQUETES CREADOS DE 594 BYTES
							packet_594++;
						}
						else if(packet->getByteLength()==1500)
						{
							// PAQUETES CREADOS DE 1500 BYTES
							packet_1500++;
						}

						// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA EL MxTODO DE INSERCIxN DE PAQUETES DE LAS COLAS
						switch(method)
						{
							case 0:
								EV <<" Metodo de Colas Separadas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;
								EV <<" Tamaño Colas Totales."<<endl;

								// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE ESTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
								for(int i=0; i<(int)par("numqueue"); i++)
								{
									cModule *c_onu_queue;
									c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
									onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
									EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
								}
								separatequeue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE COLAS SEPARADAS
								break;

								case 1:
									//EV <<" Metodo de Prioridad de Colas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;

									// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
									for(int i=0; i<(int)par("numqueue"); i++)
									{
										cModule *c_onu_queue;
										c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
										//onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
										//EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
									}
									priorityqueue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE PRIORIDAD DE COLAS
									break;

								default:
									EV <<" ERROR AL ELEGIR EL METODO DE COLAS, ELEGIR 0 x 1."<<endl;
									delete packet;
									break;
						}

// FINAL DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 2 /////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// INICIO DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 ////////////////////////////////////////////////////////////////////////
/*
						PacketGenerator &SRC=*pSRC;
						Packet pckt; // DEFINIMOS EL PAQUETE
						pckt = SRC.GetNextPacket(); // SIGUIENTE PAQUETE

						// CALCULAMOS LA VARIABLE interarrivaltime A PARTIR DEL INTERVALO DETERMINADO EN BYTES
						interarrivalTime = (simtime_t)(((double)pckt.Interval*8)/wavelength_bit_rate);

						//CREAMOS PAQUETE ETHERNET PARA ENVIAR AL OLT
						ETHERNETmsg *packet = new ETHERNETmsg("ethernet");
						packet->setSrcAddress(srcAddress); // DIRECCIxN FUENTE O DE ORIGEN
						packet->setDestAddress(destAddress); // DIRECCIxN DE DESTINO
						packet->setByteLength(pckt.PcktSize); // TAMAxO DEL PAQUETE ETHERNET
						packet->setPriority(priority); // PRIORIDAD DEL PAQUETE ETHERNET
						packet->setLambdaethernet(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE ETHERNET
						packet->setKind(1); // IDENTIFICADOR DEL PAQUETE ETHERNET
						packet->setId_servicio(getIndex());

						//VISUALIZAMOS POR PANTALLA LOS CAMPOS DEL PAQUETE ETHERNET
						EV <<" Paquete Ethernet "<<endl;
						EV <<" Origen ONU "<<packet->getSrcAddress()<<endl;
						EV <<" Destino OLT con ID "<<packet->getDestAddress()<<endl;
						EV <<" Prioridad: "<<packet->getPriority()<<endl;
						EV <<" Longitud de onda de envio, Lambda "<<packet->getLambdaethernet()<<endl;
						EV <<" Tamaño Paquete Ethernet: "<<packet->getByteLength()<<endl;
						EV <<" Tipo "<<packet->getKind()<<endl;
						EV <<" Identificador servicio P"<<packet->getId_servicio()<<endl;

						scheduleAt(simTime()+interarrivalTime,msg); //PROGRAMAMOS UN AUTOMENSAJE PARA EL INSTANTE SimTime()+interarrivalTime

						// CALCULAMOS LA SUMA TOTAL DEL TAMAxO DE LOS PAQUETES GENERADOS POR LA ONU EN BYTES Y LO VISUALIZAMOS POR PANTALLA
						suma_tam_packets = suma_tam_packets + pckt.PcktSize;
						EV <<" suma tamaño paquetes ONU "<<getParentModule()->getParentModule()->getIndex()<<": "<<suma_tam_packets<<"Bytes"<<endl;

						time_creation = simTime(); // TIEMPO DE CREACCIxN DEL PAQUETE ETHERNET

						// CALCULAMOS LA CARGA DEL NODO DE LA ONU Y LA VISUALIZAMOS POR PANTALLA CADA VEZ QUE SE GENERA UN PAQUETE ETHERNET
						total_load = suma_tam_packets*8/(SIMTIME_DBL(time_creation)*txrate); // FxRMULA PARA CALCULAR LA CARGA DEL NODO DE LA ONU
						EV <<" Carga Total del Nodo de la ONU: "<<total_load<<endl;

						//RECOGIDA DE ESTADISTICAS DE LA CARGA TOTAL
						load_carga.analyze(total_load);

						// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA EL MxTODO DE INSERCIxN DE PAQUETES DE LAS COLAS
						switch(method)
						{
							case 0:
								EV <<" Metodo de Colas Separadas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;
								EV <<" Tamaño Colas Totales."<<endl;

								// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE ESTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
								for(int i=0; i<(int)par("numqueue"); i++)
								{
									cModule *c_onu_queue;
									c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
									onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
									EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
								}
								separatequeue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE COLAS SEPARADAS
								break;

							case 1:
								EV <<" Metodo de Prioridad de Colas."<<" Tamaño Buffer Total: "<< buffer<<"Bytes"<<endl;

								// VISULAIZAMOS POR PANTALLA EL TAMAxO DE LAS COLAS ENTRANDO DESDE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y COMPROBANDO SU TAMAxO
								for(int i=0; i<(int)par("numqueue"); i++)
								{
									cModule *c_onu_queue;
									c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
									onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
									EV <<" Tamaño cola "<<i<<"-> "<<onu_queue->tamqueue[i]<<"Bytes"<<endl;
								}
								priorityqueue(packet); // LLAMADA A LA FUNCIxN DEL MxTODO DE INSERCIxN DE PAQUETES DE PRIORIDAD DE COLAS
								break;

							default:
								EV <<" ERROR AL ELEGIR EL METODO DE COLAS, ELEGIR 0 x 1."<<endl;
								delete packet;
								break;
						}
*/
// FINAL DE CxDIGO PARA LA FUENTE SELF SIMILAR VERSIxN 3 ////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					}
				}
			}
			break;

		default:
				delete msg;
				break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN SEPARATEQUEUE(cMessage *msg)--> FUNCIxN SE INVOCA CUANDO EL GENERADOR DE LA ONU CREA UN PAQUETE ETHERNET Y LO MANDA	//
//					HACIA LAS COLAS DONDE SE INSERTAN MIENTRAS SE LE ASIGNA UN ANCHO DE BANDA PARA TRANSMITIR.					//
//					ESTA FUNCIxN INSERTA LOS PAQUETES EN LA COLA CORRESPONDIENTE DESPUxS DE COMPROBAR SI HAY ESPACIO EN DICHAS 	//
//					COLAS, SINO HAY ESPACIO LIBRE BORRA EL PAQUETE GENERADO ANTES DE SER ENVIADO A LA COLA. EL TAMAxO DE LAS 	//
//					COLAS SE DEFINE MEDIANTE UN TAMAxO TOTAL DE BUFFER QUE SE REPARTE ENTRE EL NÚMERO DE COLAS QUE SE DEFINEN	//
//					EN LA RED. EL BUFFER SE MIDE EN BYTES.																							        //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_GENTraffic::separatequeue(cMessage *msg)
{
	// EJECUTAMOS EL MxTODO DE INSERCIxN DE COLAS SEPARADAS

	// VARIABLES
	double buffer = (double)par("tambuffer"); // TAMAxO TOTAL DEL BUFFER EN BYTES

	ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET

	// VARIABLES PARA PODER ENTRAR DESTE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIxN SOBRE LAS COLAS
	cModule *c_onu_queue;
	c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",ethernetmsg->getPriority());
	onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);

	// VISUALIZAMOS POR PANTALLA EL TAMAxO DE LA COLA DONDE INSERTAREMOS EL MENSAJE CREADO POR LA FUENTE
	EV <<" Tamaño de la Cola "<<ethernetmsg->getPriority()<<" donde insertamos paquete"<<"-> "<<onu_queue->tamqueue[ethernetmsg->getPriority()]<<"Bytes"<<endl;

	// COMPARAMOS SI EL TAMAxO DEL BUFFER PARA CADA COLA ES MAYOR O MENOR QUE EL TAMAxO DE LA COLA MxS EL TAMAxO DEL MENSAJE ETHERNET
	if(buffer/(int)par("numqueue") >= onu_queue->tamqueue[ethernetmsg->getPriority()] + ethernetmsg->getByteLength() )
	{
		EV <<" Como Tamaño total Cola "<<buffer/(int)par("numqueue")<<" >= "<<onu_queue->tamqueue[ethernetmsg->getPriority()] + ethernetmsg->getByteLength()<<". Enviamos Paquete."<<endl;
		send(ethernetmsg, "onugenOut", ethernetmsg->getPriority()); // EN ESTE CASO, ENVIAMOS EL PAQUETE ETHERNET HACIA LA COLA CORRESPONDIENTE
	}
	else if(buffer/(int)par("numqueue") < onu_queue->tamqueue[ethernetmsg->getPriority()] + ethernetmsg->getByteLength() )
	{
		EV <<" Como Tamaño total Cola "<<buffer/(int)par("numqueue")<<" < "<<onu_queue->tamqueue[ethernetmsg->getPriority()] + ethernetmsg->getByteLength()<<". Borramos Paquete. Cola LLena"<<endl;
		delete ethernetmsg; // EN ESTE CASO, BORRAMOS EL MENSAJE ETHERNET YA QUE NO SE PUEDE INSERTAR EN LA COLA AL ESTAR LLENA
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN PRIORITYQUEUE(cMessage *msg)--> FUNCIxN SE INVOCA CUANDO EL GENERADOR DE LA ONU CREA UN PAQUETE ETHERNET Y LO MANDA	//
//					HACIA LAS COLAS DONDE SE INSERTAN MIENTRAS SE LE ASIGNA UN ANCHO DE BANDA PARA TRANSMITIR.					//
//					ESTA FUNCIxN INSERTA LOS PAQUETES EN LA COLA CORRESPONDIENTE DESPUxS DE COMPROBAR SI HAY ESPACIO EN EL 		//
//					BUFFER TOTAL. SINO HAY ESPACIO LIBRE EN EL BUFFER, SE BORRA UN PAQUETE DE LA COLA DE PRIORIDAD MxS BAJA Y SE//
//					INSERTA EL PAQUETE EN LA COLA CORRESPONDIENTE. SI AL BORRAR EL PAQUETE DE LA COLA DE PRIORIDAD MENOR NO SE 	//
//					PUEDE INSERTAR EL PAQUETE GENERADO, Y EN LA COLA DE MENOR PRIORIDAD NO HAY MAS PAQUETES PARA ELIMINAR, SE 	//
//					BORRA UN PAQUETE DE LA COLA DE PRIORIDAD INMEDIATAMENTE SUPERIOR A LA MAS BAJA Y DESPUxS SE INSERTA EL 		//
//					PAQUETE SI YA HAY SITIO EN EL BUFFER. SI EL PAQUETE FUERA DE PRIORIDAD MENOR, SE BORRARIAN PAQUETES 		//
//					ANTERIORES DE DICHA COLA HASTA QUE SE PUEDA INSERTAR EL PAQUETE GENARADO.EL TAMAxO DEL BUFFER EN BYTES ES 	//
//					GLOBAL PARA	TODAS LAS COLAS YA QUE SE COMPARA CON LAS SUMA DE TODOS LOS PAQUETES GENERADOS EN BYTES.	    //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_GENTraffic::priorityqueue(cMessage *msg)
{
	// EJECUTAMOS EL MxTODO DE INSERCIxN DE PRIORIDAD DE COLAS

	// VARIABLES
	double buffer = (double)par("tambuffer"); // TAMAxO TOTAL DEL BUFFER EN BYTES

	ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET

	// VARIABLES PARA PODER ENTRAR DESTE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIxN SOBRE LAS COLAS
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		cModule *c_onu_queue;
		c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
		onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);
		suma_total[getIndex()] = suma_total[getIndex()] + onu_queue->tamqueue[i];

	}
	//EV <<" Suma de los Bytes de los Paquetes que estan insertados en todas las colas de la Red PON: "<<suma_total[getIndex()]<<endl;

	// DAMOS A LA VARIABLE tamsumqueue EL VALOR DE LA SUMA TOTAL DE LOS BYTES QUE HAY EN TODAS LAS COLAS MxS EL TAMAxx DEL MENSAJE QUE GENERA LA FUENTE
	tamsumqueue = suma_total[getIndex()] + ethernetmsg->getByteLength();

	// COMPARAMOS SI EL TAMAxO TOTAL DEL BUFFER ES MAYOR O MENOR QUE LA SUMA DEL TAMAxO DE TODOS LOS PAQUETES QUE LLEGAN A LAS COLAS
	if(buffer >= tamsumqueue)
	{
		//EV <<" Como Tamaño Total Buffer "<<buffer<<" >= "<<"Tamaño Suma Colas "<<tamsumqueue <<". Enviamos Paquete."<<endl;

		send(ethernetmsg, "onugenOut", ethernetmsg->getPriority()); // EN ESTE CASO, SE ENVIA EL PAQUETE ETHERNET HACIA LAS COLAS
	}
	else if(buffer < tamsumqueue)
	{
		// EN ESTE CASO, EL PAQUETE NO ENTRA EN LAS COLAS Y TENEMOS QUE ELIMINAR UNO DE MENOR PRIORIDAD PARA INSERTAR EL PAQUETE NUEV O
		// VISUALIZAMOS POR PANTALLA QUE EL TAMAxO DE LA SUMA DE LAS COLAS ES MAYOR QUE EL TAMAxO TOTAL DEL BUFFER
		//EV <<" Tamaño Total Buffer "<<buffer<<" < "<<"Tamaño Suma Colas "<<tamsumqueue <<"."<<endl;

		// COMPROBAMOS LAS COLAS MENOR A MAYOR PRIORIDAD PARA ELIMINAR UN PAQUETE ANTERIOR PARA INSERTAR EL NUEV O
		for(int i=(int)par("numqueue")-1; i>=0; i--)
		{
			// VARIABLES PARA PODER ENTRAR DESTE xSTE MxDULO AL MxDULO ONU_SISTQUEUE Y PODER OBTENER INFORMACIxN SOBRE LAS COLAS
			cModule *c_onu_queue;
			c_onu_queue = getParentModule()->getParentModule()->getSubmodule("onu_squeue")->getSubmodule("onu_sistqueue",i);
			onu_queue = check_and_cast<ONU_SISTqueue *>(c_onu_queue);

			// COMPARAMOS SI LA PRIORIDAD DEL PAQUETE QUE LLEGA ES LA MAS BAJA O ES DE MAYOR PRIORIDAD
			if(ethernetmsg->getPriority() == i)
			{
				// SI EL PAQUETE QUE LLEGA ES DE LA MENOR PRIORIDAD, DIRECTAMENTE SE BORRA
				//EV <<" Borramos el paquete que llega porque es de prioridad mas baja."<<endl;
				// RESTAMOS EL TAMAxO DEL PAQUETE QUE SE BORRA A LA SUMA DEL TAMAxO DE LOS PAQUETES QUE LLEGAN A LAS COLAS DE LA ONU Y LO VISUALIZAMOS POR PANTALLA
				//EV <<" Tamaño del Paquete que Borramos:"<<ethernetmsg->getByteLength()<<endl;
				tamsumqueue = tamsumqueue - ethernetmsg->getByteLength();
				//EV <<" Suma del Tamaño de las Colas -> "<<tamsumqueue<<"Bytes"<<endl;
				delete ethernetmsg; // BORRAMOS EL PAQUETE ETHERNET

				break; // SALIMOS DEL BUCLE FOR
			}
			else if(ethernetmsg->getPriority() < i && onu_queue->queue.getLength()>0)
			{
				// SI EL PAQUETE QUE LLEGA ES PRIORIDAD MAYOR QUE LA COLA EN LA QUE NOS ENCONTRAMOS.
				// SI ADEMxS EN NÚMERO DE PAQUETES DE xSTA COLA ES MAYOR QUE 0,
				// BORRAMOS PAQUETES HASTA QUE PODAMOS INSERTAR EL NUEV O PAQUETE

				// RECORREMOS TODOS LOS PAQUETES DE LA COLA DESDE EL MAS ANTIGUO PARA ELIMINARLOS Y PODER INSERTAR EL PAQUETE NUEV O
				for(int j=0; j<=onu_queue->queue.getLength(); j++)
				{
					// LLAMAMOS DE FORMA REMOTA A LA FUNCIxN ELIMINAR ELEMENTOS IMPLIMENTADA EN EL MxDULO ONU_SISTQUEUE
					onu_queue->deleteelement(ethernetmsg);

					// VISUALIZAMOS POR PANTALLA EL TAMAxO DEL PAQUETE QUE VAMOS A ELIMINAR
					//EV <<" Sacamos el mensaje con tamaño "<<onu_queue->tamqueuepop<<"Bytes de la cola "<<i<<" y borramos. Comprobamos si entra el mensaje que llego."<<endl;

					// RESTAMOS EL TAMAxO DEL PAQUETE QUE SACAMOS A LA SUMA DEL TAMAxO DE LOS PAQUETES QUE LLEGAN A LAS COLAS
					tamsumqueue = tamsumqueue - onu_queue->tamqueuepop;
					//EV <<" Tamaño Total de la Suma de las Colas-> "<<tamsumqueue<<"Bytes"<<endl;

					// SUMA DEL TAMAxO DE LOS S QUE SALEN DE LAS COLAS PARA RESTARSELO AL TAMAxO DE CADA COLA Y LO VISULAIZAMOS POR PANTALLA
					tamsumpop[i] = tamsumpop[i] + onu_queue->tamqueuepop;

					// COMPARAMOS SI EL TAMAxO TOTAL DEL BUFFER ES MAYOR QUE LA SUMA DEL TAMAxO DE LOS PAQUETES QUE LLEGAN A LAS COLAS DESPUxS DE RESTAR EL PAQUETE ELIMINADO
					if(buffer > tamsumqueue)
					{
						// SI HAY UN TAMAxO SUFICIENTE EN LA COLA PARA INSERTAR EL NUEV O PAQUETE, LO ENVIAMOS HACIA LAS COLAS
						//EV <<" Como Tamaño Total Buffer "<<buffer<<" > "<<"Tamaño Total Colas "<<tamsumqueue<<"Bytes"<<". Enviamos el paquete a la cola "<<ethernetmsg->getPriority()<<endl;

						send(ethernetmsg, "onugenOut", ethernetmsg->getPriority()); // ENVIAMOS EL PAQUETE ETHERNET HACIA LA COLA CORRESPONDIENTE
						break;// SALIMOS DEL BUCLE FOR QUE RECORRE LA COLA EN LA QUE ESTAMOS
					}
				}
				// COMPARAMOS SI EL TAMAxO TOTAL DEL BUFFER ES MAYOR QUE LA SUMA DEL TAMAxO DE LOS PAQUETES QUE LLEGAN A LAS COLAS DESPUxS DE RESTAR EL PAQUETE ELIMINADO
				if(buffer > tamsumqueue)
				{
					break; // SALIMOS DEL BUCLE FOR QUE RECORRE TODAS LAS COLAS
				}
			}
		}
	}

	// DAMOS EL VALOR CERO A LAS DOS VARIABLES PARA PODER HACER LO CALCULOS NECESARIOS EN SIGUIENTES SITUACIONES CORRECTAMENTE
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		suma_total[i] = 0;
	}
	tamsumqueue = 0;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN FINISH()--> ESTA FUNCIxN SE INVOCA CUANDO LA SIMULACIxN HA TERMINADO CON xXITO SIN QUE SE PRODUZCA NINGUN ERROR. 		//
//					  LO USAMOS PARA LA RECOGIDA DE ESTADxSTICAS Y VISUALIZACIxN POR PANTALLA O MEDIANTE UN ARCHIVO.            //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_GENTraffic::finish()
{
	// VISUALIZAMOS POR PANTALLA LA RECOGIDA DE ESTADISTICAS DE LA CARGA CUANDO LLAMAMOS A LA FUNCIxN FINISH()
	EV <<" Estadísticas tomadas en el Mxdulo ONU_GENTraffic"<<endl;
	EV <<" Carga del node de la ONU: "<<total_load<<endl;

	// RECOGIDA DE ESTADISTICAS Y LO GUARDAMOS LOS DATOS EN EL ARCHIVO CARGA_PAQUETES
	// SE PONE LA RUTA DONDE SE VAN A CREAR LOS ARCHIVOS
	carga_paquetes=fopen("results/carga_paquetes.txt", "a+"); // ABRIMOS EL ARCHIVO EN EL QUE GUARDAREMOS LOS RESULTADOS
		fprintf(carga_paquetes,"%g\t", (double)load_carga.average()); // CARGA DEL NODO DE LA ONU
		fprintf(carga_paquetes,"\n");
		fclose(carga_paquetes); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS

	// RECOGIDA DE ESTADISTICAS DE LOS PAQUETES GENERADOS Y LO GUARDAMOS LOS DATOS EN EL ARCHIVO PAQUETES
	// SE PONE LA RUTA DONDE SE VAN A CREAR LOS ARCHIVOS
	paquetes=fopen("results/paquetes.txt", "a+");
		fprintf(paquetes,"%li\t", totalpacket); // SUMA TOTAL DE PAQUETES GENERADOS
		fprintf(paquetes,"%li\t", packet_64); // PAQUETES GENERADOS DE 64 BYTES
		fprintf(paquetes,"%li\t", packet_594); // PAQUETES GENERADOS DE 594 BYTES
		fprintf(paquetes,"%li\t", packet_1500); // PAQUETES GENERADOS DE 1500 BYTES
		fprintf(paquetes,"\n");
		fclose(paquetes); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS
}
