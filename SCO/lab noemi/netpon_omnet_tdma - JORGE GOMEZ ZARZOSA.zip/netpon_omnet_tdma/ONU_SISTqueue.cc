////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TxTULO: Implementacixn de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERxA TxCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIxN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "ONU_SISTqueue.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"

// GENERAMOS EL CxDIGO Y LAS FUNCIONES DEL MxDULO SIMPLE
Define_Module(ONU_SISTqueue);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN INITIALIZE()--> ESTA FUNCIxN SE INVOCA DESPUxS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARxMETROS DEL MxDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MxDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINxMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MxDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_SISTqueue::initialize()
{
	queue.setName("queue"); // DEFINIMOS EL NOMBRE DE LA COLA

	// INICIALIZAMOS LAS VARIABLES AL VALOR 0
	tamqueuepop = 0; // VARIABLE DEL TAMAxO DE LOS PAQUETES QUE BORRAMOS DE LAS COLAS
	tamqueueextract = 0; // VARIABLE DEL TAMAxO DE LOS PAQUETES QUE CHEQUEAMOS ANTES DE SACARLOS DE LAS COLAS

	// RESERVAMOS TAMAxO PARA LA VARIABLE tamqueue Y LA INICIALIZAMOS AL VALOR 0
	tamqueue.resize((int)par("numqueue"),0); // VARIABLE DEL TAMAxO DE LOS PAQUETES QUE EXTRAEMOS DE LAS COLAS
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIxN SE INVOCA CON EL MENSAJE COMO PARxMETRO CADA VEZ QUE EL MxDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CxDIGO IMPLEMENTADO PARA DEVOLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIxN DENTRO DEL MxDULO SIMPLE. EL TIEMPO DE SIMULACIxN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CxDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_SISTqueue::handleMessage(cMessage *msg)
{
	// VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MxDULO
	switch(type)
	{
		case 1:
			// LLEGA UN PAQUETE ETHERNET CON IDENTIFICADOR = 1
			if(msg->getKind()==1)
			{

				ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET
				 //ev<< " Enviamos el paquete Ethernet."<< endl;

				 // SUMAMOS EL TAMAxO DE LOS PAQUETES QUE INSERTAMOS EN LAS COLAS
				 tamqueue[ethernetmsg->getPriority()] = tamqueue[ethernetmsg->getPriority()] + ethernetmsg->getByteLength();

				 // VEMOS EL TIEMPO EN EL QUE EL PAQUETE ETHERNET SE INSERTA EN LA COLA PARA DESPUxS CALCULAR EL RETARDO
				 // INTRODUCIMOS EN EL PAQUETE ETHERNET EL TIEMPO EN EL QUE EL PAQUETE SE INSERTA EN LA COLA
				 ethernetmsg->setTime_enter_queue(simTime());
				 //ev<<" Tiempo en el que se inserta el paquete ethernet en la cola: "<<ethernetmsg->getTime_enter_queue()<<endl;

				 queue.insert(ethernetmsg); // INSERTAMOS EL PAQUETE EN LA COLA QUE NOS INDIQUE LA PRIORIDAD DEL PAQUETE ETHERNET
			}
			break;

		case 2:
			// LLEGA UN PAQUETE REPORT CON IDENTIFICADOR = 2
			if(msg->getKind()==2)
			{
				REPORTmsg *reportmsg=check_and_cast<REPORTmsg*>(msg); // CHEQUEAMOS EL PAQUETE REPORT

				// ENVIAMOS EL PAQUETE REPORT HACIA EL MxDULO ONU_WDMSPLITTER Y VISUALIZAMOS POR PANTALLA CUANDO LO MANDAMOS
				send(reportmsg, "onuqueuewdmOut", reportmsg->getPriority());
				//EV << " Enviamos el paquete Report."<< endl;
			}
			break;

		default:
			delete msg;
			break;
	}


}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN DELETEELEMENT(CMESSAGE *MSG)--> ESTA FUNCIxN SE INVOCA CON EL MENSAJE COMO PARxMETRO CADA VEZ QUE EL MxDULO 			//
//					ONU_GENTraffic GENERA UN PAQUETE ETHERNET Y TIENE QUE INSERTARLO EN LA COLA Y NO HAY TAxANO SUFICIENTE PARA //
//					HACERLO Y TENEMOS QUE ELIMINAR MENSAJES ANTIGUOS PARA INSERTAR EL NUEVO PAQUETE CREADO.                     //
//					ESTA FUNCIxN EXTRAE UN PAQUETE QUE SE ENCONTRABA YA EN LA COLA Y LO ELIMINA, PERO ANTES OBTENEMOS EL 		//
//					TAMAxO DEL PAQUETE ETHERNET ELIMINADO PARA RESTARLO DEL TAMAxO TOTAL DE BYTES QUE TIENE ALMACENADO LA COLA	//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_SISTqueue::deleteelement(cMessage *msg)
{
	// FUNCIxN PARA ELIMINAR LOS PAQUETES DEL PRINCIPIO DE LAS COLAS

	ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET

	//ethernetmsg = (ETHERNETmsg *)queue.pop(); // EXTRAEMOS EL PRIMER PAQUETE ETHERNET QUE SE ENCUENTRA EN LA COLA

	// PARA ELIMINAR EL ULTIMO PAQUETE INSERTADO EN LAS COLAS
	ethernetmsg = (ETHERNETmsg *)queue.back();
	queue.remove(ethernetmsg);

	tamqueuepop = ethernetmsg->getByteLength(); // TAMAxO DEL PAQUETE ETHERNET EXTRAIDO DE LA COLA

	// RESTAMOS AL TAMAxO DE LA COLAS EL TAMAxO DEL PAQUETE QUE SE BORRA PARA PODER INSERTAR UN PAQUETE MAS ACTUAL
	tamqueue[ethernetmsg->getPriority()] = tamqueue[ethernetmsg->getPriority()] - tamqueuepop;
	delete ethernetmsg; // BORRAMOS EL PAQUETE ETHERNET
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN CHECKPACKET()--> ESTA FUNCIxN SE INVOCA CADA VEZ QUE EL MxDULO ONU_Rx_Report RECIBE UN PAQUETE REPORT. DE ESTA MANERA //
//					PODEMOS AVERIGUAR EL TAMAxO DEL PRIMER PAQUETE DE LA COLA SIN NECESIDAD DE EXTRAER EL PAQUETE ENCOLADO.		//
//					PARA OBTENER ESTA INFROMACIxN, ENTRAMOS EN LA COLA Y MEDIANTE LA FUNCIxN front() OBTENEMOS EL TAMAxO DEL 	//
//					PAQUETE QUE SE ENCUENTRA AL PRINCIPIO DE LA COLA Y LO INTRODUCIMOS EN UNA VARIABLE.							//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_SISTqueue::checkpacket()
{
	// FUNCIxN PARA CHUEQUEAR LOS PAQUETES DEL PRINCIPIO DE LA COLA PARA SABER SU TAMAxO EN BYTES

	ETHERNETmsg *ethernetmsg; // DEFINIMOS LA VARIABLE PARA EL PAQUETE ETHERNET
	ethernetmsg = (ETHERNETmsg *)queue.front(); // OBTENEMOS INFORMACIxN DEL PRIMER PAQUETE ETHERNET DE LA COLA SIN EXTRAERLO
	tamqueueextract = ethernetmsg->getByteLength(); // TAMAxO DEL PRIMER PAQUETE ETHERNET DE LA COLA SIN EXTRAERLO
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN EXTRACTIONELEMENT(int priority)--> ESTA FUNCIxN SE INVOCA CON LA PRIORIDAD DEL PAQUETE COMO PARxMETRO	CADA VEZ QUE EL	//
//					MxDULO ONU_Rx_Report RECIBE UN PAQUETE REPORT. DE ESTA MANERA PODEMOS EXTRAER EL PRIMER PAQUETE DE LA COLA Y//
//					ENVIARLE HACIA EL OLT.																						//
//					PRIMERAMENTE EXTRAEMOS EL PRIMER PAQUETE DE LA COLA CON LA FUNCIxN pop() Y METEMOS SU TAMAxO EN UNA VARIABLE//
//					PARA POSTERIORMENTE ACTUALIZAR EL TAMAxO DE LA COLA UNA VEZ SACADOS LOS PAQUETES PERTINENTES. DESPUxS LOS 	//
//					ENVIAMOS HACIA EL OLT POR LA SALIDA DEL MxDULO ONU_Rx_Report CORRESPONDIENTE.								//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_SISTqueue::extractionelement(int priority)
{
	// FUNCIxN PARA EXTRAER LOS PAQUETES DEL PRINCIPIO DE LAS COLAS

	ETHERNETmsg *ethernetmsg; // DEFINIMOS LA VARIABLE PARA EL PAQUETE ETHERNET
	take(ethernetmsg = (ETHERNETmsg *)queue.pop()); // EXTRAEMOS EL PRIMER PAQUETE QUE SE ENCUENTRA EN EL INICIO DE LA COLA
	tamextract = ethernetmsg->getByteLength(); // TAMAxO DEL PRIMER PAQUETE QUE SE ENCUENTRA EN EL INICIO DE LA COLA

	// RESTAMOS EL TAMAxO DEL PAQUETE QUE OBTUVIMOS EN LA FUNCIxN DE CHEQUEAR LOS PAQUETES AL TAMAxO DE LA COLA EN LA QUE EXTRAIGAMOS EL PAQUETE ETHERNET
	tamqueue[priority] = tamqueue[priority] - tamqueueextract;

	// ENVIAMOS EL PAQUETE ETHERNET HACIA EL MxDULO ONU_WDMSPLITTER
	send(ethernetmsg, "onuqueuewdmOut", priority);
}

void ONU_SISTqueue::finish()
{
}
