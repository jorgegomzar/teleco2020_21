////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////


/**
* @brief Provides the simulation analysis
* This class is used to analyze the simulation results.
*/
/***********************************************************/
//
// File:        analysis.h
// Aim:         Declaration of the required classes for
//              simulation analysis
// Authors:     Ignacio de Miguel Jimenez
//              David Rodriguez Alfayate
// Institution: University of Valladolid (Spain)
// E-mail:      ignacio.miguel@tel.uva.es
// Version:     1.1
//              21-Nov-00
// Translation to English: 2-Dec-10
/***********************************************************/

#ifndef __ANALYSIS_H
#define __ANALYSIS_H

#include <cstring>
#include <algorithm>
#include <cctype>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <sys/types.h>
#include <typeinfo>


#ifndef __MATH_H
#include <math.h>
#endif

#ifndef __STDLIB_H
#include <stdlib.h>
#endif

#ifndef __IOSTREAM_H
#include <iostream>
#endif

#ifndef __FSTREAM_H
#include <fstream>
#endif

#define NUM_BATCHES 400
#define EVEN 1
#define ODD 0

#define HALF 2

// By decreasing THRESHOLD and GAMMA more
// strict requirements are set in order to
// declare that the estimation of the parameter 
// has converged.
// Hence, by decreasing these values, simulations
// run longer but provide more accurate estimates of
// the averages and a smaller confidence interval
#define THRESHOLD   0.4
#define GAMMA    0.075

#define t_STUDENT        1.960

using namespace std;

/**
* @brief Provides the simulation analysis
* This class is used to analyze the simulation results.
* The method employed is that partially explained in the book:
*
* A.M. Law, W. Kelton, Simulation Modeling & Analysis, 
* 2nd ed. McGraw-Hill, 1991.
*
* and fully described in:
*
* A.M. Law, J.S. Carson, “A sequential procedure for 
* determining the length of a steady-state simulation”, 
* Operations Research, vol. 27, no. 5, pp. 1011-1025, 1979.
*
*/
class Analysis
{
	long double averages[2][NUM_BATCHES];	// It stores the averages with the result
						// of the analysis.
	long double rohat;			// Correlation.
	int position_batch[2];		// Posicion of the batch where we are
	int size_batch[2];		// Size of the batch
	int batch[2];			// Current batch
	long samples[2];		// Total samples per batch
	int iter;			// Number of iteration
	int converge;			// Converge or not.
	long double total_average;	// Average of all batches.
	long double numerator_sy2;	// Numerator used in calculation of conf. interval
	long Max_samples[2];   // Maximum number of samples in even and odd iterations
public:
	// IMPORTANT FUNCTIONS FOR THE USER OF THE CLASS
	Analysis();
	bool analyze(const long double &elem); // Add a sample of the parameter to analyze to the list.
	int converged() {return converge;}  // Returns 1 if the analysis of the parameter converged, 0 otherwise.
	long double average() {return total_average; } // Returns the average of the parameter
	long double half_confidence_interval() {
		// Returns half confidence interval
		// Thus, the result should be expressed as: 
		//       average() +- half_confidence_interval()
		return t_STUDENT*sqrt(numerator_sy2/(NUM_BATCHES*(NUM_BATCHES-1)));
	}
	int number_iterations() { return iter; }  // Returns the number of iterations
	void result();				// Prints the result of the analysis

	// OTHER FUNCTIONS
	long double value_rohat() {return rohat;} // Returns self-correlation
protected:
	void calculate_averages(int); // Calculates the averages of the batches
	int calculate_rohat(int,int x=1);	// Calculates the correlation
	long double calculate_ro(int,int,int);    // Calculates a first estimate of the correlation
	void average_from_to(int,int,int);  // Calculates the average of all averages
					   	// from 'from' to 'to'
	int check_gamma();	// Checks whether the threshold has been exceeded

	friend istream & operator>> (istream & ent, Analysis & anls);
	friend ostream & operator<< (ostream & sal, Analysis anls);

};

#endif

