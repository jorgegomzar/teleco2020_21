////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////


/***********************************************************/
//
// File:        analysis.cpp
// Aim:         Simulation analysis
// Authors:     Ignacio de Miguel Jimenez
//              David Rodriguez Alfayate
// Institution: University of Valladolid (Spain)
// E-mail:      ignacio.miguel@tel.uva.es
// Version:     1.1
//              21-Nov-00
// Translation to English: 2-Dec-10
/***********************************************************/

#include "analysis.h"

Analysis::Analysis()
{
	size_batch[EVEN]=3;
	size_batch[ODD]=2;
	converge=0;
	Max_samples[EVEN]=1200;
	Max_samples[ODD]=800;
	samples[EVEN]=0;
	samples[ODD]=0;
	position_batch[EVEN]=0;
	position_batch[ODD]=0;
	averages[EVEN][0]=0;
	averages[ODD][0]=0;
	batch[EVEN]=batch[ODD]=0;
	total_average=0;
	numerator_sy2=0;
	iter=0;
}
	
// This function implements the (approximately) simultaneous analysis of the
// samples that are being collected.
bool Analysis::analyze(const long double &elem)
{
	// elem is the element to analyze.
	// We calculate the averages corresponding to 
	// even and odd iterations
	bool finalized_iteration=0;
	long double rohatold;
	int end;
	averages[EVEN][batch[EVEN]]+=elem;
	averages[ODD][batch[ODD]]+=elem;
	position_batch[EVEN]+=1;
	position_batch[ODD]+=1;
	// We check whether we have completed any batch.
	if(position_batch[EVEN]==size_batch[EVEN]) {
		// We divide by the size of the batch:
		averages[EVEN][batch[EVEN]]/=size_batch[EVEN];
		// We increase the batch in one unit
		batch[EVEN]+=1;
		position_batch[EVEN]=0;
		if(batch[EVEN]<NUM_BATCHES) averages[EVEN][batch[EVEN]]=0; // We put this element to 0.
	}
	if(position_batch[ODD]==size_batch[ODD]) {
		averages[ODD][batch[ODD]]/=size_batch[ODD];
		batch[ODD]+=1;
		position_batch[ODD]=0;
		if(batch[ODD]<NUM_BATCHES) averages[ODD][batch[ODD]]=0;
	}
	samples[EVEN]+=1;
	samples[ODD]+=1;

	// We check whether we have reached the maximum number of samples
	// that made the block that we are analyzing.
	if(samples[EVEN]==Max_samples[EVEN]) {
		// End of the batch. 
		iter++;
		calculate_rohat(EVEN);
		// The number of samples for the next even iteration is
		// twice the current number:
		Max_samples[EVEN]*=2;
		size_batch[EVEN]=Max_samples[EVEN]/NUM_BATCHES;
		calculate_averages(EVEN); // Comment 1. /* <1> */
		// We have to divide by 2 the batch where we are
		batch[EVEN]/=2;
		averages[EVEN][batch[EVEN]]=0;
		// We check the calculated value of the correlation.
		if(rohat<=0) {
			// If we are below the confidence threshold, everything is OK
			if(check_gamma()) {
				end=1;
			}
			else end=0;
		}
		else {
			if(0<rohat && rohat<THRESHOLD) {
				// We have to reorganized the array with the averages.
				// The first half of the array must contain averages of 2*l samples
				// Regarding the second half, it does not matter.
				/* <1> */
				// But this operation has to be done for the next even block
				// and that is why we do it at the beggining of the check
				// and we earn time. Comment 1.
				// So, we only have to check the correlation
				rohatold=rohat;	
				calculate_rohat(EVEN,HALF); // But only of the first half
							    // of the averages.
				if(rohat<rohatold && check_gamma()) {
					// Confidence threshold, we have finished the task.
					end=1;
				}
				else end=0;
			}
			else end=0;
		}
		cout << "Iteration: " << iter << "\n";
		cout << "   -> Result: "; result(); cout << "\n";
	        finalized_iteration=1;
		// If end equals to 1, we have finished the task,
		// so that we set converge to 1 and return to the calling program.
		if(end) {
			converge=1;
			return finalized_iteration;
		}
	}
	// Now, exactly the same procedure but for the ODD iteration
	if(samples[ODD]==Max_samples[ODD]) {
		iter++;
		calculate_rohat(ODD);
		Max_samples[ODD]*=2;
		size_batch[ODD]=Max_samples[ODD]/NUM_BATCHES;
		calculate_averages(ODD);
		batch[ODD]/=2;
		averages[ODD][batch[ODD]]=0;
		if(rohat<=0) {
			if(check_gamma()) {
				end=1;
			}
			else end=0;
		}		
		else {
			if(0<rohat && rohat<THRESHOLD) {
				rohatold=rohat;
				calculate_rohat(ODD,HALF);
				if(rohat<rohatold && check_gamma()) {
					end=1;
				}
				else end=0;
			}
			else end=0;
		}
		cout << "Iteration: " << iter << "\n";
		cout << "   -> Result: "; result(); cout << "\n";
	        finalized_iteration=1;
		if(end) {
			converge=1;
			return finalized_iteration;
		}
	}
	return finalized_iteration;
}

void Analysis::calculate_averages(int iteration)
{
	// The iteration parameter indicates whether we are
	// in an EVEN or ODD operation.
	register int i;
	register int k=0;
	// Special case
	for(i=0;i<NUM_BATCHES/2;i++) {
		// As it can be seen, we go from 2 blocks in 2 blocks
		averages[iteration][i]=averages[iteration][k]+averages[iteration][k+1];
		averages[iteration][i]/=2;
		k+=2;
	}
	return;
}

int Analysis::calculate_rohat(int iteration,int which_part)
{
	// The iteration parameter tells us whether we work with even
	// or odd iterations. The which_part parameter tells us
	// whether we are going to deal with all the batches (NUM_BATCHES)
	// or only with half of them
	int number_batches=NUM_BATCHES/which_part;
	rohat=-0.5*(calculate_ro(iteration,number_batches,1)+calculate_ro(iteration,number_batches,2))+2*calculate_ro(iteration,number_batches,0);
	return 1;
	// The imposed order is crution in order to keep the correct value
	// of parameters such as total_average
}

long double Analysis::calculate_ro(int iteration,int number_batches,int indicator)
{
	int from=0;
	int to=number_batches;
	long double numerator=0;
	long double denominator=0;
	long double old=0;
	long double aux=0;
	register int i;
	switch (indicator) {
		case 1:
			to >>= 1;
			break;
		case 2:
			from = number_batches >> 1;
			break;
	}
	// We introduce in total_average the average value of the averages
	// by means of the average_from_to function.
	average_from_to(iteration,from,to);
	denominator=old=averages[iteration][from]-total_average;
	denominator*=denominator;
	for(i=from+1;i<=to-1;i++) {
		aux=averages[iteration][i]-total_average;
		numerator+=old*aux;
		denominator+=aux*aux;
		old=aux;
	}
	numerator_sy2=denominator;
	if(!denominator) {
		return 0;
	}
	numerator/=denominator;
	return numerator;
}

void Analysis::average_from_to(int iteration,int from, int to)
{
	register int i=0;
	total_average=0;
	for(i=from;i<to;i++) {
		total_average+=averages[iteration][i];
	}
	total_average/=(to-from);
}	

int Analysis::check_gamma()
{
	long double delta;
	delta=t_STUDENT*sqrt(numerator_sy2/(NUM_BATCHES*(NUM_BATCHES-1)));
	if(total_average==0) {
		return 0; // If the total average is 0 we say that it has NOT converged.
			// (This is required for evaluating, e.g., low blocking probabilities,
			// we force the simulation to continue running even if we have
			// a long sequence of samples being 0.)
	}
	delta/=fabs(total_average);
	// We compare delta with the gamma threshold.
	if(delta>GAMMA) return 0;
	// If we get to this point, the gamma threshold has been exceeded.
	return 1;
}

void Analysis::result()
{
	cout << total_average << "+-" << t_STUDENT*sqrt(numerator_sy2/(NUM_BATCHES*(NUM_BATCHES-1)));
}	

istream & operator >> (istream & ent, Analysis & anls)
{
	return ent;
}

ostream & operator << (ostream & sal, Analysis anls)
{
	return sal;
}
