////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_ONU_TABLE_H_
#define __REDPON_ONU_TABLE_H_

#include <omnetpp.h>
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
using namespace omnetpp;

//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES Y MATRICES
typedef std::vector<int> int_vector_t; // VECTOR TIPO ENTERO
typedef std::vector<simtime_t> simtime_t_vector_t; // VECTOR TIPO TIEMPO
typedef std::vector<double> double_vector_t; // VECTOR TIPO DOUBLE
typedef std::vector< int_vector_t > int_matrix_t; // MATRIZ DE TIPO ENTERO

class ONU_Table : public cSimpleModule
{
	public:
		double_vector_t table_onu_gate; // VECTOR DE TIPO DOUBLE PARA GUARDAR EL ANCHO DE BANDA DE SLOT
		simtime_t_vector_t table_onu_gate_time; // VECTOR DE TIPO TIEMPO PARA GUARDAR EL TIEMPO DE INICIO DE TRANSMISIÓN

		int numInitStages() const; // FUNCIÓN QUE INICIALIZA VARIAS ETAPAS.

  	protected:
    	 void initialize(int stage);
    	 void handleMessage(cMessage *msg);
};

#endif
