////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "ONU_Rxuser.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"

// GENERAMOS EL CÓDIGO Y LAS FUNCIONES DEL MÓDULO SIMPLE
Define_Module(ONU_Rxuser);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN INITIALIZE()--> ESTA FUNCIÓN SE INVOCA DESPUÉS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARÁMETROS DEL MÓDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MÓDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINÁMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MÓDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Rxuser::initialize()
{
	nombreonu = getParentModule()->getIndex(); // IDENTIFICADOR DE LA ONU
	numReceived = 0; // INICIALIZAMOS EL NÚMERO DE PAQUETES ETHERNET RECIBIDOS A 0
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIÓN SE INVOCA CON EL MENSAJE COMO PARÁMETRO CADA VEZ QUE EL MÓDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CÓDIGO IMPLEMENTADO PARA DEVOLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIÓN DENTRO DEL MÓDULO SIMPLE. EL TIEMPO DE SIMULACIÓN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CÓDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Rxuser::handleMessage(cMessage *msg)
{
	// VARIABLES
	simtime_t eed;

	// RECOGIDA DE ESTADISTICAS MANUALMENTE
	eed = simTime() - msg->getCreationTime(); // PARÁMETRO PARA CALCULAR EL RETARDO EXTREMO A EXTREMOS MANUALMENTE
	eedStats.collect(eed); // RECOGEMOS EL RESULTADO

	ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET

	// VISUALIZAMOS POR PANTALLA CUANDO RECIBIMOS EL PAQUETE ETHERNET
	EV <<" Paquete " << msg << " recibido y borrado."<<endl;

	numReceived++; // INCREMENTAMOS EN UNO EL CONTADOR DE NÚMERO DE PAQUETES ETHERNET RECIBIDOS

	delete ethernetmsg; // BORRAMOS EL MENSAJE ETHERNET
}

void ONU_Rxuser::finish()
{
	// VISUALIZAMOS POR PANTALLA LA RECOGIDA DE ESTADISTICAS DE ESTE MÓDULO DE CUANDO LLAMAMOS A LA FUNCIÓN FINISH()
	EV << " ONU " << nombreonu << endl;
	EV << " Estadísticas en el ONU_Rxuser para paquetes Ethernet"<<endl;
	EV << " Retardo medio: " << eedStats.getMean() << endl;
	EV << " Paquetes Ethernet Totales Recibidos: " << numReceived << endl;

}
