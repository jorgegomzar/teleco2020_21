////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "OLT_WDMSplitter.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"

// GENERAMOS EL CÓDIGO Y LAS FUNCIONES DEL MÓDULO SIMPLE
Define_Module(OLT_WDMSplitter);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN INITIALIZE()--> ESTA FUNCIÓN SE INVOCA DESPUÉS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARÁMETROS DEL MÓDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MÓDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINÁMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MÓDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void OLT_WDMSplitter::initialize()
{
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIÓN SE INVOCA CON EL MENSAJE COMO PARÁMETRO CADA VEZ QUE EL MÓDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CÓDIGO IMPLEMENTADO PARA DEVOLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIÓN DENTRO DEL MÓDULO SIMPLE. EL TIEMPO DE SIMULACIÓN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CÓDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void OLT_WDMSplitter::handleMessage(cMessage *msg)
{
	// VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED
	int p= gateSize("wdmnet"); // TAMAÑO DE LA PUERTA wdmnet DEL MÓDULO OLT_WDMSPLITTER

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MÓDULO
	switch(type)
	{
		case 0:
			// LLEGA UN PAQUETE GATE CON IDENTIFICADOR = 0
			if(msg->getKind()==0)
			{
				GATEmsg *gatemsg=check_and_cast<GATEmsg*>(msg); // CHEQUEAMOS EL PAQUETE GATE

				// ENVIAMOS EL PAQUETE GATE HACIA EL SPLITTER POR LA LONGITUD DE ONDA QUE NOS INDICA EL PAŔAMETRO gatemsg->getLambdagate()
				send(gatemsg, "wdmnet$o", gatemsg->getLambdagate());
			}
			break;

		case 1:
			// LLEGA UN PAQUETE ETHERNET CON IDENTIFICADOR = 1
			if(msg->getKind()==1)
			{
				// DEFINIMOS EL PARÁMETRO ingate QUE NOS INDICA EL PUNTERO DE LA PUERTA POR LA CUAL ENTRA EL MENSAJE QUE LLEGA
				cGate *ingate = msg->getArrivalGate();

				// COMPARAMOS EL NOMBRE DE LA PUERTA POR LA QUE ENTRA EL MENSAJE CON LA PUERTA wdmnet$i
				if(ingate->getName() == gate("wdmnet$i",intuniform(0,p-1))->getName())
				{
					send(msg, "wdmrxOut"); // ENVIAMOS EL PAQUETE ETHERNET HACIA EL RECEPTOR
				}
				else
				{
					ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET

					// ENVIAMOS EL PAQUETE ETHERNET HACIA EL SPLITTER POR LA LONGITUD DE ONDA QUE NOS INDICA EL PAŔAMETRO ethernetmsg->getLambdaethernet()
					send(ethernetmsg, "wdmnet$o", ethernetmsg->getLambdaethernet());
				}
			}
			break;

		case 2:
			// LLEGA UN PAQUETE REPORT CON IDENTIFICADOR = 2
			if(msg->getKind()==2)
			{
				send(msg, "wdmrxOut"); // ENVIAMOS EL PAQUETE REPORT HACIA EL RECEPTOR DEL OLT
			}
			break;

		default:
			delete msg;
			break;
	}
}
