////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_ONU_WDMSPLITTER_H_
#define __REDPON_ONU_WDMSPLITTER_H_

#include <omnetpp.h>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "analysis.h"
#include <vector>
using namespace omnetpp;

//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES
typedef std::vector<int> int_vector_t;
typedef std::vector<double> double_vector_t; // VECTOR DE TIPO DOUBLE
typedef std::vector<simtime_t> simtime_t_vector_t; // VECTOR DE TIPO TIEMPO

class ONU_WDMSplitter : public cSimpleModule
{
  protected:

	cStdDev time_cycles; // PARÁMETRO DE ESTADISTICAS DEFINIDO PARA OBTENERLAS MANUALMENTE
	Analysis tiempo_ciclos; // DEFININOS EL PARÁMETRO PARA LA CLASE ANÁLISIS
	FILE * tiempo_entre_ciclos; // ARCHIVO DONDE SE GUARDARAN LOS RESULTADOS DE LA CLASE ANÁLISIS

	simtime_t timepacketethernet; // VARIABLE QUE CONTIENE EL TIEMPO EN EL QUE SE ENVIARÁ EL PAQUETE ETHERNET
	simtime_t time_report; // VARIABLE QUE CONTIENE EL TIEMPO EN EL QUE SE ENVIA EL PAQUETE REPORT
	simtime_t time_gate; // VARIABLE QUE CONTIENE EL TIEMPO EN EL QUE LLEGA EL PAQUETE GATE A LA ONU

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);


    virtual void finish(); // DEFINICIÓN DE LA FUNCIÓN FINALIZAR


};

#endif
