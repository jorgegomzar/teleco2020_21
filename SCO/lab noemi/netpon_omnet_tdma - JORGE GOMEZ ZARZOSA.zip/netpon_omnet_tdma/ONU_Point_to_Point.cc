////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "ONU_Point_to_Point.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"

// GENERAMOS EL CÓDIGO Y LAS FUNCIONES DEL MÓDULO SIMPLE
Define_Module(ONU_Point_to_Point);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN INITIALIZE()--> ESTA FUNCIÓN SE INVOCA DESPUÉS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARÁMETROS DEL MÓDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MÓDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINÁMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MÓDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Point_to_Point::initialize()
{
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIÓN SE INVOCA CON EL MENSAJE COMO PARÁMETRO CADA VEZ QUE EL MÓDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CÓDIGO IMPLEMENTADO PARA DEV OLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIÓN DENTRO DEL MÓDULO SIMPLE. EL TIEMPO DE SIMULACIÓN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CÓDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Point_to_Point::handleMessage(cMessage *msg)
{
	// VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MÓDULO
	switch(type)
	{
		case 0:
			// LLEGA UN PAQUETE GATE CON IDENTIFICADOR = 0
			if(msg->getKind()==0)
			{
				GATEmsg *gatemsg = check_and_cast<GATEmsg *>(msg); // CHEQUEAMOS EL PAQUETE GATE

				// VISUALIZAMOS ALGUNOS CAMPOS DEL PAQUETE GATE
				EV <<" Paquete Gate Recibido."<<endl;
				EV <<" Direccion de destino: "<<gatemsg->getDestAddress()<<endl;
				EV <<" Mi ID es: "<<getParentModule()->getIndex()<<endl;

				// COMPARAMOS SI EL IDENTIFICADOR DE LA ONU EN LA QUE NOS ENCONTRAMOS ES IGUAL A LA DIRECCIÓN DE DESTINO QUE CONTIENE EL PAQUETE GATE
				if(getParentModule()->getIndex()==gatemsg->getDestAddress())
				{
					EV <<" El paquete Gate recibido es para esta ONU, pasa a la capa MAC."<<endl;
					send(gatemsg, "onuptpmacOut"); // SI EL PAQUETE ES PARA ESTA ONU, SE ENVIA HACIA LA CAPA MAC DE LA ONU
				}
				else
				{
					EV <<" Este paquete Gate no es para esta ONU, Eliminando."<<endl;
					delete gatemsg; // EN ESTE CASO, COMO EL PAQUETE GATE NO ES PARA ESTA ONU, ELIMINAMOS EL PAQUETE GATE
				}
			}
			break;

		case 1:
			// LLEGA UN PAQUETE ETHERNET CON IDENTIFICADOR = 1
			if(msg->getKind()==1)
			{
				ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET

				// VISUALIZAMOS ALGUNOS CAMPOS DEL PAQUETE ETHERNET
				EV <<" Paquete Ethernet Recibido."<<endl;
				EV <<" Direccion de destino: "<<ethernetmsg->getDestAddress()<<endl;
				EV <<" Mi ID es: "<<getParentModule()->getIndex()<<endl;

				// COMPARAMOS SI EL IDENTIFICADOR DE LA ONU EN LA QUE NOS ENCONTRAMOS ES IGUAL A LA DIRECCIÓN DE DESTINO QUE CONTIENE EL PAQUETE ETHERNET
				if(getParentModule()->getIndex()==ethernetmsg->getDestAddress())
				{
					EV <<" El paquete Ethernet recibido es para esta ONU, pasa a la capa MAC."<<endl;
					send(ethernetmsg, "onuptpmacOut"); // SI EL PAQUETE ES PARA ESTA ONU, SE ENVIA HACIA LA CAPA MAC DE LA ONU
				}
				else
				{
					EV <<" Este paquete Ethernet no es para esta ONU, Eliminando."<<endl;
					delete ethernetmsg; // EN ESTE CASO, COMO EL PAQUETE ETHERNET NO ES PARA ESTA ONU, ELIMINAMOS EL PAQUETE ETHERNET
				}
			}
			break;

		default:
			delete msg;
			break;
	}
}

