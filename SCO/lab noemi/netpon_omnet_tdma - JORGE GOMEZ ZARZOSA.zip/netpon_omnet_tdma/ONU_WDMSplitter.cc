////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TxTULO: Implementacixn de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERxA TxCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIxN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "ONU_WDMSplitter.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include <vector>
#include "analysis.h"
#include <string.h>
#include <stdio.h>

// GENERAMOS EL CxDIGO Y LAS FUNCIONES DEL MxDULO SIMPLE
Define_Module(ONU_WDMSplitter);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN INITIALIZE()--> ESTA FUNCIxN SE INVOCA DESPUxS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARxMETROS DEL MxDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MxDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINxMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MxDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_WDMSplitter::initialize()
{
	// RECOGIDA DE ESTADISTICAS DE TIEMPO ENTRE CICLOS MANUALMENTE
	time_cycles.setName("Tiempo entre ciclos");

	// INICIALIZAMOS VARIABLES AL VALOR 0
	timepacketethernet = 0; // TIEMPO EN EL QUE SE ENVIARx EL PAQUETE ETHERNET
	time_report = 0; // TIEMPO EN EL QUE SE ENVIA EL PAQUETE REPORT
	time_gate = 0; // TIEMPO EN EL QUE LLEGA EL PAQUETE GATE A LA ONU

	// CxDIGO PARA MODIFICAR EL DELAY DEL CANAL QUE UNE EL SPLITTER Y LAS ONUS
	if((int)par("methodlength_longvariable0_longfija1")==0)
	{
		cTopology topo; // DEFINIMOS UN PARxMETRO DE LA TOPOLOGIA DE LA RED
		topo.extractByParameter( "numlong" ); // EXTRAEMOS LOS NODOS DE NUESTRA RED QUE UTILIZAN EL PARxMETRO numlong
		// PARA VISUALIZAR LOS NODOS DE LA TOPOLOGxA Y SUS CONEXIONES
		//for (int i=0; i<topo.getNumNodes(); i++)
		//{
		// cTopology::Node *node = topo.getNode(i);
		//  EV  << "Node i=" << i << " is " << node->getModule()->getFullPath() << endl;
		//  EV  << " It has " << node->getNumOutLinks() << " conns to other nodes\n";
		//  EV  << " and " << node->getNumInLinks() << " conns from other nodes\n";

		//  EV  << " Connections to other modules are:\n";
		//	for (int j=0; j<node->getNumOutLinks(); j++)
		//	{
		//	  cTopology::Node *neighbour = node->getLinkOut(j)->getRemoteNode();
		//	  cGate *gate = node->getLinkOut(j)->getLocalGate();
		//	  EV  << " " << neighbour->getModule()->getFullPath()
		//		 << " through gate " << gate->getFullName() << endl;
		//	}

		//	}

		// DEFINIMOS EL PARxMETRO MODULE QUE NOS INDICA EL CAMINO HASTA EL NODO DEL QUE QUEREMOS OBTENER INFORMACIxN
		cModule *module = getParentModule()->getParentModule()->getSubmodule("onu", getParentModule()->getIndex());
		double delay = intuniform(0,10)*1000*0.000000005; // CALCULAMOS EL RETARDO DEL SEGMENTO QUE UNA EL SPLITTER CON LA ONU MEDIANTE DISTANCIAS ALEATORIAS ENTE 0 Y 10 KM

		cTopology::Node *nodeonuOut = topo.getNodeFor(module);  // NOMBRE DEL NODO QUE SACAMOS DEL GRAFO
		// RECORREMOS CON EL BUCLE FOR TODOS LOS ENLACES DE SALIDA QUE TIENE ESE NODO PARA OBTENER LA INFORMACIxN QUE SOLICITAMOS
		for(int j=0; j<nodeonuOut->getNumOutLinks(); j++)
		{
			// OBTENEMOS EL VALOR DEL RETARDO QUE HAY EN EL CANAL QUE PASA POR EL NODO EN EL QUE OBTENEMOS LA INFORMACIxN Y LO VISUALIZAMOS POR PANTALLA
			SIMTIME_DBL((check_and_cast<cDelayChannel*>(nodeonuOut->getLinkOut(j)->getLocalGate()->getChannel()))->getDelay());
			EV <<" Delay del canal descendente antes de Inicializar: "<<SIMTIME_DBL((check_and_cast<cDelayChannel*>(nodeonuOut->getLinkOut(j)->getLocalGate()->getChannel()))->getDelay())<<endl;

			// INTRODUCIMOS EL NUEV O VALOR DEL RETARDO DEL CANAL  Y LO VISUALIZAMOS POR PANTALLA
			(check_and_cast<cDelayChannel*>(nodeonuOut->getLinkOut(j)->getLocalGate()->getChannel()))->setDelay(delay);
			EV <<" NuEV o Delay del canal descendente: "<<(check_and_cast<cDelayChannel*>(nodeonuOut->getLinkOut(j)->getLocalGate()->getChannel()))->getDelay()<<endl;
		}

		cTopology::Node *nodeonuIn = topo.getNodeFor(module);  // NOMBRE DEL NODO QUE SACAMOS DEL GRAFO
		// RECORREMOS CON EL BUCLE FOR TODOS LOS ENLACES DE ENTRADA QUE TIENE ESE NODO PARA OBTENER LA INFORMACIxN QUE SOLICITAMOS
		for(int j=0; j<nodeonuIn->getNumInLinks(); j++)
		{
			// OBTENEMOS EL VALOR DEL RETARDO QUE HAY EN EL CANAL QUE PASA POR EL NODO EN EL QUE OBTENEMOS LA INFORMACIxN Y LO VISUALIZAMOS POR PANTALLA
			SIMTIME_DBL((check_and_cast<cDelayChannel*>(nodeonuIn->getLinkIn(j)->getRemoteGate()->getChannel()))->getDelay());
			EV <<" Delay del canal ascendente antes de Inicializar: "<<SIMTIME_DBL((check_and_cast<cDelayChannel*>(nodeonuIn->getLinkIn(j)->getRemoteGate()->getChannel()))->getDelay())<<endl;

			// INTRODUCIMOS EL NUEV O VALOR DEL RETARDO DEL CANAL  Y LO VISUALIZAMOS POR PANTALLA
			(check_and_cast<cDelayChannel*>(nodeonuIn->getLinkIn(j)->getRemoteGate()->getChannel()))->setDelay(delay);
			EV <<" NuEV o Delay del canal ascendente: "<<(check_and_cast<cDelayChannel*>(nodeonuIn->getLinkIn(j)->getRemoteGate()->getChannel()))->getDelay()<<endl;
		}
	}
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIxN SE INVOCA CON EL MENSAJE COMO PARxMETRO CADA VEZ QUE EL MxDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CxDIGO IMPLEMENTADO PARA DEV OLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIxN DENTRO DEL MxDULO SIMPLE. EL TIEMPO DE SIMULACIxN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CxDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_WDMSplitter::handleMessage(cMessage *msg)
{
	// VARIABLES
	simtime_t comprobar_tiempo_ciclos; // VARIABLE QUE INDICA EL TIEMPO QUE SE PIERDE ENTRE EL FINAL Y EL PRINCIPIO DE UN CICLO
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED
	double txrate = (int)par("txrate"); // TASA DE TRANSMISIxN EN BITS POR SEGUNDO
	int p= gateSize("wdmnet"); // TAMAxO DE LA PUERTA wdmnet DEL MxDULO ONU_WDMSPLITTER

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MxDULO
	switch(type)
	{
		case 0:
			// LLEGA UN PAQUETE GATE CON IDENTIFICADOR = 0
			if(msg->getKind()==0)
			{
				GATEmsg *gatemsg=check_and_cast<GATEmsg*>(msg); // CHEQUEAMOS EL PAQUETE GATE

				// VEMOS SI SE CUMPLEN LAS TRES IGUALDADES PARA QUE SE EJECUTE LA FUNCIxN:
				// SI EL IDENTIFICADOR DE LA DIRECCIxN DE DESTINO ES IGUAL AL IDENTIFICADOR = 0,
				// SI EL TIEMPO DE CREACCIxN DEL PAQUETE GATE ES MAYOR A 1 SEGUNDO,
				// SI EL IDENTIFICADOR DE LA ONU EN LA QUE ESTAMOS ES IGUAL A 0.
				if(gatemsg->getDestAddress()==0 && gatemsg->getCreationTime() > 1 && getParentModule()->getIndex()==0)
				{
					// DAMOS EL VALOR DEL TIEMPO DE SIMULACIxN A LA VARIABLE time_gate Y LO VISUALIZAMOS POR PANTALLA
					time_gate = simTime();
					//EV <<" Tiempo en el que llega el paquete Gate a la ONU 0: "<<time_gate<<"s."<<endl;
					//EV <<" Tiempo de envio del paquete Report de la ONU "<<((int)par("numOnu")-1)<<": "<<gatemsg->getTimereport()<<"s."<<endl;

					// RECOGIDA DE ESTADISTICAS MANUALMENTE Y LO VISUALIZAMOS POR PANTALLA
					comprobar_tiempo_ciclos = time_gate - gatemsg->getTimereport(); // TIEMPO QUE SE PIERDE ENTRE EL FINAL Y EL PRINCIPIO DE UN CICLO
					//EV <<" Tiempo que se pierde entre el final y el comienzo de un ciclo: "<<comprobar_tiempo_ciclos<<"s."<<endl;
					time_cycles.collect(comprobar_tiempo_ciclos); // RECOGEMOS EL RESULTADO
				}

				send(gatemsg, "wdmptpOut"); // ENVIAMOS EL PAQUETE GATE HACIA EL MxDULO POINT TO POINT DE LA ONU
			}
			break;

		case 1:
			// LLEGA UN PAQUETE ETHERNET CON IDENTIFICADOR = 1
			if(msg->getKind()==1)
			{
				// DEFINIMOS EL PARxMETRO ingate QUE NOS INDICA EL PUNTERO DE LA PUERTA POR LA CUAL ENTRA EL MENSAJE QUE LLEGA
				cGate *ingate = msg->getArrivalGate();

				// COMPARAMOS EL NOMBRE DE LA PUERTA POR LA QUE ENTRA EL MENSAJE CON LA PUERTA wdmnet$i
				if(ingate->getName() == gate("wdmnet$i",intuniform(0,p-1))->getName())
				{
					send(msg, "wdmptpOut"); // ENVIAMOS EL PAQUETE ETHERNET HACIA EL MxDULO POINT TO POINT DE LA ONU
				}
				else
				{
					ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL APQUETE ETHERNET

					// VISUALIZAMOS EL TAMAxO DEL PAQUETE ETHERNET QUE MANDAMOS HACIA EL OLT
					//EV <<" Tamaño del Paquete que se manda: "<<ethernetmsg->getByteLength()<<endl;

					// CALCULAMOS EL TIEMPO EN EL QUE SE MANDAN LOS PAQUETES ETHERNET Y LO VISUALIZAMOS POR PANTALLA
					double datarate = ethernetmsg->getByteLength()*8/txrate; // CALCULAMOS EL PARxMETRO datarate QUE INDICA LA TASA DE TRANSMISIxN DEL PAQUETE ETHERNET
					timepacketethernet = timepacketethernet + datarate;
					//EV <<" Tiempo de envio del paquete ethernet: "<<timepacketethernet<<" s."<<endl;
					// ENVIAMOS LOS PAQUETES ETHERNET MEDIANTE EL ENVIO RETARDADO DEL TIEMPO EN EL QUE SE MANDAN LOS PAQUETES

					ethernetmsg->setTime_exit_wdmsplitter(simTime());

					sendDelayed(ethernetmsg, timepacketethernet, "wdmnet$o", ethernetmsg->getLambdaethernet());
				}
			}
			break;

		case 2:
			// LLEGA UN PAQUETE REPORT CON IDENTIFICADOR = 2
			if(msg->getKind()==2)
			{
				REPORTmsg *reportmsg=check_and_cast<REPORTmsg*>(msg); // CHEQUEAMOS EL PAQUETE REPORT

				// ENVIAMOS EL PAQUETE REPORT EN EL INSTANTE DESPUxS DE MANDAR TODOS LOS PAQUETES REPORT
				sendDelayed(reportmsg, timepacketethernet, "wdmnet$o", reportmsg->getLambdareport());

				// COMPARAMOS SI LA DIRECCIxN FUENTE DEL PAQUETE REPORT ES PARA LA ÚLTIMA ONU PARA VER EL TIEMPO EN EL QUE SE ENVIA EL REPORT DE LA ULTIMA ONU PARA CALCULAR EL TIEMPO ENTRE CICLOS EN EL MxTODO DMB DEL OLT
				if(reportmsg->getSrcAddress()==((int)par("numOnu")-1))
				{
					time_report = reportmsg->getSendingTime(); // TIEMPO EN EL QUE SE ENVIA EL PAQUETE REPORT
					reportmsg->setTimesendreport(time_report); // CARGAMOS EL VALOR DE time_report EN UNO DE LOS CAMPOS DEL PAQUETE REPORT Y LO VISUALIZAMOS POR PANTALLA
					//EV <<" Tiempo de envio del paquete REPORT de la última ONU: "<<reportmsg->getTimesendreport()<<endl;
				}

				timepacketethernet = 0; // ACTUALIZAMOS EL PARxMETRO DEL TIEMPO DE ENVIO DE LOS PAQUETES ETHERNET AL VALOR 0
			}
			break;

		default:
			delete msg;
			break;
	}

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN FINISH()--> ESTA FUNCIxN SE INVOCA CUANDO LA SIMULACIxN HA TERMINADO CON xXITO SIN QUE SE PRODUZCA NINGUN ERROR. 		//
//					  LO USAMOS PARA LA RECOGIDA DE ESTADxSTICAS Y VISUALIZACIxN POR PANTALLA O MEDIANTE UN ARCHIVO.            //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_WDMSplitter::finish()
{
	//RECOGIDA DE ESTADISTICAS CON LA CLASE ANALISIS!! GUARDAMOS LOS DATOS EN UN ARCHIVO
	// SE PONE LA RUTA DONDE SE VAN A CREAR LOS ARCHIVOS
	tiempo_entre_ciclos=fopen("results/tiempo_entre_ciclos.txt", "a+"); // ABRIMOS EL ARCHIVO EN EL QUE GUARDAREMOS LOS RESULTADOS
		fprintf(tiempo_entre_ciclos,"%g\t", time_cycles.getMean()); // MEDIA DEL TIEMPO ENTRE CICLOS
		fprintf(tiempo_entre_ciclos,"\n");
		fclose(tiempo_entre_ciclos); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS

}
