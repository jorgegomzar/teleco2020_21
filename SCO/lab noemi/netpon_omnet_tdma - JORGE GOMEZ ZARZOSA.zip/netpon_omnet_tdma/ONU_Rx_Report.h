////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_ONU_RX_REPORT_H_
#define __REDPON_ONU_RX_REPORT_H_

#include <omnetpp.h>
#include <vector>
#include <time.h>
#include "analysis.h"
#include "ONU_SISTqueue.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
using namespace omnetpp;

class ONU_SISTqueue;

//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES Y MATRICES
typedef std::vector<int> int_vector_t; // VECTOR DE TIPO ENTERO
typedef std::vector<double> double_vector_t; // VECTOR DE TIPO DOUBLE


class ONU_Rx_Report : public cSimpleModule
{
	public:

		ONU_SISTqueue *onu_queue; // DEFINIMOS VARIABLE PARA PODER ENTRAR EN EL MÓDULO OLT_TABLE
		long sumpacketextrac; // VARIABLE DE LA SUMA DE LOS PAQUETES QUE SE CHEQUEAN EN EL MÉTODO DE EXTRACION ESTRICTA DE PAQUETES
		long sumextract; // VARIABLE DE LA SUMA DE LOS PAQUETES QUE SE EXTRAEN EN EL MÉTODO DE EXTRACION ESTRICTA DE PAQUETES
		long tamsumqueue; // TAMAÑO DE LA SUMA DEL TAMAÑO DE LOS PAQUETES QUE LLEGAN A LAS COLAS DE LA ONU
		int_vector_t sumpacket; // VECTOR DE LA SUMA DE LOS PAQUETES QUE SE CHEQUEAN EN LAS COLAS
		int_vector_t sumqueuepop; // VECTOR DE LA SUMA TOTAL DE BYTES EXTRAIDOS DE LAS COLAS
		int_vector_t bytes_queue; // VECTOR DE LOS BYTES QUE QUEDAN EN LA COLA DESPUES DE CADA CICLO
		double_vector_t media; // VECTOR PARA INDICAR LA MEDIA

	// DEFINIMOS LOS PARÁMETROS PARA LA CLASE ANÁLISIS
		// PARÁMETRO PARA OBTENER LA MEDIA DE LOS BYTES QUE SE QUEDAN EN LA COLAS DESPUÉS DE CADA CICLO CON LA CLASE ANÁLISIS
		std::vector<Analysis> media_bytes_queue; // VECTOR DE CLASE ANÁLISIS PARA CREAR LOS BYTES QUE SE QUEDAN EN LA COLAS DESPUÉS DE CADA CICLO
		FILE * media_queue_onu; // ARCHIVO DONDE GUARDAMOS LA MEDIA DE LAS COLAS


	protected:
		virtual void initialize();
		virtual void handleMessage(cMessage *msg);

		virtual void strictpriorityqueue(cMessage *msg); // FUNCIÓN DEL MÉTODO DE EXTRACCIÓN DE PAQUETES DE COLAS DE PRIORIDAD ESTRICTA
        virtual void centralizedmethod(cMessage *msg); // FUNCIÓN DEL MÉTODO DE EXTRACCIÓN DE PAQUETES DE COLAS CENTRALIZADO

        virtual void finish(); // DEFINICIÓN DE LA FUNCIÓN FINALIZAR
};

#endif
