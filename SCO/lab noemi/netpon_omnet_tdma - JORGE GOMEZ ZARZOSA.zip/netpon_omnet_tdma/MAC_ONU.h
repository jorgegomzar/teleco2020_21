////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_MAC_ONU_H_
#define __REDPON_MAC_ONU_H_

#include <omnetpp.h>
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "ONU_Table.h"

//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES Y MATRICES
typedef std::vector<int> int_vector_t; // VECTOR TIPO ENTERO
typedef std::vector<double> double_vector_t; // VECTOR TIPO DOUBLE
typedef std::vector< double_vector_t > double_matrix_t; // MATRIZ DE TIPO DOUBLE

class MAC_ONU : public cSimpleModule
{
	private:
		ONU_Table *onutable_module; // DEFINIMOS VARIABLE PARA PODER ENTRAR EN EL MÓDULO ONU_TABLE
		int_vector_t numsla_onu; // VECTOR QUE GUARDA EL IDENTIFICADOR DE SLA ASOCIADO A LA ONU

	protected:
    	 virtual void initialize(int stage);
    	 virtual void handleMessage(cMessage *msg);

	public:
		int numInitStages() const; // FUNCIÓN QUE INICIALIZA VARIAS ETAPAS.
};

#endif
