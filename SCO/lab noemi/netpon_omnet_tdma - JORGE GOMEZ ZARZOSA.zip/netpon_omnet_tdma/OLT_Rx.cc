////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TxTULO: Implementacixn de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERxA TxCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIxN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "OLT_Rx.h"
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "analysis.h"
#include <string.h>
#include <stdio.h>
#include <vector>

// GENERAMOS EL CxDIGO Y LAS FUNCIONES DEL MxDULO SIMPLE
Define_Module(OLT_Rx);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN INITIALIZE()--> ESTA FUNCIxN SE INVOCA DESPUxS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARxMETROS DEL MxDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MxDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINxMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MxDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void OLT_Rx::initialize()
{
	num_sla.resize((int)par("numOnu"),0); // VECTOR PARA GUARDAR EL IDENTIFICADOR DEL SLA DE LA ONU ASOCIADA. SE INICIALIZA A 0 CON UN TAMAxO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	numReceived = 0; // INICIALIZAMOS EL NÚMERO DE PAQUETES ETHERNET RECIBIDOS A 0
	total_bytes_received = 0; // INICIALIZAMOS EL TOTAL DE LOS BYTES DE LOS PAQUETES ETHERNET RECIBIDOS A 0
	total_bits_received = 0; // INICIALIZAMOS EL TOTAL DE LOS BITS DE LOS PAQUETES ETHERNET RECIBIDOS A 0
	throughput = 0; // INICIALIZAMOS EL RENDIMIENTO A 0

	retardo_global_P.resize((int)par("numqueue"));
	retardo_sla.resize((int)par("numSLA"));
	retardo_servicios_sla.resize((int)par("numSLA"));
	for(int i=0; i<retardo_servicios_sla.size(); i++)
	{
		retardo_servicios_sla[i].resize((int)par("numqueue"));
	}
	media_bytes_total_onus.resize((int)par("numqueue"));
	retardo_P.resize((int)par("numqueue"),0);
	retardo.resize((int)par("numSLA"),0);
	tam_packet_queue.resize((int)par("numqueue"),0);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIxN SE INVOCA CON EL MENSAJE COMO PARxMETRO CADA VEZ QUE EL MxDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CxDIGO IMPLEMENTADO PARA DEVOLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIxN DENTRO DEL MxDULO SIMPLE. EL TIEMPO DE SIMULACIxN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIxN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CxDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void OLT_Rx::handleMessage(cMessage *msg)
{
	// VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MxDULO
	switch(type)
	{
		case 1:
			// LLEGA UN PAQUETE ETHERNET CON IDENTIFICADOR = 1
			if(msg->getKind()==1)
			{
				//ev<<" Paquete Ethernet Recibido y Borrado."<<endl;
				ETHERNETmsg *ethernetmsg=check_and_cast<ETHERNETmsg*>(msg); // CHEQUEAMOS EL PAQUETE ETHERNET

				// VARIABLES
				int id_servicio = ethernetmsg->getId_servicio(); // PARxMETRO QUE INDICA EL IDENTIFICADOR DEL SERVICIO DE LA ONU
				int numero_sla = num_sla[ethernetmsg->getSrcAddress()]; // PARxMETRO QUE INDICA EL IDENTIFICADOR DEL SLA ASOCIADO A LA ONU

				//COMPARAMOS EL TIEMPO DE SIMULACIxN CON EL VALOR 1 (SE EMPIEZAN A CREAR LOS PAQUETES ETHERNET) PARA EMPEZAR A COGER ESTADxSTICAS MANUALMENTE Y CON LA CLASE ANxLISIS
				if(simTime()>=1)
				{
					// RECOGIDA DE ESTADISTICAS DEL RETARDO GLOBAL CON LA CLASE ANxLISIS PARA TODAS LAS CLASES DE SERVICIOS
					  retardo_P[id_servicio] = simTime() - ethernetmsg->getTime_enter_queue(); // PARAMETRO PARA CALCULAR EL RETARDO CON LA CLASE ANxLISIS
					  retardo_global_P[id_servicio].analyze(SIMTIME_DBL(retardo_P[id_servicio])); // RECOGEMOS EL RESULTADO CON LA CLASE ANxLISIS

					// RECOGEMOS LAS ESTADxSTICAS DEL RETARDO POR SLA CON LA CLASE ANxLISIS
					// COMPARAMOS SI ES DE POLLIN O CENTRALIZADO YA QUE SOLO SE TRABAJA CON LOS SLAs EN EL ALGORITMO CENTRALIZADO DMB
					if((int)par("oltmethod_Centralized0_Polling1")==0)
					{
						// RECOGEMOS LAS ESTADxSTICAS DEL RETARDO POR SLA CON LA CLASE ANxLISIS
						retardo[numero_sla] =  simTime() - ethernetmsg->getTime_enter_queue(); // PARAMETRO PARA CALCULAR EL RETARDO CON LA CLASE ANxLISIS
						retardo_sla[numero_sla].analyze(SIMTIME_DBL(retardo[numero_sla])); // RECOGEMOS EL RESULTADO CON LA CLASE ANxLISIS
						retardo_servicios_sla[numero_sla][id_servicio].analyze(SIMTIME_DBL(retardo_P[id_servicio])); // RECOGEMOS EL RESULTADO CON LA CLASE ANxLISIS
					}

				}

				numReceived++; // INCREMENTAMOS EN UNO EL CONTADOR DE NÚMERO DE PAQUETES ETHERNET RECIBIDOS
				total_bytes_received = total_bytes_received + ethernetmsg->getByteLength();
				delete ethernetmsg; // BORRAMOS LOS PAQUETES ETHERNET

				// COMPARAMOS SI EL NUMERO DE ITERACCIONES ES MAYOR O IGUAL UN CIERTO NÚMERO, O QUE LA FUNCIxN ANxLISIS CONVERJA
				if((int)par("oltmethod_Centralized0_Polling1")==0)
				{
					// MxTODO CENTRALIZADO O DMB
					// PONEMOS EL SIGUIENTE CxDIGO PARA QUE SE PARE LA SIMULACIxN Y SE INVOQUE LA FUNCIxN FINISH()
					// TENEMOS QUE MODIFICAR MANUALMENTE LAS VARIABLES QUE QUEREMOS QUE LLEGUEN A UN CIERTO NÚMERO DE ITERACIONES
					// PARA QUE FINALICE LA SIMULACIxN Y SE INVOQUE LA FUNCION FINISH()
					// retardo_global_P[] -> RETARDO GLOBAL DE CADA SERVICIO
					// retardo_sla[] -> RETARDO GLOBAL DE CADA SLA
					// retardo_servicios_sla[][] -> RETARDO DE CADA SERVICIO ASOCIADO A CADA SLA

					if( retardo_global_P[0].number_iterations() >= 20  && retardo_sla[0].number_iterations() >= 20 && retardo_sla[1].number_iterations() >= 20)// TENEMOS QUE AxADIR LAS VARIABLES // numReceived >= 5000000)//retardo_global_P[0].converged() && retardo_sla[0].converged()) // NÚMERO DE PAQUETES QUE LLEGAN O SI LA FUNCIxN ANxLSIS CONVERGE
					{
						total_bits_received = total_bytes_received*8;
						throughput = total_bits_received/simTime().dbl();

						//endSimulation(); // LLAMAMOS A LA FUNCIxN TERMINAR SIMULACIxN
						//callFinish(); // LLAMAMOS A LA FUNCIxN FINALIZAR
					}
					if(simTime() >= 5000)
					{
						endSimulation(); // LLAMAMOS A LA FUNCION TERMINAR SIMULACION
						callFinish(); // LLAMAMOS A LA FUNCION FINALIZAR
					}
				}
				else if((int)par("oltmethod_Centralized0_Polling1")==1)
				{
					// MxTODO DE POLLING O IPACT
					// PONEMOS EL SIGUIENTE CxDIGO PARA QUE SE PARE LA SIMULACIxN Y SE INVOQUE LA FUNCIxN FINISH()
					// TENEMOS QUE MODIFICAR MANUALMENTE LAS VARIABLES QUE QUEREMOS QUE LLEGUEN A UN CIERTO NÚMERO DE ITERACIONES
					// PARA QUE FINALICE LA SIMULACIxN Y SE INVOQUE LA FUNCION FINISH()
					// retardo_global_P[] -> RETARDO GLOBAL DE CADA SERVICIO
					if( retardo_global_P[0].number_iterations() >= 30 ) // TENEMOS QUE AxADIR LAS VARIABLES // numReceived >= 5000000)//retardo_global_P[0].converged()) // NÚMERO DE PAQUETES QUE LLEGAN O SI LA FUNCIxN ANxLSIS CONVERGE
					{
						total_bits_received = total_bytes_received*8;
						throughput = total_bits_received/ simTime().dbl();

						//endSimulation(); // LLAMAMOS A LA FUNCIxN TERMINAR SIMULACIxN
						//callFinish(); // LLAMAMOS A LA FUNCIxN FINALIZAR
					}
					if(simTime() >= 5000)
					{
						endSimulation(); // LLAMAMOS A LA FUNCION TERMINAR SIMULACION
						callFinish(); // LLAMAMOS A LA FUNCION FINALIZAR
					}
				}
			}
			break;

		case 2:
			// LLEGA UN PAQUETE REPORT CON IDENTIFICADOR = 2
			if(msg->getKind()==2)
			{
				REPORTmsg *reportmsg=check_and_cast<REPORTmsg*>(msg);

				num_sla[reportmsg->getSrcAddress()] = reportmsg->getNumsla(); // GUARDAMOS EN EL VECTOR num_sla[] EL IDENTIFICADOR DEL SLA Y LO VISUALIZAMOS POR PANTALLA
				//ev<<" Número del SLA asociado a la ONU"<<reportmsg->getSrcAddress()<<": SLA"<<num_sla[reportmsg->getSrcAddress()]<<endl;

				// COGEMOS LAS ESTADxSTICAS DE LA MEDIA DE TODAS LAS ONUS CUANDO EL TIEMPO DE SIMULACIxN SEA MAYOR O IGUAL A 1
				if(simTime()>=1)
				{
					// RECORREMOS EL BUCLE FOR PARA GUARDAR EN EL VECTOR tam_packet_queue[] LOS BYTES QUE QUEDAN EN CADA COLA DESPUxS DE CADA CICLO
					for(int i=0; i<(int)par("numqueue"); i++)
					{
						tam_packet_queue[i] = reportmsg->getQueue_estado(i); // GUARDAMOS LOS BYTES QUE QUEDAN EN CADA COLA DESPUxS DE CADA CICLO
						media_bytes_total_onus[i].analyze(tam_packet_queue[i]); // RECOGEMOS EL RESULTADO CON LA CLASE ANxLISIS
					}

					// PONEMOS EL SIGUIENTE CxDIGO PARA QUE SE PARE LA SIMULACIxN Y SE INVOQUE LA FUNCIxN FINISH()
					// TENEMOS QUE MODIFICAR MANUALMENTE LAS VARIABLES QUE QUEREMOS QUE LLEGUEN A UN CIERTO NÚMERO DE ITERACIONES
					// PARA QUE FINALICE LA SIMULACIxN Y SE INVOQUE LA FUNCION FINISH()
					// media_bytes_total_onus[] -> MEDIA POR SERVICIOS DE TODAS LAS ONU
					//if( media_bytes_total_onus[0].number_iterations() >= 30 ) // TENEMOS QUE AxADIR LAS VARIABLES // numReceived >= 5000000)//media_bytes_total_onus[0].converged()) // NÚMERO DE PAQUETES QUE LLEGAN O SI LA FUNCIxN ANxLSIS CONVERGE
					//{
					//	endSimulation(); // LLAMAMOS A LA FUNCIxN TERMINAR SIMULACIxN
					//	callFinish(); // LLAMAMOS A LA FUNCIxN FINALIZAR
					//}
				}

				send(reportmsg, "oltrxOut"); // ENVIA EL PAQUETE REPORT HACIA LA CAPA MAC DEL OLT
			}
			break;

		default:
			delete msg;
			break;
	}

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIxN FINISH()--> ESTA FUNCIxN SE INVOCA CUANDO LA SIMULACIxN HA TERMINADO CON xXITO SIN QUE SE PRODUZCA NINGUN ERROR. 		//
//					  LO USAMOS PARA LA RECOGIDA DE ESTADxSTICAS Y VISUALIZACIxN POR PANTALLA O MEDIANTE UN ARCHIVO.            //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void OLT_Rx::finish()
{
	// VISUALIZAMOS POR PANTALLA LA RECOGIDA DE ESTADISTICAS MANUAL CUANDO LLAMAMOS A LA FUNCIxN FINISH()
	EV << " OLT " << endl;
	EV << " Paquetes Ethernet Totales Recibidos: " << numReceived << endl;

	//RECOGIDA DE ESTADISTICAS CON LA CLASE ANALISIS!! GUARDAMOS LOS DATOS EN UN ARCHIVO
	// SE PONE LA RUTA DONDE SE VAN A CREAR LOS ARCHIVOS
	retardo_analisis=fopen("results/retardo_analisis.txt", "a+"); // ABRIMOS EL ARCHIVO EN EL QUE GUARDAREMOS LOS RESULTADOS
		// RECORREMOS ESTE BUCLE FOR PARA OBTENER LA MEDIA GLOBAL DE CADA SERVICIO
		for(int i=0; i<(int)par("numqueue"); i++)
		{
			fprintf(retardo_analisis,"%g\t", (double)retardo_global_P[i].average()); // MEDIA DEL RETARDO
			fprintf(retardo_analisis,"%g\t", (double)retardo_global_P[i].half_confidence_interval()); // DESVIACIxN DEL RETARDO
		}
		fprintf(retardo_analisis,"\n");
		fprintf(retardo_analisis,"%li\n", numReceived);
		fclose(retardo_analisis); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS


		// ARCHIVO PARA RECOGER LOS DATOS DEL RETARDO POR CADA SLA GLOBAL Y POR TIPO DE SERVICIOS
		// SE PONE LA RUTA DONDE SE VAN A CREAR LOS ARCHIVOS
	retardo_analisis_sla=fopen("results/retardo_analisis_sla.txt", "a+"); // ABRIMOS EL ARCHIVO EN EL QUE GUARDAREMOS LOS RESULTADOS
		for(int i=0; i<(int)par("numSLA"); i++)
		{
			fprintf(retardo_analisis_sla,"%g\t", (double)retardo_sla[i].average()); // MEDIA DEL RETARDO GLOBAL DE CADA SLA
			// RECORREMOS ESTE BUCLE FOR PARA OBTENER LA MEDIA DE CADA SERVICIO ASOCIADA A CADA SLA
			for(int j=0; j<(int)par("numqueue"); j++)
			{
				fprintf(retardo_analisis_sla,"%g\t", (double)retardo_servicios_sla[i][j].average());
			}
			fprintf(retardo_analisis_sla,"%g\t", (double)retardo_sla[i].half_confidence_interval()); // DESVIACIxN DEL RETARDO GLOBAL DE CADA SLA
			// RECORREMOS ESTE BUCLE FOR PARA OBTENER EL INTERVALO DE CONFIANZA DE CADA SERVICIO ASOCIADO A CADA SLA
			for(int j=0; j<(int)par("numqueue"); j++)
			{
				fprintf(retardo_analisis_sla,"%g\t", (double)retardo_servicios_sla[i][j].half_confidence_interval()); // MEDIA DEL RETARDO GLOBAL DE CADA SLA
			}
			fprintf(retardo_analisis_sla,"\n");
		}
		fprintf(retardo_analisis_sla,"\n");
		fclose(retardo_analisis_sla); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS

		// RECOGIDA DE ESTADISTICAS DE LAS MEDIAS DE LOS BYTES QUE QUEDAN EN LAS COLAS DE TODAS LAS ONUs DESPUxS DE CADA CICLO CON LA CLASE ANALISIS Y LO GUARDAMOS LOS DATOS EN UN ARCHIVO
		// SE PONE LA RUTA DONDE SE VAN A CREAR LOS ARCHIVOS
		media_total_onu=fopen("results/media_total_onu.txt", "a+"); // ABRIMOS EL ARCHIVO EN EL QUE GUARDAREMOS LOS RESULTADOS
			for(int i=0; i<(int)par("numqueue"); i++)
			{
					fprintf(media_total_onu,"%g\t", (double)media_bytes_total_onus[i].average()); // MEDIA DE LOS BYTES QUE QUEDAN EN LAS COLAS DESPUxS DE CADA CICLO
			}
			fprintf(media_total_onu,"\n");
			fclose(media_total_onu); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS

		throughput_net=fopen("results/throughput_net.txt", "a+"); // ABRIMOS EL ARCHIVO EN EL QUE GUARDAREMOS LOS RESULTADOS
			fprintf(throughput_net,"%g\t", (double)throughput);
			fprintf(throughput_net,"\n");
			fclose(throughput_net); // CERRAMOS EL ARCHIVO EN EL QUE GUARDAMOS LOS DATOS


}
