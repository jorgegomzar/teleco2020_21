////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "MAC_OLT.h"
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "OLT_Table.h"

// GENERAMOS EL CÓDIGO Y LAS FUNCIONES DEL MÓDULO SIMPLE
Define_Module(MAC_OLT);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN NUMINITSTAGES()--> ESTA FUNCIÓN INICIALIZA VARIAS ETAPAS. SE DEFINE PARA QUE DEV UELVA EL NÚMERO DE ETAPAS DE INICIO.  //
//							 EN NUESTRO CASO, LA FUNCIÓN DEV ULEV E EL VALOR 1 YA QUE SOLO TENEMOS UNA ETAPA DE INICIALIZACIÓN.	//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int MAC_OLT::numInitStages() const{return 1;}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN INITIALIZE()--> ESTA FUNCIÓN SE INVOCA DESPUÉS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARÁMETROS DEL MÓDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MÓDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINÁMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MÓDULO.			   													//
//						  LA FUNCIÓN INITIALIZE(INT STAGE) SE UTILIZA PARA INICIALIZAR VARIAS ETAPAS SEGUN EL VALOR STAGE.      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MAC_OLT::initialize(int stage)
{
	// CREAMOS UN AUTOMENSAJE PARA CREAR EL PAQUETE GATE QUE MANDA EL OLT HACIA LAS ONUS PARA LA INICIALIZACIÓN
	cMessage *msg = new cMessage ("mensaje inicial gate");
	msg->setKind(5); // IDENTIFICAMOS EL AUTOMENSAJE CON EL IDENTIFICADOR = 5
	scheduleAt(0, msg); // SI QUE QUITA NO SE INICIALIZAN LAS ONUS, NO SE MANDAN LOS GATES

	// INICIALIZAMOS VARIABLES AL VALOR 0
	sumqueue = 0; // VARIABLE DEL TAMAÑO DE LA SUMA DE LOS PAQUETES DE LAS COLAS
	sumbdemand = 0; // VARIABLE DEL TAMAÑO DE LA SUMA DEL ANCHO DE BANDA DEMANDADO
	B_sobra = 0; // VARIABLE DEL ANCHO DE BANDA DE SOBRA
	B_exceded = 0; // VARIABLE DEL ANCHO DE BANDA EN EXCESO
	tstarttime = 0; // VARIABLE DEL TIEMPO DE INICIO DE TRANSMISIÓN
	B_alloc.resize((int)par("numOnu"),0); // VECTOR DEL ANCHO DE BANDA ASIGNADO. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS QUE DEFINAMOS
	B_demand.resize((int)par("numOnu"),0); // VECTOR DEL ANCHO DE BANDA DEMANDADO. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS QUE DEFINAMOS
	B_extra.resize((int)par("numOnu"),0); // VECTOR DEL ANCHO DE BANDA EXTRA QUE SE ASIGNA A MAYORES. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS QUE DEFINAMOS
	t_slot.resize((int)par("numOnu"),0); // VECTOR DE TIEMPO DE SLOT DE LA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS QUE DEFINAMOS
	t_slot_initialization.resize((int)par("numOnu"),0); // VECTOR DE TIEMPO DE SLOT DE LA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	T_alloc.resize((int)par("numOnu"),0); // VECTOR DE TIEMPO ASIGNADO PARA TRANSMITIR. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS QUE DEFINAMOS
	tiempo_tx_siguiente = 0; // VECTOR DE TIEMPO DE TRANSMISIÓN DE LA SIGUIENTE ONU
	tiempo_sim_delay_datarate = 0; // VARIABLE DE TIEMPO DE LA SUMA DEL TIEMPO DE SIMULACION, RETARDO Y TIEMPO DE TRANSMISIÓN DEL PAQUETE GATE
	delay = 0; // RETARDO DE NUESTRA RED DEPENDIENDO DE LA LONGITUD TOTAL DE LA RED
	delay_pon1 = 0; // RETARDO DEL SEGMENTO DE LA RED QUE UNE EL OLT Y EL SPLITTER
	delay_pon2.resize((int)par("numOnu"),0); // VECTOR DEL RETARDO DEL SEGMENTO DE LA RED QUE UNE EL SPLITTER Y CADA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	delay_total.resize((int)par("numOnu"),0); // // VECTOR DE LA SUMA DE LOS RETARDOS DE CADA SEGMENTO DE LA RED (OLT-SPLITTER Y SPLITTER-ONU). SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	B_ex_sla.resize((int)par("numOnu"),0); // VECTOR DEL ANCHO DE BANDA ASOCIADO A CADA ONU SEGUN EL SLA ASOCIADO A LA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	B_max_dmb.resize((int)par("numOnu"),0); // VECTOR DEL ANCHO DE BANDA MÁXIMO PARA CADA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	SLA_onu.resize((int)par("numOnu"),0); // VECTOR EN EL QUE SE INTRODUCIRA LOS PESOS ASOCIADOS AL SLA QUE CORRESPONDE A CADA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	numsla.resize((int)par("numOnu"),0); // VECTOR QUE NOS GUARDA EL NÚMERO DE SLA ASOCIADO A CADA ONU. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE ONUS DE NUESTRA RED
	Wsla.resize((int)par("numSLA")+2,0); // VECTOR DE LOS PESOS DE CADA SLA. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE SLAs + 2 YA QUE SE UTILIZAN 3 SLA Y HEMOS DEFINIDO MANUALMENTE 4 PESOS PARA NUESTRA RED
	numonu_sla.resize((int)par("numSLA")+2,0); //  VECTOR DEL NÚMERO DE ONUs ASOCIADAS A CADA SLA. SE INICIALIZA A 0 CON UN TAMAÑO IGUAL AL NÚMERO DE SLAs + 2 YA QUE SE UTILIZAN 3 SLA Y HEMOS DEFINIDO MANUALMENTE 4 PESOS PARA NUESTRA RED
	id_onu = 0; // IDENTIFICADOR DE LA ONU
	W_min = 0; // PESO MÍNIMO CON UN VALOR FIJO DE 0.34
	long_max = 0; // LONGITUD MÁXIMA QUE TIENE UNA ONU PARA TRANSMITIR DEPENDIENDO DEL B_cycle Y DEL NÚMERO DE ONUs
	B_basico = 0; // ANCHO DE BANDA BASICO PARA TRANSMITIR QUE TIENE CADA ONU.
	sumatorio = 0; // VARIABLE QUE NOS INDICA EL SUMATORIO DE CADA PESO ASOCIADO A UN SLA POR SU NÚMERO DE ONUS ASOCIADOS A SLA

	// DEFININOS EL PROCESO PARA PODER ENTRAR DESDE ESTE MÓDULO AL MÓDULO OLT_TABLE
	cModule *c_table_module;
	if(stage==0)
	{
		c_table_module = getParentModule()->getSubmodule("olt_table"); // CAMINO PARA LLEGAR HASTA EL MÓDULO OLT_TABLE
		table_module = check_and_cast<OLT_Table *>(c_table_module); // ENTRAMOS Y CHEQUEAMOS EL MÓDULO OLT_TABLE
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIÓN SE INVOCA CON EL MENSAJE COMO PARÁMETRO CADA VEZ QUE EL MÓDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CÓDIGO IMPLEMENTADO PARA DEV OLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIÓN DENTRO DEL MÓDULO SIMPLE. EL TIEMPO DE SIMULACIÓN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CÓDIGO IMPLEMENTADO.																	//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MAC_OLT::handleMessage(cMessage *msg)
{
	//VARIABLES
	int type = msg->getKind(); // VARIABLE TYPE PARA IDENTIFICAR LOS MENSAJES DE LA RED
	double txrate = (int)par("txrate"); // VARIABLE TASA DE TRANSMISIÓN
	double B_slot[(int)par("numqueue")]; // VARIABLE DE ANCHO DE BANDA DE SLOT CON TAMAÑO IGUAL AL NÚMERO DE COLAS QUE DEFINAMOS
	int srcAddress = 9; // DEFINIMOS EL IDENTIFICADOR DE LA DIRECCIÓN FUENTE DE LOS PAQUETES GATE
	int oltmethod = (int)par("oltmethod_Centralized0_Polling1"); // VARIABLE QUE NOS INDICA EL MÉTODO DEL OLT ELEGIDO AL PRINCIPIO DE LA SIMULACIÓN
	double tasa_tx_gate = 512/txrate; // VARIABLE QUE NOS INDICA LA TASA DE TRANSMISIÓN DEL PAQUETE GATE CON UN TAMAÑO DE 64 BYTES
	double velocidad = 300000000; // DEFINIMOS EL PARÁMETRO VELOCIDAD DE LA VELOCIDAD DE LA LUZ (EN M/S)
	double longitud_total_red; // PARÁMETOR  QUE NOS INDICA LA LONGITUD TOTAL DE LA RED PARA CUANDO SIMULAMOS LA RED CON UNA LONGITU FIJA

	// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MENSAJES QUE LLEGUEN A ESTE MÓDULO
	switch(type)
	{
		case 2:
			// LLEGA UN PAQUETE REPORT CON IDENTIFICADOR = 2
			if(msg->getKind()==2)
			{
				REPORTmsg *reportmsg = check_and_cast<REPORTmsg *>(msg); // CHEQUEAMOS EL MENSAJE REPORT
				EV <<"Ha llegado un mensaje Report de ONU: "<<reportmsg->getSrcAddress()<<endl;
				// BULCE FOR PARA GUARDAR EN LA TABLA DEL MÓDULO OLT_TABLE EL ESTADO DE LAS COLAS
				for(int j=0; j<(int)par("numqueue"); j++)
				{
					table_module->table_olt_report[reportmsg->getSrcAddress()][j] = reportmsg->getQueue_estado(j);
				}

				// VISULAIZAMOS POR PANTALLA CON LOS BUCLES FOR LA TABLA COMPLETA DEL MÓDULO OLT_TABLE
				for(int i=0; i<(int)par("numOnu"); i++)
				{
					for(int j=0; j<(int)par("numqueue"); j++)
					{
						//EV <<"ONU "<< i<<"->"<< "Queue Estado "<< j <<": "<<table_module->table_olt_report[i][j]<<endl;
					}
					EV <<"ONU "<< i<<"->"<< "Bandwidth Demandado: "<<table_module->table_olt_report[i][(int)par("numqueue")]<<endl;
					//EV <<"ONU "<< i<<"->"<< "Bandwidth Asignado: "<<table_module->table_olt_report[i][(int)par("numqueue")+1]<<endl;
				}

				// ESTRUCTURA CONDICIONAL SWITCH QUE NOS DIFERENCIA LOS MÉTODOS DEL OLT
				switch(oltmethod)
				{
					case 0:
						// MÉTODO DMB O CENTRALIZADO DEL OLT
						centralizedmethod_DMB(msg);
						break;

					case 1:
						// MÉTODO IPACT O DE POLLING DEL OLT
						pollingmethod_IPACT(msg);
						break;
					case 2:
					    centralizedmethod(msg);
					    break;

					default:
						EV <<" ERROR AL ELEGIR EL METODO DEL OLT, ELEGIR 0, 1 ó 2."<<endl;
						break;
				}

			}
			break;

		case 5:
			// LLEGA UN AUTOMENSAJE CON IDENTIFICADOR = 5 PARA GENERAR EL PAQUETE GATE
			if(msg->getKind()==5)
			{
				delete msg; // BORRAMOS EL AUTOMENSAJE YA QUE NO SE UTILIZA MAS ADELANTE

				// CALCULAMOS EL DELAY O RETARDO DEPENDIENDO DE LA LONGITUD DE NUESTRA RED
				longitud_total_red = ((double)par("longpon1")+(double)par("longpon2")); // DEFINIMOS EL PARÁMETRO QUE INDICA LA LONGITUD TOTAL DE LA RED EN METROS
				delay = (longitud_total_red*3)/(velocidad*2); // CALCULAMOS EL RETARDO O DELAY PARA LA RED SEGUN LA LONGITU QUE DEFINAMOS AL PRINCIPION DE LA SIMULACIÓN
				EV <<" Retardo de la red EPON (segundos)"<<delay<<endl;
				// INICIALIZAMOS EL OLT MANDANDO UN MENSAJE GATE A CADA ONU INDICANDO EL ANCHO DE BANDA DE SLOT Y EL TIEMPO DE INICIO DE TRANSMISIÓN
				// MEDIANTE EL BUCLE FOR CREAMOS LOS PAQUETES GATE PARA LAS ONUS DE NUESTRA RED
				for(int i=0; i<(int)par("numOnu"); i++)
				{
					// CREAMOS EL PAQUETE GATE
					GATEmsg *packet = new GATEmsg("gate");
					packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
					packet->setDestAddress(i); // DIRECCIÓN DE DESTINO
					packet->setByteLength(64); // TAMAÑO DEL PAQUETE GATE
					packet->setLambdagate(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE GATE
					packet->setKind(0); // IDENTIFICADOR DEL PAQUETE GATE
					packet->setGrant_IntervalTxArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DE SLOT

					// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA DE SLOT GENERAL O UNO PARA CADA COLA
					if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
					{
						B_slot[0]= 564;//1602;//txrate*1/8; // DEFINIMOS ANCHO DE BANDA DE SLOT
						packet->setGrant_IntervalTx(0,B_slot[0]);


						t_slot_initialization[0] = (B_slot[0]*8/txrate); // CALCULAMOS EL TIEMPO DE SLOT DE INICIALIZACIÓN
						packet->setGrant_IniTime(i*t_slot_initialization[0]+tasa_tx_gate+delay); // TIEMPO DE INICIO DE TRANSIMISIÓN PARA CADA ONU
						EV <<"tiempo de slot inicial asignado"<< B_slot[0]<<endl;
					}
					else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
					{
						//FALTA ALGORITMO PARA ASIGNAR POR COLAS!!!!!!!!!
						// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA DE SLOT PARA CADA COLA
						for(int b=0; b<(int)par("numqueue"); b++)
						{
							B_slot[b] = 564;//1602;//txrate*1/8; // DEFINIMOS EL ANCHO DE BANDA DE SLOT PARA CADA COLA
							packet->setGrant_IntervalTx(b,B_slot[b]);
							EV <<" Ancho de Banda de slot "<<b<<" "<<B_slot[b]<<endl;
							t_slot_initialization[b] = (B_slot[b]*8/txrate); // CALCULAMOS EL TIEMPO DE SLOT DE INICIALIZACIÓN
							packet->setGrant_IniTime(i*t_slot_initialization[b]+tasa_tx_gate+delay); // TIEMPO DE INICIO DE TRANSIMISIÓN PARA CADA ONU

						}
					}

					// VISUALIZAMOS POR PANTALLA TODOS LOS CAMPOS DEL PAQUETE GATE
					EV <<" INICIALIZACIÓN: Creamos el paquete Gate para la ONU "<<packet->getDestAddress()<<endl;
					EV <<" Origen OLT ID: "<<packet->getSrcAddress()<<endl;
					EV <<" Destino ONU "<<packet->getDestAddress()<<endl;
					EV <<" Longitud de onda de envio, Lambda "<< packet->getLambdagate()<<endl;
					//EV <<" Tipo "<<packet->getKind()<<endl;
					EV <<" Tiempo iniciar Tx "<<packet->getGrant_IniTime()<<endl;
					EV <<"  "<<endl;

					// ENVIAMOS LOS PAQUETES GATE MEDIANTE EL ENVIO RETARDADO
					sendDelayed(packet, tasa_tx_gate, "mactxOut");

				}

				//CALCULAMOS EL TIEMPO DE TX SIGUIENTE QUE UTILIZAREMOS EN EL METODOD DE POLLING DE IPACT
				tiempo_tx_siguiente = ((int)par("numOnu")*t_slot_initialization[0])+tasa_tx_gate+delay;
				EV <<" Tiempo Transmisión Siguiente ONU: "<<tiempo_tx_siguiente<<endl;
			}
			break;

		default:
			delete msg;
			break;
	}
}





//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN CENTRALIZEDMETHOD_DMB(CMESSAGE *MSG)--> FUNCIÓN QUE SE INVOCA CON EL MENSAJE O PAQUETE COMO PARÁMETRO UNA VEZ QUE     //
//			LLEGUE AL OLT EL PAQUETE REPORT DE LA ÚLTIMA ONU DE LA RED Y TENEMOS SELECCIONADO EL PARÁMETRO 						//
//			oltmethod_Centralized0_Polling1 EN EL OMNETPP.INICON VALOR 0.														//
//			ESTE ALGORITMO SE ENCARGA DE ASIGNAR EL INSTANTE DE TIEMPO DE INICIO DE LA TRANSMISIÓN Y EL ANCHO DE BANDA DESIGNADO//
//			PARA TRANSMITIR CADA ONU CADA VEZ QUE LE LLEGA EL PAQUETE REPORT DE LA ÚLTIMA ONU DE LA RED. CREA TODOS	LOS PAQUETES//
//			GATE A LA VEZ Y LOS ENVIA CON LOS VALORES CORRESPONDIENTES DE TRANSMISIÓN HACIA CADA ONU, LAS CUALES TRANSMITEN     //
//			EN EL INSTANTE DESIGNADO POR EL OLT Y UNA CANTIDAD DE BYTES DESIGNADOS POR EL OLT									//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MAC_OLT::centralizedmethod_DMB(cMessage *msg)
{
	REPORTmsg *reportmsg = check_and_cast<REPORTmsg *>(msg); // CHEQUEAMOS EL PAQUETE REPORT

	//VARIABLES
	double txrate = (int)par("txrate"); // TASA DE TRANSMISIÓN EN BITS POR SEGUNDO
	double tasa_tx_gate = 512/txrate; // TASA DE TRANSMISIÓN DE UN MENSAJE GATE CON UN TAMAÑO DE 64 BYTES
	double tasa_tx_report = 512/txrate; // TASA DE TRANSMISIÓN DE UN MENSAJE REPORT CON UN TAMAÑO DE 64 BYTES
	double T_cycle = 0.002; // TIEMPO DE CICLO MAXIMO EN MILISEGUNDOS
	double T_guarda = 0.000001; // TIEMPO DE GUARDA QUE SE ESPERA ENTRA LA TRANSMISIÓN DE DOS ONUS
	double T_guarda_nonu = T_guarda*(int)par("numOnu"); // TIEMPO DE GUARDA TOTAL DE TODAS LAS ONUS MENOS LA ULTIMA
	double T_report_nonu = tasa_tx_report*((int)par("numOnu")); // TASA DE TRANSMISION TOTAL DE LOS PAQUETES REPORT DE TODAS LAS ONUS
	double T_cycle_total = T_cycle - T_guarda_nonu - T_report_nonu; // TIEMPO DE CICLO FINAL Y LO VISUALIZAMOS POR PANTALLA
	EV <<" Tiempo de ciclo total: "<<T_cycle_total<<"s"<<endl;
	long double B_cycle = txrate*T_cycle_total/8; // ANCHO DE BANDA MÁXIMO DEL CICLO EN BYTES Y LO VISULAIZAMOS POR PANTALLA
	EV <<" Ancho de banda del ciclo: "<<B_cycle<<"Bytes"<<endl;
	long double B_report = txrate*tasa_tx_report/8; // TAMAÑO DEL PAQUETE REPORT
	double B_slot[(int)par("numqueue")]; // VARIABLE DE ANCHO DE BANDA DE SLOT CON TAMAÑO EL NÚMERO DE COLAS QUE SE DEFINEN
	int srcAddress = 9; // DEFINICIÓN DEL IDENTIFICADOR DE LA DIRECCIÓN DE ORIGEN O FUENTE
	simtime_t time_tx_onu0; // TIEMPO DE TRANSMISIÓN DE LA PRIMERA ONU
	double velocidad = 300000000; // DEFINIMOS EL PARÁMETRO VELOCIDAD DE LA VELOCIDAD DE LA LUZ (EN M/S)
	double longitud_total_red; // DEFINIMOS LA VARIABLE QUE NOS INDICA LA LONGITUD TOTAL DE LA RED

	// ASIGANCIÓN DE PESOS
	Wsla[0] = (int)par("w_sla0"); // PESO DEL SLA0 DEFINIDO EN NUESTRA RED
	Wsla[1] = (int)par("w_sla1"); // PESO DEL SLA1 DEFINIDO EN NUESTRA RED
	Wsla[2] = (int)par("w_sla2"); // PESO DEL SLA2 DEFINIDO EN NUESTRA RED
	Wsla[3] = (int)par("w_sla3"); // PESO DEL SLA3 DEFINIDO EN NUESTRA RED
	Wsla[4] = (int)par("w_sla4"); // PESO DEL SLA4 DEFINIDO EN NUESTRA RED

	// ASIGNACIÓN DEL NÚMERO DE ONUS
	numonu_sla[0] = (int)par("numonu_sla0"); // NÚMERO DE ONUs ASOCIADO AL SLA0
	numonu_sla[1] = (int)par("numonu_sla1"); // NÚMERO DE ONUs ASOCIADO AL SLA1
	numonu_sla[2] = (int)par("numonu_sla2"); // NÚMERO DE ONUs ASOCIADO AL SLA2
	numonu_sla[3] = (int)par("numonu_sla3"); // NÚMERO DE ONUs ASOCIADO AL SLA3
	numonu_sla[4] = (int)par("numonu_sla4"); // NÚMERO DE ONUs ASOCIADO AL SLA4

	// CALCULAMOS EL DELAY DEPENDIENDO DE LA LONGITUD Y LE SUMAMOS LA TASA DE TRANSMISIÓN DEL PAQUETE GATE PARA SUMARLE DESPUES AL TIEMPO DE INICIO DE TRANSMISIÓN
	longitud_total_red = ((double)par("longpon1")+(double)par("longpon2")); // DEFINIMOS EL PARÁMETRO QUE INDICA LA LONGITUD TOTAL DE LA RED EN METROS
	delay = (longitud_total_red*3)/(velocidad*2); // CALCULAMOS EL RETARDO O DELAY PARA LA RED SEGUN LA LONGITU QUE DEFINAMOS AL PRINCIPION DE LA SIMULACIÓN
	EV <<" CENTRALIZADO DMB Retardo de la Red PON: "<<delay<<endl; // VISUALIZAMOS EL RETARDO DE LA RED

	//LEEMOS EL TIEMPO CUANDO SE ENVIO EL REPORT DE LA ONU 15 Y LO GUARDAMOS EN EL VECTOR DE LA TABLA
	table_module->table_olt_report_time[0] = reportmsg->getTimesendreport();
	EV <<" Tiempo en el que se envio el paquete Report "<<table_module->table_olt_report_time[0]<<endl;

	//VAMOS A CALCULAR EL ANCHO DE BANDA DEMANDADO Y LO GUARDAMOS EN LA TABLA DEL OLT
	EV <<" Calculamos el Bandwitch Demandado y lo guardamos en la tabla del OLT."<<endl;
	// SUMAMOS EL TAMAÑO DEL ESTADO DE LAS COLAS DE LA ONU QUE A MANDADO EL REPORT QUE LLEGA AL OLT
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		sumqueue = sumqueue + reportmsg->getQueue_estado(i);
	}
	// SI LA SUMA TOTAL DEL TAMAÑO DE LAS COLAS ES 0, DAMOS UN VALOR PREDETERMINADO DE 20 BYTES
	if(sumqueue == 0)
	{
		sumqueue = 20;
	}

	// ASIGNAMOS LA SUMA TOTAL A LA VARIABLE DEL ANCHO DE BANDA DEMANDADO DE LA ONU
	B_demand[reportmsg->getSrcAddress()] = sumqueue;

	sumqueue = 0; // DAMOS EL VALOR 0 A LA SUMA DE LAS COLAS. DE ESTA MANERA LA INICIALIZAMOS DE NUEV O A 0

	// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE EL ANCHO DE BANDA DEMANDADO POR LA ONU Y LO VISUALIZAMOS POR PANTALLA
	table_module->table_olt_report[reportmsg->getSrcAddress()][(int)par("numqueue")] = B_demand[reportmsg->getSrcAddress()];
	EV <<"ONU "<< reportmsg->getSrcAddress()<<"->"<< "Bandwitch Demandado: "<< B_demand[reportmsg->getSrcAddress()]<<"Bytes"<<endl;

	// SUMAMO EL ANCHO DE BANDA DEMANDADO DE CADA ONU PARA DESPUÉS COMPARARLO CON EL ANCHO DE BANDA MÁXIMO DEL CICLO
	sumbdemand = sumbdemand + B_demand[reportmsg->getSrcAddress()];

	// EJECUTAMOS EL MÉTODO DMB DEL OLT CUANDO NOS LLEGUE EL PAQUETE REPORT DE LA ÚLTIMA ONU DE LA RED
	if(reportmsg->getSrcAddress()==((int)par("numOnu")-1))
	{
		EV <<" EJECUTAMOS EL METODO CENTRALIZADO DEL OLT, METODO DMB."<<endl;
		EV <<" Suma del Ancho de Banda Demandado por todas las ONUs: "<<sumbdemand<<"Bytes"<<endl;

		// ASIGANCIÓN DE LOS SLA A CADA ONU CON SU RESPECTIVO PESO
		// RECORREMOS MEDIANTE ESTE BUCLE FOR TODOS LOS SLA DEFINIDOS EN LA RED
		for(int j=0; j<(int)par("numSLA"); j++)
		{
			// RECORREMOS MEDIANTE ESTE BUCLE FOR TODAS LAS ONUs ASOCIADAS A UN SLA
			for(int i=0; i<numonu_sla[j]; i++)
			{
				SLA_onu[id_onu+i] = Wsla[j]; // ASIGANAMOS A LA VARIABLE SLA_onu[] EL VALOR DEL PESO DEL SLA AL QUE ESTA ASOCIADA ESA ONU
				EV <<" ONU "<<id_onu+i<<": Peso="<<Wsla[j]<<endl; // VISUALIZAMOS EL PESO ASOCIADO A CADA ONU
				numsla[id_onu+i] = j; // INTRODUCIMOS EN LA VARIABLE numsla[] EL IDENTIFICADOR DEL SLA PARA CADA ONU YA QUE LO UTILIZAREMOS PARA RECOGER EL RETARDO DE CADA SLA
				// MEDIANTE ESTE IF, VAMOS INCREMENTANDO EL IDENTIFICADOR DE LA ONU QUE
				if(i==(numonu_sla[j]-1))
				{
					id_onu=id_onu+1+i;
				}
			}
		}
		id_onu=0; // IGUALAMOS EL IDENTIFICADOR DE LA ONU AL VALOR 0

		// DEFINIMOS EL ANCHO DE BANDA MAXIMO
		W_min = 0.34; // PESO MÍNIMO CON VALOR FIJO DE 0.34
		long_max = B_cycle/(int)par("numOnu"); // LONGITUD MÁXIMA QUE TIENE UNA ONU PARA TRANSMITIR DEPENDIENDO DEL B_cycle Y DEL NÚMERO DE ONUs
		B_basico = W_min*long_max; // ANCHO DE BANDA BASICO PARA TRANSMITIR QUE TIENE CADA ONU Y LO VISUALIZAMOS POR PANTALLA
		EV <<" Ancho de Banda Basico: "<<B_basico<<endl;

		// RECORREMOS MEDIANTE ESTE BUCLE FOR LOS SLAs DEFINIDOS EN NUESTRA RED PARA REALIZAR EL SUMATORIO PARA CALCULAR EL ANCHO DE BANDA ASOCIADO A CADA SLA
		for(int i=0; i<(int)par("numSLA"); i++)
		{
			sumatorio = sumatorio + (numonu_sla[i]*Wsla[i]); // CALCULAMOS EL SUMATORIO Y LO VISUALIZAMOS POR PANTALLA
			EV <<" Sumatorio: "<<sumatorio<<endl;
		}

		// RECORREMOS MEDIANTE ESTE BUCLE FOR TODAS LAS ONUs PARA CALCULAR EL ANCHO DE BANDA DE CADA ONU ASIGNADO POR EL SLA QUE CORRESPONDE A CADA ONU
		for(int j=0; j<(int)par("numOnu"); j++)
		{
			B_ex_sla[j] = (B_cycle - (B_basico*(int)par("numOnu")))*SLA_onu[j]/sumatorio; // CALCULAMOS EL ANCHO DE BANDA ASOCIADO A CADA ONU SEGUN EL SLA ASOCIADO A LA ONU
			EV <<" Ancho de Banda de SLA de la ONU"<<j<<": "<<B_ex_sla[j]<<endl; // VISUALIZAMOS EL ANCHO DE BANDA
		}
		// RECORREMOS MEDIANTE ESTE BUCLE FOR TODAS LAS ONUs PARA CALCULAR EL ANCHO DE BANDA MÁXIMO DE CADA ONU
		for(int j=0; j<(int)par("numOnu"); j++)
		{
			B_max_dmb[j] = B_basico + B_ex_sla[j]; // CALCULAMOS EL ANCHO DE BANDA MÁXIMO Y LO VISUALIZAMOS POR PANTALLA
			EV <<" Ancho de Banda Maximo de la ONU"<<j<<": "<<B_max_dmb[j]<<endl;
		}
		sumatorio = 0; // DAMOS EL VALOR 0 AL SUMATORIO PARA QUE NO SE INCREMENTE

		// COMPARAMOS SI LA SUMA TOTAL DE ANCHO DE BANDA DEMANDADO ES MAYOR O MENOR QUE EL ANCHO DE BANDA MÁXIMO DEL CICLO
		if(sumbdemand < B_cycle)
		{
			B_alloc[0] = B_demand[0] + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA DEMANDADO MAS EL TAMAÑO DEL PAQUETE REPORT
			// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGANDO
			EV <<"Ancho de Banda Asignado ONU 0: "<<B_alloc[0]<<endl;
			// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
			table_module->table_olt_report[0][(int)par("numqueue")+1] = B_alloc[0];
			EV <<"ONU "<< 0<<"->"<< "Bandwitch Asignado: "<< B_alloc[0]<<"Bytes"<<endl;

			t_slot[0] = B_alloc[0]*8/txrate; // ASIGNAMOS EL TIEMPO DE SLOT PARA LA ONU 0

			time_tx_onu0 = simTime() + delay + tasa_tx_gate; // TIEMPO DE TRANSMISIÓN PARA LA ONU 0 CON DISTANCIAS FIJAS
			EV <<" Tiempo de inicio de transmisión de la ONU 0: "<<time_tx_onu0<<endl;

			// CREAMOS EL PAQUETE GATE QUE MANDA EL OLT PARA LA ONU 0
			GATEmsg *packet = new GATEmsg("gate");
			packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
			packet->setDestAddress(0); // DIRECCIÓN DE DESTINO
			packet->setByteLength(64); // TAMAÑO DEL PAQUETE GATE
			packet->setLambdagate(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE GATE
			packet->setKind(0); // IDENTIFICADOR DEL PAQUETE GATE
			packet->setGrant_IntervalTxArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DE SLOT
			packet->setNumsla(numsla[0]); // IDENTIFICADOR DEL SLA DE LA ONU DE DESTINO

			// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA DE SLOT GENERAL O UNO PARA CADA COLA
			if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
			{
				B_slot[0]= B_alloc[0]; // DEFINIMOS ANCHO DE BANDA DE SLOT
				packet->setGrant_IntervalTx(0,B_slot[0]);
			}
			else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
			{
				//FALTA ALGORITMO PARA ASIGNAR POR COLAS!!!!!!!!!
				// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA DE SLOT PARA CADA COLA
				for(int b=0; b<(int)par("numqueue"); b++)
				{
					B_slot[b] = B_alloc[b]; // DEFINIMOS EL ANCHO DE BANDA DE SLOT PARA CADA COLA
					packet->setGrant_IntervalTx(b,B_slot[b]);
					EV <<"Ancho de Banda de Slot "<<b<<" "<<B_slot[b]<<endl;
				}
			}
			packet->setGrant_IniTime(time_tx_onu0); // TIEMPO DE INICIO DE TRANSMISIÓN
			packet->setTimereport(table_module->table_olt_report_time[0]); // PASAMOS A ESTE CAMPO DESDE LA TABLA DEL MÓDULO OLT_TABLE EL TIEMPO CUANDO SE ENVIA EL REPORT EN LA ONU

			// VISUALIZAMOS POR PANTALLA LOS CAMPOS DEL PAQUETE GATE
			EV <<" Creamos el paquete gate para la Onu "<<packet->getDestAddress()<<endl;
			EV <<" Paquete Gate."<<endl;
			EV <<" Origen OLT ID: "<<packet->getSrcAddress()<<endl;
			EV <<" Destino ONU "<<packet->getDestAddress()<<endl;
			EV <<" Longitud de onda de envio, Lambda "<< packet->getLambdagate()<<endl;
			EV <<" Tipo "<<packet->getKind()<<endl;
			EV <<" Tiempo inicial Tx "<<packet->getGrant_IniTime()<<endl;
			EV <<" SLA: "<<packet->getNumsla()<<endl;
			EV <<"  "<<endl;

			// ENVIAMOS LOS PAQUETES GATE MEDIANTE EL ENVIO RETARDADO
			sendDelayed(packet, tasa_tx_gate, "mactxOut");

			tstarttime = time_tx_onu0; // ASIGNAMOS A LA VARIABLE tstarttime EL TIEMPO DE INICIO DE TRANSMISIÓN DE LA ONU 0

			// CREAMOS CON EL BUCLE FOR LOS PAQUETES GATE PARA LAS DEMAS ONUS
			for(int i=1; i<(int)par("numOnu"); i++)
			{
				B_alloc[i] = B_demand[i] + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA DEMANDADO MAS EL TAMAÑO DEL PAQUETE REPORT
				// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGNADO
				EV <<" Ancho de Banda Asigando ONU "<<i<<": "<<B_alloc[i]<<endl;
				// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
				table_module->table_olt_report[i][(int)par("numqueue")+1] = B_alloc[i];
				EV <<"ONU "<< i<<"->"<< "Bandwitch Asignado: "<< B_alloc[i]<<"Bytes"<<endl;

				t_slot[i] = B_alloc[i]*8/txrate; //ASIGNAMOS EL TIEMPO DE SLOT PARA CADA ONU

				//ASIGNAMOS EL TIEMPO DE INICIO DE TRANSMISION DE LAS ONUS Y LO VISUALIZAMOS POR PANTALLA
				tstarttime = tstarttime + T_guarda + t_slot[i-1];
				EV <<" Tiempo de tslot de la onu "<<i-1<<" "<<t_slot[i-1]<<endl;

				// CREAMOS EL PAQUETE GATE QUE MANDA EL OLT PARA LAS DEMÁS ONUS
				GATEmsg *packet = new GATEmsg("gate");
				packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
				packet->setDestAddress(i); // DIRECCIÓN DE DESTINO
				packet->setByteLength(64); // TAMAÑO DEL PAQUETE GATE
				packet->setLambdagate(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE GATE
				packet->setKind(0); // IDENTIFICADOR DEL PAQUETE GATE
				packet->setGrant_IntervalTxArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DE SLOT
				packet->setNumsla(numsla[i]); // IDENTIFICADOR DEL SLA DE LA ONU DE DESTINO

				// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA DE SLOT GENERAL O UNO PARA CADA COLA
				if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
				{
					B_slot[0]= B_alloc[i]; // DEFINIMOS ANCHO DE BANDA DE SLOT
					packet->setGrant_IntervalTx(0,B_slot[0]);
				}
				else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
				{
					//FALTA ALGORITMO PARA ASIGNAR POR COLAS!!!!!!!!!
					// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA DE SLOT PARA CADA COLA
					for(int b=0; b<(int)par("numqueue"); b++)
					{
						B_slot[b] = B_alloc[i]; // DEFINIMOS EL ANCHO DE BANDA DE SLOT PARA CADA COLA
						packet->setGrant_IntervalTx(b,B_slot[b]);
						EV <<" Ancho de Banda de Slot "<<b<<" "<<B_slot[b]<<endl;
					}
				}
				packet->setGrant_IniTime(tstarttime); // TIEMPO DE INICIO DE TRANSMISIÓN

				// VISUALIZAMOS POR PANTALLA TODOS LOS CAMPOS DEL PAQUETE GATE
				EV <<" Creamos el paquete gate para la Onu "<<packet->getDestAddress()<<endl;
				EV <<" Paquete Gate."<<endl;
				EV <<" Origen OLT ID: "<<packet->getSrcAddress()<<endl;
				EV <<" Destino ONU "<<packet->getDestAddress()<<endl;
				EV <<" Longitud de onda de envio, Lambda "<< packet->getLambdagate()<<endl;
				EV <<" Tipo "<<packet->getKind()<<endl;
				EV <<" Tiempo iniciar Tx "<<packet->getGrant_IniTime()<<endl;
				EV <<" SLA: "<<packet->getNumsla()<<endl;
				EV <<"  "<<endl;

				// ENVIAMOS LOS PAQUETES GATE MEDIANTE EL ENVIO RETARDADO
				sendDelayed(packet, tasa_tx_gate, "mactxOut");

			}

			sumbdemand = 0; // PONEMOS A 0 EL VALOR DE LA SUMA DEL ANCHO DE BANDA DEMANDADO DE TODAS LAS ONUS PARA EL PRÓXIMO CICLO
		}
		else if(sumbdemand > B_cycle)
		{
			//RECORREMOS LAS ONUS PARA VER SI EL ANCHO DE BANDA DEMANDADO ES MAYOR O MENOR QUE EL ANCHO DE BANDA MÁXIMO
			for(int i=0; i<(int)par("numOnu"); i++)
			{
				EV <<" ONU "<<i<<endl; // VISUALIZAMOS EN LA ONU EN LA QUE NOS ENCONTRAMOS

				// COMPARAMOS SI EL ANCHO DE BANDA DEMANDADO ES MAYOR O MENOR QUE EL ANCHO DE BANDA MÁXIMO
				if(B_demand[i] <= B_max_dmb[i])
				{
					B_alloc[i] = B_demand[i] + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA DEMANDADO MAS EL TAMAÑO DEL PAQUETE REPORT
					// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGNADO
					EV <<" Ancho de Banda Asigando ONU "<<i<<": "<<B_alloc[i]<<endl;
					// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
					table_module->table_olt_report[i][(int)par("numqueue")+1] = B_alloc[i];
					EV <<"ONU "<< i<<"->"<< "Bandwitch Asignado: "<< B_alloc[i]<<"Bytes"<<endl;

					// GUARDAMOS EL ANCHO DE BANDA QUE SOBRA EN LA VARIABLE B_SOBRA Y LO VISUALIZAMOS POR PANTALLA
					B_sobra = B_sobra + (B_max_dmb[i] - B_demand[i]); //vemos el ancho de banda que sobra
					EV <<" Ancho de Banda que Sobra: "<<B_sobra<<endl;
				}
				else if(B_demand[i] > B_max_dmb[i])
				{
					B_alloc[i] = B_max_dmb[i] + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA MÁXIMO MÁS EL TAMAÑO DEL PAQUETE REPORT
					// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGNADO
					EV <<" Ancho de Banda Asigando ONU "<<i<<": "<<B_alloc[i]<<endl;
					// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
					table_module->table_olt_report[i][(int)par("numqueue")+1] = B_alloc[i];
					EV <<"ONU "<< i<<"->"<< "Bandwitch Asignado: "<< B_alloc[i]<<"Bytes"<<endl;

					// GUARDAMOS EL ANCHO DE BANDA QUE SE DEMANDA EN EXCESO EN LA VARIABLE B_exceded Y LO VISUALIZAMOS POR PANTALLA
					B_exceded = B_exceded + (B_demand[i] - B_max_dmb[i]);
					EV <<" Ancho de Banda en Exceso: "<<B_exceded<<endl;
				}
			}

			//AHORA RECORREMOS LAS ONUS QUE DEMANDAN MÁS ANCHO DE BANDA QUE EL MÁXIMO PARA ASIGNARLE UNA PARTE PROPORCIONAL DE LO QUE SOBRA
			for(int i=0; i<(int)par("numOnu"); i++)
			{
				// COMPARAMOS SI EL ANCHO DE BANDA DEMANDADO ES MAYOR QUE EL ANCHO DE BANDA MÁXIMO
				if(B_demand[i] > B_max_dmb[i])
				{
					// CALCULAMOS EL ANCHO DE BANDA PROPORCINAL QUE ASIGNAREMOS A LA ONU QUE PIDE UN ANCHO DE BANDA EN EXCESO
					B_extra[i] = B_sobra*(B_demand[i] - B_max_dmb[i])/B_exceded;

					// ASIGNAMOS EL ANCHO DE BANDA TOTAL A LA ONU Y LO CARGAMOS EN LA TABLA EN LA COLUMNA DE ANCHO DE BANDA ASIGNADO
					B_alloc[i] = B_alloc[i] + B_extra[i]; // ANCHO DE BANDA ASIGANDO TOTAL
					// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
					table_module->table_olt_report[i][(int)par("numqueue")+1] = B_alloc[i];
					EV <<"ONU "<< i<<"->"<< "Bandwitch Asignado: "<< B_alloc[i]<<"Bytes"<<endl;
				}
			}

			t_slot[0] = B_alloc[0]*8/txrate; //ASIGNAMOS EL TIEMPO DE SLOT PARA LA ONU 0

			//ASIGNAMOS EL TIEMPO DE INICIO DE TRANSMISION DE LA PRIMERA ONU Y LO VISUALIZAMOS POR PANTALLA
			time_tx_onu0 = simTime() + delay + tasa_tx_gate; // TIEMPO DE TRANSMISIÓN PARA LA ONU 0 CON DISTANCIAS FIJAS
			EV <<" Tiempo de inicio de transmisión de la ONU 0: "<<time_tx_onu0<<endl;

			//CREAMOS EL PAQUETE GATE PARA LA ONU 0
			GATEmsg *packet = new GATEmsg("gate");
			packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
			packet->setDestAddress(0); // DIRECCIÓN DE DESTINO
			packet->setByteLength(64); // TAMAÑO DEL PAQUETE GATE
			packet->setLambdagate(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE GATE
			packet->setKind(0); // IDENTIFICADOR DEL PAQUETE GATE
			packet->setGrant_IntervalTxArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DE SLOT
			packet->setNumsla(numsla[0]); // IDENTIFICADOR DEL SLA DE LA ONU DE DESTINO

			// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA DE SLOT GENERAL O UNO PARA CADA COLA
			if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
			{
				B_slot[0]= B_alloc[0]; // DEFINIMOS ANCHO DE BANDA DE SLOT
				packet->setGrant_IntervalTx(0,B_slot[0]);
			}
			else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
			{
				//FALTA ALGORITMO PARA ASIGNAR POR COLAS!!!!!!!!!
				// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA DE SLOT PARA CADA COLA
				for(int b=0; b<(int)par("numqueue"); b++)
				{
					B_slot[b] = B_alloc[b]; // DEFINIMOS EL ANCHO DE BANDA DE SLOT PARA CADA COLA
					packet->setGrant_IntervalTx(b,B_slot[b]);
					EV <<" Ancho de Banda de Slot "<<b<<" "<<B_slot[b]<<endl;
				}
			}
			packet->setGrant_IniTime(time_tx_onu0); // TIEMPO DE INICIO DE TRANSMISIÓN
			packet->setTimereport(table_module->table_olt_report_time[0]); // PASAMOS A ESTE CAMPO DESDE LA TABLA DEL MÓDULO OLT_TABLE EL TIEMPO CUANDO SE ENVIA EL REPORT EN LA ONU

			// VISUALIZAMOS POR PANTALLA TODOS LOS CAMPOS DEL PAQUETE GATE
			EV <<" Creamos el paquete gate para la Onu "<<packet->getDestAddress()<<endl;
			EV <<" Paquete Gate."<<endl;
			EV <<" Origen OLT ID: "<<packet->getSrcAddress()<<endl;
			EV <<" Destino ONU "<<packet->getDestAddress()<<endl;
			EV <<" Longitud de onda de envio, Lambda "<< packet->getLambdagate()<<endl;
			EV <<" Tipo "<<packet->getKind()<<endl;
			EV <<" Tiempo inicial Tx "<<packet->getGrant_IniTime()<<endl;
			EV <<" SLA: "<<packet->getNumsla()<<endl;
			EV <<"  "<<endl;

			// ENVIAMOS LOS PAQUETES GATE MEDIANTE EL ENVIO RETARDADO
			sendDelayed(packet, tasa_tx_gate, "mactxOut");

			tstarttime = time_tx_onu0; // ASIGNAMOS A LA VARIABLE tstarttime EL TIEMPO DE INICIO DE TRANSMISIÓN DE LA ONU 0

			// CREAMOS EL PAQUETE GATE QUE MANDA EL OLT PARA LAS DEMÁS ONUS
			for(int i=1; i<(int)par("numOnu"); i++)
			{
				t_slot[i] = B_alloc[i]*8/txrate;//ASIGNAMOS EL TIEMPO DE SLOT PARA CADA ONU

				//ASIGNAMOS EL TIEMPO DE INICIO DE TRANSMISION DE LAS ONUS Y LO VISUALIZAMOS POR PANTALLA
				tstarttime = tstarttime + T_guarda + t_slot[i-1];
				EV <<" Tiempo de tslot de la onu "<<i-1<<" "<<t_slot[i-1]<<endl;

				// CREAMOS EL PAQUETE GATE QUE MANDA EL OLT PARA LAS DEMÁS ONUS
				GATEmsg *packet = new GATEmsg("gate");
				packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
				packet->setDestAddress(i); // DIRECCIÓN DE DESTINO
				packet->setByteLength(64); // TAMAÑO DEL PAQUETE GATE
				packet->setLambdagate(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE GATE
				packet->setKind(0); // IDENTIFICADOR DEL PAQUETE GATE
				packet->setGrant_IntervalTxArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DE SLOT
				packet->setNumsla(numsla[i]); // IDENTIFICADOR DEL SLA DE LA ONU DE DESTINO

				// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA DE SLOT GENERAL O UNO PARA CADA COLA
				if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
				{
					B_slot[0]= B_alloc[i]; // DEFINIMOS ANCHO DE BANDA DE SLOT
					packet->setGrant_IntervalTx(0,B_slot[0]);
				}
				else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
				{
					//FALTA ALGORITMO PARA ASIGNAR POR COLAS!!!!!!!!!
					// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA DE SLOT PARA CADA COLA
					for(int b=0; b<(int)par("numqueue"); b++)
					{
						B_slot[b] = B_alloc[i]; // DEFINIMOS EL ANCHO DE BANDA DE SLOT PARA CADA COLA
						packet->setGrant_IntervalTx(b,B_slot[b]);
						EV <<" Ancho de Banda de Slot "<<b<<" "<<B_slot[b]<<endl;
					}
				}
				packet->setGrant_IniTime(tstarttime); // TIEMPO DE INICIO DE TRANSMISIÓN

				// VISUALIZAMOS POR PANTALLA TODOS LOS CAMPOS DEL PAQUETE GATE
				EV <<" Creamos el paquete gate para la Onu "<<packet->getDestAddress()<<endl;
				EV <<" Paquete Gate."<<endl;
				EV <<" Origen OLT ID: "<<packet->getSrcAddress()<<endl;
				EV <<" Destino ONU "<<packet->getDestAddress()<<endl;
				EV <<" Longitud de onda de envio, Lambda "<< packet->getLambdagate()<<endl;
				EV <<" Tipo "<<packet->getKind()<<endl;
				EV <<" Tiempo iniciar Tx "<<packet->getGrant_IniTime()<<endl;
				EV <<" SLA: "<<packet->getNumsla()<<endl;
				EV <<"  "<<endl;

				// ENVIAMOS LOS PAQUETES GATE MEDIANTE EL ENVIO RETARDADO
				sendDelayed(packet, tasa_tx_gate, "mactxOut");

			}

			sumbdemand = 0; // PONEMOS A 0 EL VALOR DE LA SUMA DEL ANCHO DE BANDA DEMANDADO DE TODAS LAS ONUS PARA EL PRÓXIMO CICLO
			B_sobra = 0; // PONEMOS A 0 EL VALOR DEL ANCHO DE BANDA DE SOBRA PARA EL PRÓXIMO CICLO
			B_exceded = 0; // PONEMOS A 0 EL VALOR DEL ANCHO DE BANDA EN EXCESO PARA EL PRÓXIMO CICLO
		}
	}

	delete reportmsg; // BORRAMOS EL MENSAJE REPORT
}


void MAC_OLT::centralizedmethod(cMessage *msg) {
    // CHEQUEAMOS EL PAQUETE REPORT QUE HA LLEGADO
    REPORTmsg *reportmsg = check_and_cast<REPORTmsg *>(msg);

    //DEFINICIÓN DE VARIABLES
    // tasa de transmisión del canal (1 Gpbs)
    double txrate = (int)par("txrate");
    //tasa de transmisión de un mensaje Gate (64 bytes)
    double tasa_tx_gate = 512/txrate;
    //tasa de transmisión de un mensaje Report (64 bytes)
    double tasa_tx_report = 512/txrate;
    //Tiempo de ciclo máximo en milisegundos del estándar (2 ms)
    double T_cycle = 0.002;
    //Tiempo de guarda entre la transmisión de ONTs diferentes
    double T_guarda =0.000001;
    //Tiempo de guarda total de todas las ONTs en un ciclo
    double T_guarda_nonu = 0.000001*(int)par("numOnu");
    //Tasa de transmisión total de los paquetes report de todas las ONTs en un ciclo
    double T_report_nonu = tasa_tx_report*((int)par("numOnu"));
    // tiempo de ciclo final aprovechado
    double T_cycle_total = T_cycle - T_guarda_nonu - T_report_nonu;
    //ancho de banda máximo del ciclo en bytes (carga útil)
    double B_cycle = txrate*T_cycle_total/8;

    //ancho de banda que ocupa el mensaje  Report (bytes)
    double B_report = txrate*tasa_tx_report/8;
    //ancho de banda de slot
    double B_slot[(int)par("numqueue")];
    // identificador de la direccion del OLT (identificador 9)
    int srcAddress = 9;
    // velocidad de la luz (en m/s)
    double velocidad = 300000000;
    //Variable que contiene la longitud total de la red
    double longitud_total_red;

    // Retardo RTT/2 en la fibra óptica (20 km de la red GPON) en la variable “delay” (ya definida)
    longitud_total_red = ((double)par("longpon1")+(double)par("longpon2"));
    delay = (longitud_total_red*3)/(velocidad*2);
    EV<< "delay "<< delay << endl;


    //Se lee el tiempo cuando el envío del mensaje Report de la ONT y lo guardamos en el vector de la tabla
    table_module->table_olt_report_time[0] = reportmsg->getTimesendreport();
    //Final de la definición de las variables


//PASOS A SEGUIR EN EL ALGORITMO QUE TENÉIS QUE DISEÑAR


/*1. EXTRAER DEL MENSAJE DE LLEGADA REPORT (mensaje reportmsg) EL ANCHO DE BANDA DEMANDADO POR LA ONT QUE ENVIÓ EL MENSAJE. Para ello siga los siguientes pasos:

1.1.    Sumamos el estado de las colas (en bytes) de la ONT y cuyo valor está contenido en el mensaje report de llegada. Para ello podéis crear un bucle “for” que recorra  todas las colas siendo el número de colas el parámetro/“(int)par("numqueue")”. La variable “numqueue” denota el número de colas en la ONT. Sin embargo, para simplificar tened en cuenta que esta práctica solamente se considera una única cola. Para extraer el estado de las colas que llega en el mensaje report, escribid la sentencia:
reportmsg->getQueue_estado(i)
1.2.    El estado de las colas (en bytes) lo cargáis a la variable “sumqueue”. No defináis ninguna variable, ya están definidas.
*/
    sumqueue = reportmsg->getQueue_estado(0);
/*
1.3.    En el caso de que la suma total de todas las colas de la ONT (variable “sumqueue”) sea “0”, es decir, la ONT no demanda ancho de banda para el ciclo siguiente, le damos un valor garantizado de 1500 bytes (por si llegan paquetes entre ciclos consecutivos).
*/
    if (sumqueue == 0)
        sumqueue = 1500;
/*
1.4.    Una vez que conocemos la demanda total de la ONT (contenida en “sumqueue”) se asigna esta demanda al vector global del ancho de banda demandado de la ONT denominado “B_demand[i]” donde i denota la dirección de la ONT. Podrá extraer la dirección de la ONT  a partir del mensaje report  que ha llegado se realiza con la sentencia “reportmsg->getSrcAddress()”.
*/
    B_demand[reportmsg->getSrcAddress()] = sumqueue;
/*
1.5.    A continuación, se actualiza el ancho de banda demandado total de todas ONTs en ese ciclo contenido en la variable global  “sumbdemand” (no la defina, ya está definida), sumando a dicha variable el valor de “sumqueue”.
*/
    sumbdemand += sumqueue;
/*
1.6.    A continuación, se inicializa a cero la variable local “sumqueue” para la siguiente ONT para cuando llegue el mensaje report de la siguiente ONT.
*/
    sumqueue = 0;
/*
1.7.    Finalmente, se guarda en la tabla del modulo “olt_module” el ancho de banda demandado por la ONT  escribiendo la siguiente sentencia: table_module->table_olt_report[reportmsg->getSrcAddress()][(int)par("numqueue")] = B_demand[reportmsg->getSrcAddress()]
*/
    table_module->table_olt_report[reportmsg->getSrcAddress()][(int)par("numqueue")] = B_demand[reportmsg->getSrcAddress()];
/*

/*2. COMPROBAMOS SI EJECUTAMOS EL DBA CENTRALIZADO  CUANDO NOS LLEGUE EL PAQUETE REPORT DE LA ULTIMA ONT. Para ello siga los siguientes pasos:

2.1.    Comprobar si ha llegado mensaje de la ONT 16 (última ONT) mediante método “reportmsg->getSrcAddress()”.
2.2.    Si  ha llegado se ejecuta el método DBA para asignar recursos a las ONTs para el ciclo siguiente.
*/
        if (reportmsg->getSrcAddress() == 15) {

/*3. DISEÑAMOS EL ALGORITMO DBA PARA ASIGNAR RECURSOS PARA EL CICLO SIGUIENTE. Para ello siga los siguientes pasos:

3.1.     Recorremos todas las ONTs para hacer la asignación de ancho de banda (hacer bucle desde 0 hasta 15 (16 ONUs)), ya que la primera ONT tiene el identificador “0”.
*/
            while(sumbdemand < B_cycle/2) {
                T_cycle /= 2;
                T_cycle_total = T_cycle - T_guarda_nonu - T_report_nonu;
                B_cycle = txrate*T_cycle_total/8;
            }
            for(int i=0; i<16; i++) {
/*
3.2.    Hacemos la asignación de ancho de banda para cada ONT del bucle  y la cargamos en el vector global “B_alloc[i]” (ya está definido, no lo defina). La asignación se hará de forma proporcional a la demanda de cada ONT, por lo que  tan solo serán necesarias las variables:
ancho de banda demandado de cada ONT en la variable “B_demand[i]”,
la suma de las demandas de las 16 ONTs en “sumbdemand”
y el ancho de banda contenido en el ciclo “B_cycle” (este valor ya es el ancho de banda útil, se le ha quitado el ancho de banda del mensaje report y el tiempo de guarda). Todos los valores de las variables y vectores están en bytes.
*/
                B_alloc[i] = B_cycle*(B_demand[i]/sumbdemand);
/*
3.3.    Una vez asignado el ancho de banda hay que sumarle a “B_alloc[i]” el ancho de banda que ocupa un mensaje Report (64 bytes), y cargado en la variable “B_report” (ya está definida, es global).
*/
                B_alloc[i] += B_report;
/*
3.4.    La vector global “B_alloc[i]” la pasamos a tiempo y lo asignamos al vector también global “t_slot[i]”  (ya está definido) sabiendo que “B_alloc[i]”está en bytes y la tasa de transmisión de 1 Gbps está ya en la variable definida “txrate”.
*/
                t_slot[i] = 8 * B_alloc[i] / txrate;

/*
3.5.    A continuación cargamos el ancho de banda asignado “B_alloc[i]” en la tabla de seguimiento del OLT para mantenerlo ciclo tras ciclo añadiendo la siguiente sentencia
 “table_module->table_olt_report[i][(int)par("numqueue")+1] = B_alloc[i];
*/
                table_module->table_olt_report[i][(int)par("numqueue")+1] = B_alloc[i];
/*
3.6.    A continuación, se calcula el tiempo de transmisión de todas las ONTs en el siguiente ciclo, cargándolo en el variable global “tstarttime” ya definida (no es un vector sino una variable global). Tenga en cuenta que el tiempo de transmisi´n No es lo mismo la ONU 0 que el resto de ONUs del ccilo
*/
                if (i == 0)
                    tstarttime = simTime()+delay+tasa_tx_gate;
                else
                    tstarttime += 8 * B_alloc[i-1] / txrate + T_guarda;
/*
3.7.     En el siguiente paso, se crean los mensajes GATE (uno para cada ONT) y es el que mandará el OLT a todas las ONTs para asignar el ancho de banda asignado “B_alloc[i]” y el tiempo en el que comenzarán a transmitir “tstarttime” en el ciclo siguiente. Por lo tanto metemos los datos pertinentes en el paquete GATE creado (de nombre packet):
GATEmsg *packet = new GATEmsg("gate");
packet->setSrcAddress(srcAddress);
packet->setDestAddress(i);
packet->setByteLength(64);
packet->setLambdagate(0);
packet->setKind(0);
packet->setGrant_IntervalTxArraySize((int)par("numqueue"));
packet->setNumsla(numsla[i]);
packet->setGrant_IntervalTx(0,B_alloc[i]);
packet->setGrant_IniTime(tstarttime);
*/
                GATEmsg *packet = new GATEmsg("gate");
                packet->setSrcAddress(srcAddress);
                packet->setDestAddress(i);
                packet->setByteLength(64);
                packet->setLambdagate(0);
                packet->setKind(0);
                packet->setGrant_IntervalTxArraySize((int)par("numqueue"));
                packet->setNumsla(numsla[i]);
                packet->setGrant_IntervalTx(0,B_alloc[i]);
                packet->setGrant_IniTime(tstarttime);

/*
3.8.    A continuación se envían los paquetes GATE a la OLT mediante la sentencia el envío retardado el tiempo de transmisión del paquete GATE y cargado en la variable “tasa_tx_gate” (ya definida), en concreto escribiendo la sentencia:

*/
                EV << " [+] ONU " << i << ":\n - TiempoTX = " << tstarttime << "\n - BW = " << B_alloc[i] << "" << std::endl;
                sendDelayed(packet, tasa_tx_gate, "mactxOut");
/*
3.9.    Finalmente, Inicializamos a cero las variables necesarias para el ciclo siguiente, tales como la suma de ancho de banda de las ONUs en el ciclo “sumbdemand”.
*/
            }
            sumbdemand = 0;

        }

/*4. BORRAMOS EL MENSAJE REPORT QUE HA LLEGADO INDEPENDIENTEMENTE DE LA ONT QUE SEA. Para ello siga los siguientes pasos:

4.1.    Finalmente tiene que borrar mensaje REPORT con método “delete”*/

        delete reportmsg;

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN POLLINGMETHOD_IPACT(CMESSAGE *MSG)--> FUNCIÓN QUE SE INVOCA CON EL MENSAJE O PAQUETE COMO PARÁMETRO CADA VEZ QUE      //
//			LLEGUE AL OLT EL PAQUETE REPORT  DE UNA ONU DE LA RED Y TENEMOS SELECCIONADO EL PARÁMETRO 							//
//			oltmethod_Centralized0_Polling1 EN EL OMNETPP.INICON VALOR 1.														//
//			ESTE ALGORITMO SE ENCARGA DE ASIGNAR EL INSTANTE DE INICIO DE LA TRANSMISIÓN Y EL ANCHO DE BANDA DESIGNADO PARA 	//
//			TRANSMITIR DE CADA ONU CADA VEZ QUE LE LLEGA EL PAQUETE REPORT DE UNA ONU DE LA RED. CREA EL PAQUETE GATE CON 		//
//			DICRECCIÓN DE DESTINO LA ONU QUE ENVIO EL PAQUETE REPORT Y LE ENVIA HACIA LA ONU CON LOS VALORES CORRESPONDIENTES 	//
//			DE TRANSMISIÓN HACIA LA ONU, LA CUAL TRANSMITE	EN EL INSTANTE DESIGNADO POR EL OLT Y UNA CANTIDAD DE BYTES			//
//			DESIGNADOS POR EL OLT.																								//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MAC_OLT::pollingmethod_IPACT(cMessage *msg)
{
	EV <<" EJECUTAMOS EL METODO IPACT DE POLLING EN EL OLT."<<endl;
	REPORTmsg *reportmsg = check_and_cast<REPORTmsg *>(msg); // CHEQUEAMOS EL PAQUETE REPORT

	//VARIABLES
	double txrate = (int)par("txrate"); // TASA DE TRANSMISIÓN EN BITS POR SEGUNDO
	double tasa_tx_gate = 512/txrate; // TASA DE TRANSMISIÓN DEL PAQUETE GATE DE 64 BYTES
	double tasa_tx_report = 512/txrate; // TASA DE TRANSMISIÓN DEL PAQUETE REPORT DE 64 BYTES
	double T_cycle = 0.002; // TIEMPO DE CICLO MAXIMO EN MILISEGUNDOS
	double T_guarda = 0.000005; // TIEMPO DE GUARDA QUE SE ESPERA ENTRA LA TRANSMISIÓN DE DOS ONUS
	double T_guarda_nonu = T_guarda*((int)par("numOnu")); // TIEMPO DE GUARDA TOTAL DE TODAS LAS ONUS
	double T_report_nonu = tasa_tx_report*((int)par("numOnu")); // TASA DE TRANSMISION TOTAL DE LOS PAQUETES REPORT DE TODAS LAS ONUS
	double T_cycle_total = T_cycle - T_guarda_nonu - T_report_nonu; // TIEMPO DE CICLO FINAL Y LO VISUALIZAMOS POR PANTALLA
	EV <<" Tiempo de ciclo total: "<<T_cycle_total<<"s"<<endl;
	double T_tx_onu; // TIEMPO DE TRANSMISIÓN DE UNA ONU
	long double B_cycle = txrate*T_cycle_total/8; // ANCHO DE BANDA MÁXIMO DEL CICLO EN BYTES
	EV <<" Ancho de banda del ciclo: "<<B_cycle<<"Bytes"<<endl;
	long double B_report = txrate*tasa_tx_report/8; // TAMAÑO DEL PAQUETE REPORT
	double B_slot[(int)par("numqueue")]; // VARIABLE DE ANCHO DE BANDA DE SLOT CON TAMAÑO EL NÚMERO DE COLAS QUE SE DEFINEN
	int srcAddress = 9; // DEFINICIÓN DEL IDENTIFICADOR DE LA DIRECCIÓN DE ORIGEN O FUENTE
	simtime_t time_tx_onu0; // TIEMPO DE TRANSIMISIÓN DE LA PRIMERA ONU
	int onu = reportmsg->getSrcAddress(); // VARIABLE QUE NOS INDICA EL IDENTIFICADOR DE LA ONU CORRESPONDIENTE
	int lengthmethod = (int)par("methodlength_longvariable0_longfija1");
	double velocidad = 300000000; // DEFINIMOS EL PARÁMETRO VELOCIDAD DE LA VELOCIDAD DE LA LUZ (EN M/S)
	cTopology topo; // DEFINIMOS UN PARÁMETRO DE LA TOPOLOGIA DE LA RED
	double longitud_total_red; // DEFINIMOS LA VARIABLE QUE NOS INDICA LA LONGITUD TOTAL DE LA RED
	int B_max; // ANCHO DE BANDA MÁXIMO PARA EL ALGORITMO IPACT

	// CALCULAMOS EL DELAY O RETARDO DEPENDIENDO DE LA LONGITUD DE NUESTRA RED
	switch(lengthmethod)
	{
		case 0:
			// MÉTODO DE LONGITUD VARIABLE
			topo.extractByParameter( "numlong" ); // EXTRAEMOS LOS NODOS DE NUESTRA RED QUE UTILIZAN EL PARÁMETRO numlong
			delay_pon1 = ((double)par("longpon1")*3)/(velocidad*2); // CALCULAMOS EL RETARDO DEL SEGMENTO DE LA RED QUE UNE EL OLT Y EL SPLITTER
			// RECORREMOS CON EL BUCLE FOR TODAS LAS ONUS PARA CALCULAR EL RETARDO DEL CANAL QUE UNE EL SPLITTER CON CADA ONU
			for(int i=0; i<(int)par("numOnu"); i++)
			{
				cModule *module = getParentModule()->getParentModule()->getSubmodule("onu", i); // DEFINIMOS EL PARÁMETRO MODULE QUE NOS INDICA EL CAMINO HASTA EL NODO DEL QUE QUEREMOS OBTENER INFORMACIÓN
				cTopology::Node *nodeonuOut = topo.getNodeFor(module); // NOMBRE DEL NODO QUE SACAMOS DEL GRAFO
				// RECORREMOS CON EL BUCLE FOR TODOS LOS ENLACES DE SALIDA QUE TIENE ESE NODO PARA OBTENER LA INFORMACIÓN QUE SOLICITAMOS
				for(int j=0; j<nodeonuOut->getNumOutLinks(); j++)
				{
					delay_pon2[i] = (check_and_cast<cDelayChannel*>(nodeonuOut->getLinkOut(j)->getLocalGate()->getChannel()))->getDelay();
					EV <<" Retardo Onu"<<i<<": "<<delay_pon2[i]<<endl; // VISUALIZAMOS EL VALOR DEL RETARDO
					delay_total[i] = delay_pon1 + delay_pon2[i]; // CALCULAMOS EL RETARDO TOTAL DE LA RED Y LO VISUALIZAMOS
					EV <<" Retardo Total de la red PON: "<<delay_total[i]<<endl;
				}
			}
			break;

		case 1:
			// MÉTODO DE LONGITUD FIJA
			longitud_total_red = ((double)par("longpon1")+(double)par("longpon2")); // DEFINIMOS EL PARÁMETRO QUE INDICA LA LONGITUD TOTAL DE LA RED EN METROS
			delay = (longitud_total_red*3)/(velocidad*2); // CALCULAMOS EL RETARDO O DELAY PARA LA RED SEGUN LA LONGITU QUE DEFINAMOS AL PRINCIPION DE LA SIMULACIÓN
			break;

		default:
			EV <<"Error al elegir el metodo de longitudes."<<endl;
			break;

	}

	// OBTENEMOS Y VISUALIZAMOS POR PANTALLA EL TIEMPO DE SIMULACION + DELAY CORRESPONDIENTE + TASA DE TRANSMISIÓN DEL PAQUETE GATE
	// COMPARAMOS SI SE TRATA DE LONGITUD DE LA RED VARIABLE O LONGITUD DE LA RED FIJA
	if((int)par("methodlength_longvariable0_longfija1")==0)
	{
		// MÉTODO DE LONGITUD VARIABLE
		// TIEMPO DE SIMULACION + DELAY CORRESPONDIENTE + TASA DE TRANSMISIÓN DEL PAQUETE GATE CON DISTANCIAS ALEATORIAS
		tiempo_sim_delay_datarate = simTime() + delay_total[onu] + tasa_tx_gate;
		EV <<" Tiempo de simulacion + delay + tasa tx gate: "<<tiempo_sim_delay_datarate<<" s."<<endl;
	}
	else if((int)par("methodlength_longvariable0_longfija1")==1)
	{
		// MÉTODO DE LONGITUD FIJA
		// TIEMPO DE SIMULACION + DELAY CORRESPONDIENTE + TASA DE TRANSMISIÓN DEL PAQUETE GATE CON DISTANCIAS FIJAS
		tiempo_sim_delay_datarate = simTime() + delay + tasa_tx_gate;
		EV <<" Tiempo de simulacion + delay + tasa tx gate: "<<tiempo_sim_delay_datarate<<" s."<<endl;
	}

	//VAMOS A CALCULAR EL ANCHO DE BANDA DEMANDADO Y LO GUARDAMOS EN LA TABLA
	EV <<" Calculamos el Bandwitch Demandado y lo guardamos en la tabla del OLT."<<endl;
	// SUMAMOS EL TAMAÑO DEL ESTADO DE LAS COLAS DE LA ONU QUE A MANDADO EL REPORT QUE LLEGA AL OLT
	for(int i=0; i<(int)par("numqueue"); i++)
	{
		sumqueue = sumqueue + reportmsg->getQueue_estado(i);
	}
	// SI LA SUMA TOTAL DEL TAMAÑO DE LAS COLAS ES 0, DAMOS UN VALOR PREDETERMINADO DE 20 BYTES
	if(sumqueue == 0)
	{
		sumqueue = 20;
	}

	// ASIGNAMOS LA SUMA TOTAL A LA VARIABLE DEL ANCHO DE BANDA DEMANDADO DE LA ONU
	B_demand[onu] = sumqueue;

	sumqueue = 0;// DAMOS EL VALOR 0 A LA SUMA DE LAS COLAS. DE ESTA MANERA LA INICIALIZAMOS DE NUEV O A 0

	// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE EL ANCHO DE BANDA DEMANDADO POR LA ONU Y LO VISUALIZAMOS POR PANTALLA
	table_module->table_olt_report[onu][(int)par("numqueue")] = B_demand[onu];
	EV <<"ONU "<< onu<<"->"<< "Bandwitch Demandado: "<< B_demand[onu]<<"Bytes"<<endl;

	//CALCULAMOS ANCHO DE BANDA MAXIMO DE CADA ONU DEPENDIENDO DEL SLA
	B_max = 15000; // ASIGNAMOS UN VALOR AL ANCHO DE BANDA MÁXIMO Y LO VISUALIZAMOS POR PANTALLA
	EV <<" Ancho de Banda Máximo "<<B_max<<endl;

	// EJECUTAMOS EL ALGORITMO IPACT YA QUE SE EJECUTA CADA VEZ QUE LLEGA UN MENSAJE REPORT DESDE LAS ONUS
	if(tiempo_tx_siguiente <= tiempo_sim_delay_datarate)
	{
		EV <<" CASO A. Tiempo de Transmisión siguiente menor."<<endl;

		// COMPARAMOS SI EL ANCHO DE BANDA DEMANDADO ES MAYOR O MENOR QUE EL ANCHO DE BANDA MÁXIMO
		if(B_demand[onu] <= B_max)
		{
			B_alloc[onu] = B_demand[onu] + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA DEMANDADO MAS EL TAMAÑO DEL PAQUETE REPORT
			// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGNADO
			EV <<" Ancho de Banda Asigando ONU "<<onu<<": "<<B_alloc[onu]<<endl;
			// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
			table_module->table_olt_report[onu][(int)par("numqueue")+1] = B_alloc[onu];
			EV <<"ONU "<< onu<<"->"<< "Bandwitch Asignado: "<< B_alloc[onu]<<"Bytes"<<endl;

			T_alloc[onu] = B_alloc[onu]*8/txrate; // CALCULAMOS EL TIEMPO DE TRANSMISIÓN DE LA ONU CON RESPECTO AL ANCHO DE BANDA ASIGNADO
		}
		else if(B_demand[onu] > B_max)
		{
			B_alloc[onu] = B_max + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA  MÁXIMO MÁS EL TAMAÑO DEL PAQUETE REPORT
			// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGNADO
			EV <<" Ancho de Banda Asigando ONU "<<onu<<": "<<B_alloc[onu]<<endl;
			// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
			table_module->table_olt_report[onu][(int)par("numqueue")+1] = B_alloc[onu];
			EV <<"ONU "<< onu<<"->"<< "Bandwitch Asignado: "<< B_alloc[onu]<<"Bytes"<<endl;

			T_alloc[onu] = B_alloc[onu]*8/txrate; // CALCULAMOS EL TIEMPO DE TRANSMISIÓN DE LA ONU CON RESPECTO AL ANCHO DE BANDA ASIGNADO
		}

		T_tx_onu = T_alloc[onu] + T_guarda; //CALCULAMOS EL TIEMPO DE TRANSMISION DE LA ONU

		//CREAMOS EL PAQUETE GATE PARA LA ONU
		GATEmsg *packet = new GATEmsg("gate");
		packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
		packet->setDestAddress(onu); // DIRECCIÓN DE DESTINO
		packet->setByteLength(64); // TAMAÑO DEL PAQUETE GATE
		packet->setLambdagate(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE GATE
		packet->setKind(0); // IDENTIFICADOR DEL PAQUETE GATE
		packet->setGrant_IntervalTxArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DE SLOT

		// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA DE SLOT GENERAL O UNO PARA CADA COLA
		if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
		{
			B_slot[0]= B_alloc[onu]; // DEFINIMOS ANCHO DE BANDA DE SLOT
			packet->setGrant_IntervalTx(0,B_slot[0]);
		}
		else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
		{
			//FALTA ALGORITMO PARA ASIGNAR POR COLAS!!!!!!!!!
			// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA DE SLOT PARA CADA COLA
			for(int b=0; b<(int)par("numqueue"); b++)
			{
				B_slot[b] = B_alloc[onu]; // DEFINIMOS EL ANCHO DE BANDA DE SLOT PARA CADA COLA
				packet->setGrant_IntervalTx(b,B_slot[b]);
				EV <<" Ancho de Banda de Slot "<<b<<" "<<B_slot[b]<<endl;
			}
		}
		packet->setGrant_IniTime(tiempo_sim_delay_datarate); // TIEMPO DE INICIO DE TRANSMISIÓN

		// VISUALIZAMOS POR PANTALLA TODOS LOS CAMPOS DEL PAQUETE GATE
		EV <<" Creamos el paquete gate para la Onu "<<packet->getDestAddress()<<endl;
		EV <<" Paquete Gate."<<endl;
		EV <<" Origen OLT ID: "<<packet->getSrcAddress()<<endl;
		EV <<" Destino ONU "<<packet->getDestAddress()<<endl;
		EV <<" Longitud de onda de envio, Lambda "<< packet->getLambdagate()<<endl;
		EV <<" Tipo "<<packet->getKind()<<endl;
		EV <<" Tiempo inicial Tx "<<packet->getGrant_IniTime()<<endl;
		EV <<"  "<<endl;

		// ENVIAMOS LOS PAQUETES GATE MEDIANTE EL ENVIO RETARDADO
		sendDelayed(packet, tasa_tx_gate, "mactxOut");

		//ACTUALIZAMOS EL TIEMPO DE INICIO DE TRANSMISION PARA LA SIGUIENTE ONU
		tiempo_tx_siguiente = tiempo_sim_delay_datarate + T_tx_onu;
		EV <<" Tiempo de Transmisión Siguiente: "<<tiempo_tx_siguiente<<endl;

	}
	else if(tiempo_tx_siguiente > tiempo_sim_delay_datarate)
	{
		EV <<" CASO B. Tiempo de Transmisión siguiente mayor"<<endl;

		// COMPARAMOS SI EL ANCHO DE BANDA DEMANDADO ES MAYOR O MENOR QUE EL ANCHO DE BANDA MÁXIMO
		if(B_demand[onu] <= B_max)
		{
			B_alloc[onu] = B_demand[onu] + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA DEMANDADO MAS EL TAMAÑO DEL PAQUETE REPORT
			// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGNADO
			EV <<" Ancho de Banda Asigando ONU "<<onu<<": "<<B_alloc[onu]<<endl;
			// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
			table_module->table_olt_report[onu][(int)par("numqueue")+1] = B_alloc[onu];
			EV <<"ONU "<< onu<<"->"<< "Bandwitch Asignado: "<< B_alloc[onu]<<"Bytes"<<endl;

			T_alloc[onu] = B_alloc[onu]*8/txrate; // CALCULAMOS EL TIEMPO DE TRANSMISIÓN DE LA ONU CON RESPECTO AL ANCHO DE BANDA ASIGNADO
		}
		else if(B_demand[onu] > B_max)
		{
			B_alloc[onu] = B_max + B_report; // DAMOS EL VALOR AL ANCHO DE BANDA ASIGNADO DEL ANCHO DE BANDA  MÁXIMO MÁS EL TAMAÑO DEL PAQUETE REPORT
			// VISUALIZAMOS POR PANTALLA EL ANCHO DE BANDA ASIGNADO
			EV <<" Ancho de Banda Asigando ONU "<<onu<<": "<<B_alloc[onu]<<endl;
			// GUARDAMOS EN LA TABLA DEL MÓDULO OLT_TABLE LA VARIABLE DEL ANCHO DE BANDA ASIGANDO Y LO VISUALIZAMOS POR PANTALLA
			table_module->table_olt_report[onu][(int)par("numqueue")+1] = B_alloc[onu];
			EV <<"ONU "<< onu<<"->"<< "Bandwitch Asignado: "<< B_alloc[onu]<<"Bytes"<<endl;

			T_alloc[onu] = B_alloc[onu]*8/txrate; // CALCULAMOS EL TIEMPO DE TRANSMISIÓN DE LA ONU CON RESPECTO AL ANCHO DE BANDA ASIGNADO
		}

		T_tx_onu = T_alloc[onu] + T_guarda; //CALCULAMOS EL TIEMPO DE TRANSMISION DE LA ONU

		//CREAMOS EL PAQUETE GATE PARA LA ONU
		GATEmsg *packet = new GATEmsg("gate");
		packet->setSrcAddress(srcAddress); // DIRECCIÓN DE ORIGEN O FUENTE
		packet->setDestAddress(onu); // DIRECCIÓN DE DESTINO
		packet->setByteLength(64); // TAMAÑO DEL PAQUETE GATE
		packet->setLambdagate(0); // LONGITUD DE ONDA POR LA QUE SE TRANSMITE EL PAQUETE GATE
		packet->setKind(0); // IDENTIFICADOR DEL PAQUETE GATE
		packet->setGrant_IntervalTxArraySize((int)par("numqueue")); // TAMAÑO DEL ARRAY QUE CONTIENE EL ANCHO DE BANDA DE SLOT

		// DEPENDIENDO DEL METODO DE EXTRACCIÓN DE PAQUETES, SE DEFINE UN ANCHO DE BANDA DE SLOT GENERAL O UNO PARA CADA COLA
		if((int)par("extractionmethod_StrictPQ0_Centralized1")==0)
		{
			B_slot[0]= B_alloc[onu]; // DEFINIMOS ANCHO DE BANDA DE SLOT
			packet->setGrant_IntervalTx(0,B_slot[0]);
		}
		else if((int)par("extractionmethod_StrictPQ0_Centralized1")==1)
		{
			//FALTA ALGORITMO PARA ASIGNAR POR COLAS!!!!!!!!!
			// BUCLE FOR PARA DEFINIR UN ANCHO DE BANDA DE SLOT PARA CADA COLA
			for(int b=0; b<(int)par("numqueue"); b++)
			{
				B_slot[b] = B_alloc[onu]; // DEFINIMOS EL ANCHO DE BANDA DE SLOT PARA CADA COLA
				packet->setGrant_IntervalTx(b,B_slot[b]);
				EV <<" Ancho de Banda de Slot "<<b<<" "<<B_slot[b]<<endl;
			}
		}
		packet->setGrant_IniTime(tiempo_tx_siguiente); // TIEMPO DE INICIO DE TRANSMISIÓN

		// VISUALIZAMOS POR PANTALLA TODOS LOS CAMPOS DEL PAQUETE GATE
		EV <<" Creamos el paquete gate para la Onu "<<packet->getDestAddress()<<endl;
		EV <<" Paquete Gate."<<endl;
		EV <<" Origen OLT ID: "<<packet->getSrcAddress()<<endl;
		EV <<" Destino ONU "<<packet->getDestAddress()<<endl;
		EV <<" Longitud de onda de envio, Lambda "<< packet->getLambdagate()<<endl;
		EV <<" Tipo "<<packet->getKind()<<endl;
		EV <<" Tiempo inicial Tx "<<packet->getGrant_IniTime()<<endl;
		EV <<"  "<<endl;

		// ENVIAMOS LOS PAQUETES GATE MEDIANTE EL ENVIO RETARDADO
		sendDelayed(packet, tasa_tx_gate, "mactxOut");

		//ACTUALIZAMOS EL TIEMPO DE INICIO DE TRANSMISION PARA LA SIGUIENTE ONU
		tiempo_tx_siguiente = tiempo_tx_siguiente + T_tx_onu;
		EV <<" Tiempo de Transmisión Siguiente: "<<tiempo_tx_siguiente<<endl;

	}

	delete reportmsg; // BORRAMOS EL PAQUETE REPORT

}
