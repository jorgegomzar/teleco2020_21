////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_ONU_GENTRAFFIC_H_
#define __REDPON_ONU_GENTRAFFIC_H_

#include <omnetpp.h>
#include <vector>
#include <time.h>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "ONU_SISTqueue.h"
#include "analysis.h"
#include "ONU_Table.h"
// DEPENDIENDO DE LA VERSIÓN DE LA FUENTE SELF SIMILAR CON LA QUE QUEREMOS TRABAJAR, DEBEMOS ELEGIR UNAS CABECERAS U OTRAS.
// FUENTE SELF SIMILAR VERSIÓN 2 //////////////////////////////////////////////////////////////////////////////////////////////////

#include "_types.h"
#include "_util.h"
#include "_rand_MT.h"
#include "_link.h"
#include "trace.h"
#include "aggreg.h"

using namespace omnetpp;
// PARA DEFINIR PAQUETES DE TAMAÑO VARIABLE EN LA FUENTE SELF SIMILAR VERSIÓN 2
//#define MIN_PACKET_SIZE 64    	// MINIMO TAMAÑO DEL PAQUETE
//#define MAX_PACKET_SIZE 1518  	// MÁXIMO TAMAÑO DEL PAQUETE

// FIN DE LA FUENTE VERSIÓN 2//////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



// FUENTE SELF SIMILAR VERSIÓN 3 ///////////////////////////////////////////////////////////////////////////////////////////////////
/*
#include "trf_gen_v3.h"
#include "avltree.h"
#include "_types.h"

#define MIN_IFG         0    	// DISTANCIA MINIMA ENTRE EL MARCO
#define MIN_PACKET_SIZE 64    	// MINIMO TAMAÑO DEL PAQUETE
#define MAX_PACKET_SIZE 1518  	// MÁXIMO TAMAÑO DEL PAQUETE
#define SHAPE_PARETO    1.4F 	 // PARÁMETRO ALFA PARA LA DISTRIBUCIÓN DE PARETO
#define MEAN_BURST_SIZE 4000 	// TAMAÑO MEDIO DE ESTALLIDO DE UNA RAFAGA INDIVIDUAL
#define SUB_STREAMS 256		// NÚMERO DE FLUJO DE SUB_STREAMS O FUENTES
using namespace GEN;
*/
// FIN DE LA FUENTE SELF SIMILAR VERSIÓN 3 /////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES Y MATRICES
typedef std::vector<int> int_vector_t; // VECTOR DE TIPO ENTERO
typedef std::vector<double> double_vector_t; // VECTOR DE TIPO DOUBLE

class ONU_GENTraffic : public cSimpleModule
{
	private:

		Analysis load_carga; // VARIABLE PARA CALCULAR LA CARGA TOTAL DEL NODO CON LA CLASE ANÁLISIS
		FILE * carga_paquetes; // ARCHIVO EN EL QUE SE GUARDAN LOS RESULTADOS DE LA CARGA DE LOS PAQUETES DE LA CLASE ANÁLISIS
		FILE * paquetes; // ARCHIVO EN EL QUE SE GUARDAN LOS RESULTADOS DEL NÚMERO DE PAQUETES QUE SE GENERAN POR CADA SERVICIO

	public:

// INICIO DE CÓDIGO PARA LA FUENTE SELF SIMILAR VERSIÓN 2 ////////////////////////////////////////////////////////////////

		ONU_GENTraffic(); // CONSTRUCTOR
		virtual ~ONU_GENTraffic(); //  DESTRUCTOR
		Generator *pAG; // PUNTERO AL GENERADOR DE PAQUETES PARA LA FUENTE SELF SIMILAR VERSIÓN 2
		int packetSize; // VARIABLE DEL TAMAÑO DEL PAQUETE QUE GENERAMOS EN LAS FUENTES
		double_vector_t load_dmb; // VECTOR QUE INDICA LA CARGA DEL NODO DE LA ONU


// FINAL DE CÓDIGO PARA LA FUENTE SELF SIMILAR VERSIÓN 2 /////////////////////////////////////////////////////////////////

// INICIO DE CÓDIGO PARA LA FUENTE SELF SIMILAR VERSIÓN 3 ////////////////////////////////////////////////////////////////////
/*
		PacketGenerator *pSRC; // PUNTERO AL GENERADOR DE PAQUETES
		// ATRIBUTO PARA ESTABLECER EL INTERVALO interarrivalTime ENTRE PAQUETES DE PARÁMETROS (DIFERENCIA ENTRE EL PAQUETE ACTUAL Y EL SIGUIENTE).
		// ESTE PARÁMETRO SE HA DE CONVERTIR EN BIT Y DESPUES A TIEMPO EN FUNCIÓN DE LA VELOCIDAD DE TRANSMISIÓN.
		simtime_t interarrivalTime;
		double load; // VARIABLE QUE INDICA LA CARGA DEL NODO DE LA ONU
		double packet_size; // TAMAÑO DEL PAQUETE
		ONU_GENTraffic(); // CONSTRUCTOR
		virtual ~ONU_GENTraffic(); // DESTRUCTOR
*/
// FINAL DE CÓDIGO PARA LA FUENTE SELF SIMILAR VERSIÓN 3 ///////////////////////////////////////////////////////////////////////

		//ONU_Table *onutable_module;

		double wavelength_bit_rate; // TASA DE BITS POR LONGITUD DE ONDA UTILIZADA PARA LAS DOS VERSIONES DE LAS FUENTES

		ONU_SISTqueue *onu_queue; // DEFINIMOS VARIABLE PARA PODER ENTRAR EN EL MÓDULO OLT_TABLE
		long tamsumqueue; // TAMAÑO DE LA SUMA DEL TAMAÑO DE LOS PAQUETES QUE LLEGAN A LAS COLAS DE LA ONU
		int_vector_t tamsumpop; // VECTOR DEL TAMAÑO DE LA SUMA DE LOS BYTES DE LOS PAQUETES EXTRAIDOS DE LAS COLAS
		long double suma_tam_packets; // VARIABLE DE LA SUMA TOTAL DEL TAMAÑO DE LOS PAQUETES GENERADOS POR LA ONU EN BYTES
		simtime_t time_creation; // TIEMPO DE CREACCIÓN DEL PAQUETE
		long double total_load; // CARGA TOTAL DEL NODO DE LA ONU
		int_vector_t suma_total; // VECTOR DE LA SUMA DE TODOS LOS BYTES QUE HAY EN LAS COLAS

		// VARIABLES USADAS PARA LA VERSIÓN TRIMODAL
		long packet_64; // VARIABLE DEL NÚMERO DE PAQUETES CREADOS DE 64 BYTES POR LA FUENTE SELF SIMILAR VERSIÓN 2
		long packet_594; // VARIABLE DEL NÚMERO DE PAQUETES CREADOS DE 594 BYTES POR LA FUENTE SELF SIMILAR VERSIÓN 2
		long packet_1500; // VARIABLE DEL NÚMERO DE PAQUETES CREADOS DE 150 BYTES POR LA FUENTE SELF SIMILAR VERSIÓN 2
		long totalpacket; // VARIABLE DEL NÚMERO DE PAQUETES TOTAL CREADOS POR LA FUENTE SELF SIMILAR VERSIÓN 2

	protected:
		virtual void initialize();
		virtual void handleMessage(cMessage *msg);

		virtual void separatequeue(cMessage *msg); // FUNCIÓN DEL MÉTODO DE INSERCIÓN DE PAQUETES DE COLAS SEPARADAS
		virtual void priorityqueue(cMessage *msg); // FUNCIÓN DEL MÉTODO DE INSERCIÓN DE PAQUETES DE PRIORIDAD DE COLAS

		virtual void finish(); // DEFINICIÓN DE LA FUNCIÓN FINALIZAR
};

#endif
