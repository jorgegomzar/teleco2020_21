////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TTULO: Implementacin de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERA TCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_ONU_SISTQUEUE_H_
#define __REDPON_ONU_SISTQUEUE_H_

#include <omnetpp.h>
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
using namespace omnetpp;
//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES
typedef std::vector<int> int_vector_t; // VECTOR DE TIPO ENTERO

class ONU_SISTqueue : public cSimpleModule
{
	public:
		cQueue queue; // CREAMOS UNA COLA LLAMADA queue
		int_vector_t tamqueue; // VECTOR QUE INDICA EL TAMAO DE LA COLA
		long tamqueuepop; // VARIABLE DEL TAMAO DE LOS PAQUETES QUE BORRAMOS DE LAS COLAS
		long tamqueueextract; // VARIABLE DEL TAMAO DE LOS PAQUETES QUE CHEQUEAMOS ANTES DE SACARLOS DE LAS COLAS
		long tamextract; // VARIABLE DEL TAMAO DE LOS PAQUETES QUE EXTRAEMOS DE LAS COLAS

		virtual void handleMessage(cMessage *msg);
		virtual void initialize();
		virtual void finish();

		void deleteelement(cMessage *msg); // FUNCIN PARA ELIMINAR LOS PAQUETES DEL PRINCIPIO DE LAS COLAS

		void checkpacket(); // FUNCIN PARA CHUEQUEAR LOS PAQUETES DEL PRINCIPIO DE LA COLA PARA SABER SU TAMAO EN BYTES
		void extractionelement(int); // FUNCIN PARA EXTRAER LOS PAQUETES DEL PRINCIPIO DE LAS COLAS

};

#endif
