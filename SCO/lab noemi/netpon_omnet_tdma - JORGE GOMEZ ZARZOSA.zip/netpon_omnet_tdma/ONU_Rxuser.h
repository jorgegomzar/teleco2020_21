////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_ONU_RXUSER_H_
#define __REDPON_ONU_RXUSER_H_

#include <omnetpp.h>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
using namespace omnetpp;

class ONU_Rxuser : public cSimpleModule
{
	private:
		cStdDev eedStats; // PARÁMETRO DE ESTADISTICAS DEFINIDO PARA OBTENERLAS MANUALMENTE
		int nombreonu; // VARIABLE QUE INDICA EL IDENTIFICADOR DE LAS ONUS
		long numReceived; // VARIABLE PARA CONTAR EL NUMERO DE PAQUETES ETHERNET RECIBIDOS

	protected:
		virtual void initialize();
		virtual void handleMessage(cMessage *msg);

		virtual void finish();// DEFINICIÓN DE LA FUNCIÓN FINALIZAR
};

#endif
