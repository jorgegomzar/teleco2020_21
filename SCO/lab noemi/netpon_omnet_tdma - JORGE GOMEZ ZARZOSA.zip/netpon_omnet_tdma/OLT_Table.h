////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_OLT_TABLE_H_
#define __REDPON_OLT_TABLE_H_

#include <omnetpp.h>
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
using namespace omnetpp;

//DEFINIMOS LOS TIPOS DE std DE LOS VECTORES Y MATRICES
typedef std::vector<int> int_vector_t; // VECTOR TIPO ENTERO
typedef std::vector<simtime_t> simtime_t_vector_t; // VECTOR TIPO TIEMPO
typedef std::vector< int_vector_t > int_matrix_t; // MATRIZ DE TIPO ENTERO

class OLT_Table : public cSimpleModule
{
	public:
		int_matrix_t table_olt_report; // MATRIZ DE TIPO ENTERO PARA GUARDAR EL TAMAÑO DE LAS COLAS, ANCHO DE BANA ASIGANDO Y DEMANDADO
		simtime_t_vector_t table_olt_report_time; // VECTOR DE TIPO TIEMPO PARA GUARDAR EL TIEMPO EN EL QUE SE ENVIA EL RECEPTOR

		int numInitStages() const; // FUNCIÓN QUE INICIALIZA VARIAS ETAPAS.

	protected:
		virtual void initialize(int stage);
		virtual void handleMessage(cMessage *msg);
};

#endif
