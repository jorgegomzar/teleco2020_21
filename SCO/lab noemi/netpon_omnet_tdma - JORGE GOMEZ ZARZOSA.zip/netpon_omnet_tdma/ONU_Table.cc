////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#include "ONU_Table.h"
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"

// GENERAMOS EL CÓDIGO Y LAS FUNCIONES DEL MÓDULO SIMPLE
Define_Module(ONU_Table);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN INITIALIZE()--> ESTA FUNCIÓN SE INVOCA DESPUÉS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE LEEN LOS      //
//						  PARÁMETROS DEL MÓDULO Y SE INICIALIZAN TODAS DAS LAS VARIABLES DECLARADAS PARA ESTE MÓDULO SIMPLE, SE //
//						  ASIGNAN ESTRUCTURAS DE DATOS DINÁMICOS Y SE ASIGNAN E INICIALIZAN LOS AUTOMENSAJES SI SON NECESARIOS  //
//						  PARA EL FUNCIONAMIENTO DE ESTE MÓDULO.			   													//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int ONU_Table::numInitStages() const{return 1;}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN INITIALIZE()--> ESTA FUNCIÓN SE INVOCA DESPUÉS DE QUE OMNET++ HA PUESTO EN MARCHA LA RED, EN LA CUAL SE INICIALIZAN   //
// 						  TODAS LAS VARIABLES DECLARADAS PARA ESTE MÓDULO SIMPLE, AL IGUAL QUE SE CREAN LOS AUTOMENSAJES        //
//						  NECESARIOS PARA EL FUNCIONAMIENTO DE ESTE MÓDULO.   													//
//						  LA FUNCIÓN INITIALIZE(INT STAGE) SE UTILIZA PARA INICIALIZAR VARIAS ETAPAS SEGUN EL VALOR STAGE.      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Table::initialize(int stage)
{
	// VARIABLES
	int file = (int)par("numqueue"); // VARIABLE QUE INDICA EL NÚMERO DE FILAS DE LA TABLA DEL MÓDULO OLT_TABLE

	if(stage==0)
		{
			// RESERVAMOS DE FORMA DINÁMICA EL TAMAÑO DE LA TABLA E INICIALIZAMOS A 0
			table_onu_gate.resize(file,0);
			table_onu_gate_time.resize(2,0);
		}

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG)--> ESTA FUNCIÓN SE INVOCA CON EL MENSAJE COMO PARÁMETRO CADA VEZ QUE EL MÓDULO RECIBE UN //
//										  UN MENSAJE O PAQUETE. SE RECORRE EL CÓDIGO IMPLEMENTADO PARA DEVOLVER UN VALOR O  	//
//										  EJECUTAR UNA FUNCIÓN DENTRO DEL MÓDULO SIMPLE. EL TIEMPO DE SIMULACIÓN NO TRANSCURRE  //
//										  DENTRO DE LA LLAMADA DE LA FUNCIÓN HANDLEMESSAGE(CMESSAGE *MSG) MIENTRAS RECORRE EL	//
//										  CÓDIGO IMPLEMENTADO.																	//                                                                         //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ONU_Table::handleMessage(cMessage *msg)
{
}
