////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_SPLITTER_H_
#define __REDPON_SPLITTER_H_

#include <omnetpp.h>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
using namespace omnetpp ;

class SPLITTER : public cSimpleModule
{
	protected:
		virtual void initialize();
		virtual void handleMessage(cMessage *msg);
};

#endif
