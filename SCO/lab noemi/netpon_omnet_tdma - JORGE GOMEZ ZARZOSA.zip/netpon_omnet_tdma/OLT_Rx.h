////////////////////////////////////////////////////////////////////////////////////////
// PROYECTO FIN DE CARRERA															  //
// TÍTULO: Implementación de un Simulador de Redes de Acceso Pasivas en Omnet         //
//												                                      //
// AUTOR: Jose Maria Robledo Saez													  //
// TUTOR: Noemi Merayo Alvarez														  //
// INGENIERÍA TÉCNICA DE TELECOMUNICACIONES, SISTEMAS DE TELECOMUNICACIÓN			  //
// UNIVERSIDAD DE VALLADOLID													      //
////////////////////////////////////////////////////////////////////////////////////////

#ifndef __REDPON_OLT_RX_H_
#define __REDPON_OLT_RX_H_

#include <omnetpp.h>
#include <vector>
#include "GATE_m.h"
#include "REPORT_m.h"
#include "ETHERNET_m.h"
#include "analysis.h"

using namespace omnetpp;
typedef std::vector<int> int_vector_t; // VECTOR TIPO ENTERO
typedef std::vector<simtime_t> simtime_t_vector_t; // VECTOR TIPO DOUBLE

class OLT_Rx : public cSimpleModule
{
	private:
	// DEFINIMOS LOS PARÁMETROS PARA LA CLASE ANÁLISIS
		// PARÁMETRO PARA OBTENER EL RETARDO GLOBAL CON LA CLASE ANÁLISIS
		std::vector<Analysis> retardo_global_P; // VECTOR DE CLASE ANÁLISIS PARA CREAR EL RETARDO GLOBAL

		// PARÁMETROS PARA OBTENER EL RETARDO DE CADA SLA CON LA CLASE ANÁLISIS
		std::vector<Analysis> retardo_sla; // VECTOR DE CLASE ANÁLISIS PARA CREAR EL RETARDO GLOBAL DE CADA SLA

		// PARÁMETROS PARA OBTENER EL RETARDO DE CADA SLA CON LA CLASE ANÁLISIS
		std::vector <std::vector < Analysis > > retardo_servicios_sla; // MATRIZ DE CLASE ANÁLISIS PARA CREAR EL RETARDO DE LOS SLAs POR SERVICIOS

		// PARÁMETRO PARA OBTENER LA MEDIA DE LOS BYTES QUE SE QUEDAN EN LA COLAS DESPUÉS DE CADA CICLO CON LA CLASE ANÁLISIS
		std::vector<Analysis> media_bytes_total_onus; // VECTOR DE CLASE ANÁLISIS PARA CREAR LOS BYTES QUE SE QUEDAN EN LA COLAS DESPUÉS DE CADA CICLO

		// DEFINIMOS LOS ARCHIVOS DONDE SE GUARDAN LOS RESULTADOS DE RECOGER LAS ESTADÍSTICAS
		FILE * retardo_analisis_sla; // ARCHIVO DONDE SE GUARDARAN LOS RESULTADOS DE LA CLASE ANÁLISIS PARA EL RETARDO DE LOS SLAs
		FILE * retardo_analisis; // ARCHIVO DONDE SE GUARDARAN LOS RESULTADOS DE LA CLASE ANÁLISIS PARA EL RETARDO GLOBAL
		FILE * media_total_onu; // ARCHIVO DONDE GUARDAMOS LA MEDIA DE LAS COLAS
		FILE * throughput_net; // ARCHIVO DONDE GUARDAMOS EL RENDIMIENTO DE LA RED

		int_vector_t num_sla; // VECTOR PARA GUARDAR EL IDENTIFICADOR DEL SLA DE LA ONU ASOCIADA
		simtime_t_vector_t retardo_P; // VECTOR DONDE GUARDAMOS EL RETARDO GLOBAL DE LOS SERVICIOS
		simtime_t_vector_t retardo; // VECTOR DONDE GUARDAMOS EL RETARDO DE LOS SLAs
		long numReceived; // VARIABLE PARA CONTAR EL NUMERO DE PAQUETES ETHERNET RECIBIDOS
		int_vector_t tam_packet_queue; // TAMAÑO EN BYTES QUE QUEDAN EN LAS COLAS DESPUÉS DE CADA CICLO
		long double total_bytes_received; // BYTES TOTALES DE LOS PAQUETES ETHERNET RECIBIDOS EN EL RECEPTOR DEL OLT
		long double total_bits_received; // BITS TOTALES DE LOS PAQUETES ETHERNET RECIBIDOS EN EL RECEPTOR DEL OLT
		double throughput; // RENDIEMIENTO DE LA RED

	protected:
		virtual void initialize();
		virtual void handleMessage(cMessage *msg);

		virtual void finish(); // DEFINICIÓN DE LA FUNCIÓN FINALIZAR
};

#endif
